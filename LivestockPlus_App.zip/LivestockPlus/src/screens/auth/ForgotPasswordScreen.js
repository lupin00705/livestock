import React, { useState } from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { InputField, PrimaryButton, ScreenHeader } from '../../components/common';
import { Colors, Typography, Spacing } from '../../utils/theme';

export default function ForgotPasswordScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSend = async () => {
    if (!email) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1200));
    setLoading(false);
    setSent(true);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenHeader title="Reset Password" onBack={() => navigation.goBack()} />
      <View style={styles.content}>
        {sent ? (
          <View style={styles.successState}>
            <View style={styles.successIcon}>
              <MaterialCommunityIcons name="email-check" size={56} color={Colors.primary} />
            </View>
            <Text style={styles.successTitle}>Check Your Email</Text>
            <Text style={styles.successText}>
              We've sent a password reset link to {email}. Check your inbox and follow the instructions.
            </Text>
            <PrimaryButton
              title="Back to Login"
              onPress={() => navigation.navigate('Login')}
              style={{ marginTop: Spacing.xl }}
            />
          </View>
        ) : (
          <>
            <View style={styles.iconBox}>
              <MaterialCommunityIcons name="lock-reset" size={48} color={Colors.primary} />
            </View>
            <Text style={styles.title}>Forgot your password?</Text>
            <Text style={styles.subtitle}>
              Enter your email address and we'll send you a link to reset your password.
            </Text>
            <InputField
              label="Email Address"
              value={email}
              onChangeText={setEmail}
              placeholder="you@example.com"
              keyboardType="email-address"
              icon="email-outline"
            />
            <PrimaryButton
              title="Send Reset Link"
              onPress={handleSend}
              loading={loading}
              disabled={!email}
              icon="send"
            />
          </>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  content: { flex: 1, paddingHorizontal: Spacing.xl, paddingTop: Spacing.xl },
  iconBox: {
    width: 90, height: 90, borderRadius: 45,
    backgroundColor: '#E8F5E9',
    alignItems: 'center', justifyContent: 'center',
    alignSelf: 'center', marginBottom: Spacing.xl,
  },
  title: {
    fontSize: Typography.xl, fontWeight: Typography.bold,
    color: Colors.text, marginBottom: Spacing.sm, textAlign: 'center',
  },
  subtitle: {
    fontSize: Typography.base, color: Colors.textSecondary,
    textAlign: 'center', lineHeight: 24, marginBottom: Spacing.xl,
  },
  successState: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.base },
  successIcon: {
    width: 110, height: 110, borderRadius: 55,
    backgroundColor: '#E8F5E9',
    alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.xl,
  },
  successTitle: {
    fontSize: Typography.xxl, fontWeight: Typography.bold,
    color: Colors.text, marginBottom: Spacing.md,
  },
  successText: {
    fontSize: Typography.base, color: Colors.textSecondary,
    textAlign: 'center', lineHeight: 24,
  },
});
