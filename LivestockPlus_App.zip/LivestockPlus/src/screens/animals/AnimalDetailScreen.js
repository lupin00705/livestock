import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { LineChart, BarChart } from 'react-native-chart-kit';
import { useApp } from '../../context/AppContext';
import { Card, StatusBadge, AnimalAvatar, ScreenHeader } from '../../components/common';
import { Colors, Typography, Spacing, Radius, Shadows } from '../../utils/theme';

const { width } = Dimensions.get('window');
const TABS = ['Health', 'Milk', 'Reproduction', 'Vaccination'];

const chartConfig = (dark) => ({
  backgroundGradientFrom: dark ? Colors.darkSurface : Colors.surface,
  backgroundGradientTo: dark ? Colors.darkSurface : Colors.surface,
  decimalPlaces: 1,
  color: (opacity = 1) => `rgba(46, 125, 50, ${opacity})`,
  labelColor: (opacity = 1) => dark
    ? `rgba(165,200,167,${opacity})`
    : `rgba(90,116,96,${opacity})`,
  style: { borderRadius: Radius.lg },
  propsForDots: { r: '4', strokeWidth: '2', stroke: Colors.primary },
});

function HealthTab({ animal, dark }) {
  const h = animal.health;
  const symptoms = ['Lethargy', 'Loss of appetite', 'Nasal discharge', 'Limping', 'Coughing', 'Diarrhea'];
  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.md }}>
      {/* Vitals */}
      <Card dark={dark}>
        <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>Current Vitals</Text>
        <View style={styles.vitalsGrid}>
          {[
            { label: 'Weight', value: `${h.weight} kg`, icon: 'weight-kilogram', color: Colors.primary },
            { label: 'BCS', value: h.bcs, icon: 'chart-arc', color: Colors.accent },
            { label: 'Temp', value: `${animal.sensors?.temperature?.value}°C`, icon: 'thermometer', color: Colors.danger },
            { label: 'Status', value: h.currentStatus, icon: 'heart-pulse', color: Colors.success },
          ].map(v => (
            <View key={v.label} style={[styles.vitalItem, { backgroundColor: v.color + '18' }]}>
              <MaterialCommunityIcons name={v.icon} size={20} color={v.color} />
              <Text style={[styles.vitalValue, { color: v.color }]}>{v.value}</Text>
              <Text style={[styles.vitalLabel, dark && { color: Colors.darkTextMuted }]}>{v.label}</Text>
            </View>
          ))}
        </View>
      </Card>

      {/* Symptoms */}
      <Card dark={dark}>
        <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>Symptom Checklist</Text>
        <View style={styles.symptomGrid}>
          {symptoms.map(s => {
            const checked = h.symptoms.includes(s);
            return (
              <TouchableOpacity key={s} activeOpacity={0.8} style={[styles.symptomChip, checked && styles.symptomChipActive, dark && styles.symptomChipDark]}>
                <MaterialCommunityIcons name={checked ? 'checkbox-marked-circle' : 'checkbox-blank-circle-outline'} size={16} color={checked ? Colors.danger : Colors.textMuted} />
                <Text style={[styles.symptomText, checked && { color: Colors.danger }, dark && { color: Colors.darkTextSecondary }]}>{s}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </Card>

      {/* Vet Notes */}
      <Card dark={dark}>
        <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>Vet Notes</Text>
        <Text style={[styles.vetNotes, dark && { color: Colors.darkTextSecondary }]}>{h.vetNotes}</Text>
      </Card>

      {/* History */}
      <Card dark={dark}>
        <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>Diagnosis History</Text>
        {h.records.map(r => (
          <View key={r.id} style={[styles.recordRow, dark && styles.recordRowDark]}>
            <View style={styles.recordDot} />
            <View style={styles.recordInfo}>
              <Text style={[styles.recordType, dark && { color: Colors.darkText }]}>{r.type}: {r.diagnosis}</Text>
              <Text style={[styles.recordMeta, dark && { color: Colors.darkTextMuted }]}>
                {new Date(r.date).toLocaleDateString()} · {r.veterinarian}
              </Text>
              <Text style={[styles.recordNotes, dark && { color: Colors.darkTextSecondary }]}>{r.notes}</Text>
            </View>
          </View>
        ))}
      </Card>
    </ScrollView>
  );
}

function MilkTab({ animal, dark }) {
  if (!animal.milk) {
    return (
      <View style={styles.noData}>
        <MaterialCommunityIcons name="water-off" size={48} color={Colors.textMuted} />
        <Text style={[styles.noDataText, dark && { color: Colors.darkText }]}>No milk data for this animal</Text>
      </View>
    );
  }
  const m = animal.milk;
  const labels = m.weeklyData.map(d => d.day);
  const morningData = m.weeklyData.map(d => d.morning);
  const eveningData = m.weeklyData.map(d => d.evening);

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.md }}>
      <View style={styles.milkStatsRow}>
        {[
          { label: 'Today', value: `${m.currentDaily}L`, color: Colors.info },
          { label: 'Monthly', value: `${m.monthlyTotal}L`, color: Colors.primary },
          { label: 'Avg/Day', value: `${m.avgDaily}L`, color: Colors.accent },
        ].map(s => (
          <Card key={s.label} dark={dark} style={[styles.milkStatCard, { borderTopColor: s.color, borderTopWidth: 3 }]}>
            <Text style={[styles.milkStatValue, { color: s.color }]}>{s.value}</Text>
            <Text style={[styles.milkStatLabel, dark && { color: Colors.darkTextMuted }]}>{s.label}</Text>
          </Card>
        ))}
      </View>

      <Card dark={dark}>
        <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>7-Day Production</Text>
        <BarChart
          data={{
            labels,
            datasets: [{ data: morningData.map((v, i) => v + eveningData[i]) }],
          }}
          width={width - 80}
          height={180}
          chartConfig={chartConfig(dark)}
          style={styles.chart}
          fromZero
          showValuesOnTopOfBars
        />
      </Card>

      <Card dark={dark}>
        <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>Daily Log</Text>
        {m.logs.map(log => (
          <View key={log.id} style={[styles.milkLogRow, dark && styles.milkLogRowDark]}>
            <Text style={[styles.milkLogDate, dark && { color: Colors.darkTextSecondary }]}>
              {new Date(log.date).toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' })}
            </Text>
            <View style={styles.milkLogValues}>
              <View style={styles.milkLogItem}>
                <MaterialCommunityIcons name="weather-sunny" size={14} color={Colors.accent} />
                <Text style={[styles.milkLogValue, dark && { color: Colors.darkText }]}>{log.morning}L</Text>
              </View>
              <View style={styles.milkLogItem}>
                <MaterialCommunityIcons name="weather-night" size={14} color={Colors.info} />
                <Text style={[styles.milkLogValue, dark && { color: Colors.darkText }]}>{log.evening}L</Text>
              </View>
              <Text style={[styles.milkLogTotal, dark && { color: Colors.darkText }]}>
                {(log.morning + log.evening).toFixed(1)}L
              </Text>
            </View>
            <View style={[styles.qualityBadge, { backgroundColor: log.quality === 'A' ? '#E8F5E9' : '#FFF8E1' }]}>
              <Text style={{ fontSize: 11, fontWeight: '700', color: log.quality === 'A' ? Colors.success : Colors.accent }}>
                {log.quality}
              </Text>
            </View>
          </View>
        ))}
      </Card>
    </ScrollView>
  );
}

function ReproductionTab({ animal, dark }) {
  const r = animal.reproduction;
  const statusColors = { pregnant: Colors.info, open: Colors.accent, lactating: Colors.success, dry: Colors.textMuted };
  const daysToDelivery = r.expectedDelivery
    ? Math.max(0, Math.ceil((new Date(r.expectedDelivery) - new Date()) / 86400000))
    : null;

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.md }}>
      <Card dark={dark}>
        <View style={styles.reproStatusRow}>
          <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>Reproductive Status</Text>
          <View style={[styles.reproBadge, { backgroundColor: (statusColors[r.status] || Colors.textMuted) + '20' }]}>
            <Text style={[styles.reproBadgeText, { color: statusColors[r.status] || Colors.textMuted }]}>
              {r.status.charAt(0).toUpperCase() + r.status.slice(1)}
            </Text>
          </View>
        </View>
        {daysToDelivery !== null && (
          <View style={styles.deliveryCountdown}>
            <MaterialCommunityIcons name="baby-carriage" size={28} color={Colors.info} />
            <View>
              <Text style={[styles.deliveryDays, { color: Colors.info }]}>{daysToDelivery} days</Text>
              <Text style={[styles.deliveryLabel, dark && { color: Colors.darkTextSecondary }]}>Until Expected Delivery</Text>
            </View>
          </View>
        )}
        <View style={styles.reproInfoGrid}>
          {[
            { label: 'Last Heat', value: r.lastHeat ? new Date(r.lastHeat).toLocaleDateString() : 'N/A' },
            { label: 'Next Expected', value: r.nextExpectedHeat ? new Date(r.nextExpectedHeat).toLocaleDateString() : 'N/A' },
            { label: 'Breed Date', value: r.pregnancyDate ? new Date(r.pregnancyDate).toLocaleDateString() : 'N/A' },
            { label: 'Due Date', value: r.expectedDelivery ? new Date(r.expectedDelivery).toLocaleDateString() : 'N/A' },
          ].map(item => (
            <View key={item.label} style={styles.reproInfoItem}>
              <Text style={[styles.reproInfoLabel, dark && { color: Colors.darkTextMuted }]}>{item.label}</Text>
              <Text style={[styles.reproInfoValue, dark && { color: Colors.darkText }]}>{item.value}</Text>
            </View>
          ))}
        </View>
      </Card>

      <Card dark={dark}>
        <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>Breeding Log</Text>
        {r.breedingLog.map(b => (
          <View key={b.id} style={[styles.breedRow, dark && styles.breedRowDark]}>
            <View style={styles.breedDot} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.breedSire, dark && { color: Colors.darkText }]}>{b.sire}</Text>
              <Text style={[styles.breedMeta, dark && { color: Colors.darkTextMuted }]}>
                {new Date(b.date).toLocaleDateString()} · {b.method}
              </Text>
              <Text style={[styles.breedResult, { color: b.result.includes('pregnant') ? Colors.success : Colors.textMuted }]}>
                {b.result}
              </Text>
            </View>
          </View>
        ))}
      </Card>

      <Card dark={dark}>
        <Text style={[styles.tabSectionTitle, dark && { color: Colors.darkText }]}>Offspring</Text>
        {r.offspring.map(o => (
          <View key={o.id} style={[styles.offspringRow, dark && { backgroundColor: Colors.darkSurfaceSecondary }]}>
            <MaterialCommunityIcons name="baby-carriage" size={24} color={Colors.accent} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.offspringTag, dark && { color: Colors.darkText }]}>{o.tagNumber}</Text>
              <Text style={[styles.offspringMeta, dark && { color: Colors.darkTextMuted }]}>
                {o.sex} · Born {new Date(o.dob).toLocaleDateString()} · {o.weight}
              </Text>
            </View>
          </View>
        ))}
      </Card>
    </ScrollView>
  );
}

function VaccinationTab({ animal, dark }) {
  const vaccinations = animal.vaccinations;
  const statusColors = {
    upcoming: Colors.accent,
    overdue: Colors.danger,
    scheduled: Colors.info,
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.md }}>
      {vaccinations.map(v => (
        <Card key={v.id} dark={dark} style={[styles.vacCard, { borderLeftColor: statusColors[v.status] || Colors.textMuted, borderLeftWidth: 4 }]}>
          <View style={styles.vacHeader}>
            <Text style={[styles.vacName, dark && { color: Colors.darkText }]}>{v.name}</Text>
            <View style={[styles.vacStatusBadge, { backgroundColor: (statusColors[v.status] || Colors.textMuted) + '20' }]}>
              <Text style={[styles.vacStatusText, { color: statusColors[v.status] || Colors.textMuted }]}>
                {v.status.charAt(0).toUpperCase() + v.status.slice(1)}
              </Text>
            </View>
          </View>
          <View style={styles.vacDetails}>
            <View style={styles.vacDetailItem}>
              <MaterialCommunityIcons name="calendar-check" size={14} color={Colors.success} />
              <Text style={[styles.vacDetailText, dark && { color: Colors.darkTextSecondary }]}>
                Last: {new Date(v.date).toLocaleDateString()}
              </Text>
            </View>
            <View style={styles.vacDetailItem}>
              <MaterialCommunityIcons name="calendar-clock" size={14} color={statusColors[v.status] || Colors.textMuted} />
              <Text style={[styles.vacDetailText, dark && { color: Colors.darkTextSecondary }]}>
                Next: {new Date(v.nextDue).toLocaleDateString()}
              </Text>
            </View>
            <View style={styles.vacDetailItem}>
              <MaterialCommunityIcons name="doctor" size={14} color={Colors.textMuted} />
              <Text style={[styles.vacDetailText, dark && { color: Colors.darkTextSecondary }]}>{v.veterinarian}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.markDoneBtn} activeOpacity={0.8}>
            <MaterialCommunityIcons name="check" size={14} color={Colors.primary} />
            <Text style={styles.markDoneText}>Mark as Done</Text>
          </TouchableOpacity>
        </Card>
      ))}
      <TouchableOpacity style={[styles.addVacBtn, dark && styles.addVacBtnDark]} activeOpacity={0.85}>
        <MaterialCommunityIcons name="plus" size={18} color={Colors.primary} />
        <Text style={styles.addVacText}>Add Vaccination Record</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

export default function AnimalDetailScreen({ route, navigation }) {
  const { animalId } = route.params;
  const { state } = useApp();
  const dark = state.darkMode;
  const animal = state.animals.find(a => a.id === animalId);
  const [activeTab, setActiveTab] = useState('Health');

  if (!animal) {
    return (
      <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
        <ScreenHeader title="Animal" onBack={() => navigation.goBack()} dark={dark} />
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: Colors.textSecondary }}>Animal not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  const temp = animal.sensors?.temperature?.value;

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      {/* Header */}
      <LinearGradient
        colors={dark ? ['#1A3A1C', '#121212'] : [animal.avatarColor + 'CC', animal.avatarColor + '44']}
        style={styles.headerGrad}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      >
        <View style={styles.headerNav}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <MaterialCommunityIcons name="arrow-left" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.editBtn}>
            <MaterialCommunityIcons name="pencil" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={styles.profileRow}>
          <AnimalAvatar animal={animal} size={80} />
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{animal.name}</Text>
            <Text style={styles.profileBreed}>{animal.species} · {animal.breed}</Text>
            <Text style={styles.profileTag}>{animal.tagNumber}</Text>
            <View style={styles.profileMeta}>
              <Text style={styles.profileMetaText}>Age: {animal.age}</Text>
              <Text style={styles.profileMetaText}>·</Text>
              <Text style={styles.profileMetaText}>{animal.weight} kg</Text>
            </View>
          </View>
          <StatusBadge status={animal.status} />
        </View>

        {/* Quick sensor row */}
        <View style={styles.sensorRow}>
          {[
            { icon: 'thermometer', value: `${temp}°C`, label: 'Temp', color: temp > 39.5 ? Colors.dangerLight : Colors.primaryLight },
            { icon: 'water', value: `${animal.sensors?.milk?.value || '--'}L`, label: 'Milk', color: Colors.accentLight },
            { icon: 'walk', value: `${animal.sensors?.activity?.value || '--'}`, label: 'Steps', color: Colors.infoLight },
            { icon: 'battery', value: `${animal.sensors?.temperature?.batteryLevel}%`, label: 'Battery', color: Colors.primaryLight },
          ].map(s => (
            <View key={s.label} style={styles.sensorItem}>
              <MaterialCommunityIcons name={s.icon} size={16} color={s.color || '#fff'} />
              <Text style={styles.sensorValue}>{s.value}</Text>
              <Text style={styles.sensorLabel}>{s.label}</Text>
            </View>
          ))}
        </View>
      </LinearGradient>

      {/* Quick Actions */}
      <View style={[styles.quickActions, dark && styles.quickActionsDark]}>
        {[
          { label: 'Temperature', icon: 'thermometer', screen: 'TemperatureMonitor' },
          { label: 'Health', icon: 'heart-pulse', screen: 'HealthMonitor' },
          { label: 'Milk', icon: 'water', screen: 'MilkProduction' },
          { label: 'Vaccines', icon: 'needle', screen: 'Vaccination' },
        ].map(a => (
          <TouchableOpacity
            key={a.label}
            onPress={() => navigation.navigate(a.screen, { animalId })}
            style={styles.quickActionBtn}
            activeOpacity={0.8}
          >
            <View style={[styles.quickActionIcon, dark && { backgroundColor: Colors.darkSurfaceSecondary }]}>
              <MaterialCommunityIcons name={a.icon} size={20} color={Colors.primary} />
            </View>
            <Text style={[styles.quickActionLabel, dark && { color: Colors.darkTextSecondary }]}>{a.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Tabs */}
      <View style={[styles.tabBar, dark && styles.tabBarDark]}>
        {TABS.map(tab => (
          <TouchableOpacity
            key={tab}
            onPress={() => setActiveTab(tab)}
            style={[styles.tab, activeTab === tab && styles.tabActive]}
            activeOpacity={0.8}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive, dark && { color: Colors.darkTextSecondary }]}>
              {tab}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Tab Content */}
      <View style={styles.tabContent}>
        {activeTab === 'Health' && <HealthTab animal={animal} dark={dark} />}
        {activeTab === 'Milk' && <MilkTab animal={animal} dark={dark} />}
        {activeTab === 'Reproduction' && <ReproductionTab animal={animal} dark={dark} />}
        {activeTab === 'Vaccination' && <VaccinationTab animal={animal} dark={dark} />}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  headerGrad: { paddingBottom: Spacing.base },
  headerNav: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.base, paddingTop: Spacing.base, paddingBottom: Spacing.md },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center' },
  editBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center' },
  profileRow: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.md, paddingHorizontal: Spacing.base, marginBottom: Spacing.md },
  profileInfo: { flex: 1 },
  profileName: { fontSize: Typography.xxl, fontWeight: '800', color: '#fff', textShadowColor: 'rgba(0,0,0,0.3)', textShadowRadius: 4 },
  profileBreed: { fontSize: Typography.sm, color: 'rgba(255,255,255,0.85)', marginTop: 2 },
  profileTag: { fontSize: Typography.xs, color: 'rgba(255,255,255,0.7)', marginTop: 1 },
  profileMeta: { flexDirection: 'row', gap: 6, marginTop: 4 },
  profileMetaText: { fontSize: Typography.xs, color: 'rgba(255,255,255,0.75)', fontWeight: '500' },
  sensorRow: { flexDirection: 'row', marginHorizontal: Spacing.base, backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: Radius.lg, padding: Spacing.sm },
  sensorItem: { flex: 1, alignItems: 'center', gap: 3 },
  sensorValue: { fontSize: Typography.sm, fontWeight: '700', color: '#fff' },
  sensorLabel: { fontSize: 10, color: 'rgba(255,255,255,0.7)' },
  quickActions: { flexDirection: 'row', paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border },
  quickActionsDark: { backgroundColor: Colors.darkSurface, borderBottomColor: Colors.darkBorder },
  quickActionBtn: { flex: 1, alignItems: 'center', gap: 4 },
  quickActionIcon: { width: 44, height: 44, borderRadius: 12, backgroundColor: '#E8F5E9', alignItems: 'center', justifyContent: 'center' },
  quickActionLabel: { fontSize: 10, color: Colors.textSecondary, fontWeight: '600' },
  tabBar: { flexDirection: 'row', backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border },
  tabBarDark: { backgroundColor: Colors.darkSurface, borderBottomColor: Colors.darkBorder },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 12, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: Colors.primary },
  tabText: { fontSize: Typography.xs, fontWeight: '600', color: Colors.textMuted },
  tabTextActive: { color: Colors.primary },
  tabContent: { flex: 1, padding: Spacing.base },
  tabSectionTitle: { fontSize: Typography.md, fontWeight: '700', color: Colors.text, marginBottom: Spacing.md },
  vitalsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  vitalItem: { flex: 1, minWidth: '45%', alignItems: 'center', padding: Spacing.md, borderRadius: Radius.md, gap: 4 },
  vitalValue: { fontSize: Typography.base, fontWeight: '700' },
  vitalLabel: { fontSize: Typography.xs, color: Colors.textMuted },
  symptomGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  symptomChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 7, borderRadius: Radius.round, backgroundColor: Colors.surfaceSecondary, borderWidth: 1, borderColor: Colors.border },
  symptomChipActive: { backgroundColor: '#FFEBEE', borderColor: Colors.dangerLight },
  symptomChipDark: { backgroundColor: Colors.darkSurfaceSecondary, borderColor: Colors.darkBorder },
  symptomText: { fontSize: Typography.xs, color: Colors.textSecondary, fontWeight: '500' },
  vetNotes: { fontSize: Typography.base, color: Colors.textSecondary, lineHeight: 22 },
  recordRow: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md },
  recordRowDark: {},
  recordDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: Colors.primary, marginTop: 4 },
  recordInfo: { flex: 1 },
  recordType: { fontSize: Typography.base, fontWeight: '600', color: Colors.text },
  recordMeta: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 2 },
  recordNotes: { fontSize: Typography.sm, color: Colors.textSecondary, marginTop: 4 },
  milkStatsRow: { flexDirection: 'row', gap: Spacing.sm },
  milkStatCard: { flex: 1, alignItems: 'center', paddingVertical: Spacing.md },
  milkStatValue: { fontSize: Typography.xl, fontWeight: '800' },
  milkStatLabel: { fontSize: Typography.xs, color: Colors.textMuted },
  chart: { borderRadius: Radius.lg, marginTop: Spacing.md },
  milkLogRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border, gap: Spacing.md },
  milkLogRowDark: { borderBottomColor: Colors.darkBorder },
  milkLogDate: { fontSize: Typography.xs, color: Colors.textSecondary, width: 80 },
  milkLogValues: { flex: 1, flexDirection: 'row', gap: 12 },
  milkLogItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  milkLogValue: { fontSize: Typography.sm, fontWeight: '600', color: Colors.text },
  milkLogTotal: { fontSize: Typography.sm, fontWeight: '800', color: Colors.text },
  qualityBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.sm },
  reproStatusRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
  reproBadge: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: Radius.round },
  reproBadgeText: { fontSize: Typography.xs, fontWeight: '700' },
  deliveryCountdown: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, backgroundColor: '#E3F2FD', borderRadius: Radius.lg, padding: Spacing.md, marginBottom: Spacing.md },
  deliveryDays: { fontSize: Typography.xl, fontWeight: '800' },
  deliveryLabel: { fontSize: Typography.xs, color: Colors.textSecondary },
  reproInfoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  reproInfoItem: { width: '48%' },
  reproInfoLabel: { fontSize: Typography.xs, color: Colors.textMuted, marginBottom: 2 },
  reproInfoValue: { fontSize: Typography.sm, fontWeight: '600', color: Colors.text },
  breedRow: { flexDirection: 'row', gap: Spacing.md, marginBottom: Spacing.md },
  breedRowDark: {},
  breedDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: Colors.accent, marginTop: 4 },
  breedSire: { fontSize: Typography.base, fontWeight: '600', color: Colors.text },
  breedMeta: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 2 },
  breedResult: { fontSize: Typography.xs, fontWeight: '500', marginTop: 3 },
  offspringRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, backgroundColor: '#FFF8E1', borderRadius: Radius.md, padding: Spacing.md },
  offspringTag: { fontSize: Typography.base, fontWeight: '600', color: Colors.text },
  offspringMeta: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 2 },
  vacCard: { marginBottom: 0 },
  vacHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm },
  vacName: { fontSize: Typography.md, fontWeight: '700', color: Colors.text },
  vacStatusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.round },
  vacStatusText: { fontSize: Typography.xs, fontWeight: '700' },
  vacDetails: { gap: 6, marginBottom: Spacing.md },
  vacDetailItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  vacDetailText: { fontSize: Typography.sm, color: Colors.textSecondary },
  markDoneBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.md, backgroundColor: '#E8F5E9', borderWidth: 1, borderColor: Colors.primaryLight },
  markDoneText: { fontSize: Typography.xs, color: Colors.primary, fontWeight: '700' },
  addVacBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: Spacing.md, borderRadius: Radius.lg, borderWidth: 2, borderColor: Colors.primary, borderStyle: 'dashed' },
  addVacBtnDark: { borderColor: Colors.darkBorder },
  addVacText: { fontSize: Typography.base, color: Colors.primary, fontWeight: '600' },
  noData: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  noDataText: { fontSize: Typography.base, color: Colors.textSecondary },
  infoLight: '#29B6F6',
});
