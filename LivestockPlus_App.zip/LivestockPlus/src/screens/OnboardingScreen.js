import React, { useRef, useState } from 'react';
import {
  View, Text, StyleSheet, Dimensions, FlatList,
  TouchableOpacity, Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../context/AppContext';
import { Colors, Typography, Spacing, Radius } from '../utils/theme';

const { width, height } = Dimensions.get('window');

const SLIDES = [
  {
    id: '1',
    icon: 'barn',
    title: 'Welcome to\nLiveStock+',
    subtitle: 'Your intelligent farm companion. Monitor, manage, and improve your livestock health with real-time data.',
    gradient: [Colors.primaryDark, Colors.primary],
    iconBg: '#fff',
    iconColor: Colors.primary,
  },
  {
    id: '2',
    icon: 'access-point-network',
    title: 'Connect\nSmart Sensors',
    subtitle: 'Attach IoT sensors to monitor temperature, GPS location, milk production, and daily activity of every animal.',
    gradient: ['#1565C0', '#1976D2'],
    iconBg: '#fff',
    iconColor: '#1976D2',
  },
  {
    id: '3',
    icon: 'chart-line',
    title: 'Monitor\nYour Herd',
    subtitle: 'Get instant alerts, track health trends, manage vaccinations, and generate reports — all from your phone.',
    gradient: [Colors.accentLight, Colors.accent],
    iconBg: '#fff',
    iconColor: Colors.accent,
  },
];

export default function OnboardingScreen({ navigation }) {
  const { completeOnboarding } = useApp();
  const [currentIdx, setCurrentIdx] = useState(0);
  const flatRef = useRef(null);
  const scrollX = useRef(new Animated.Value(0)).current;

  const handleNext = () => {
    if (currentIdx < SLIDES.length - 1) {
      flatRef.current?.scrollToIndex({ index: currentIdx + 1 });
      setCurrentIdx(currentIdx + 1);
    } else {
      handleGetStarted();
    }
  };

  const handleGetStarted = async () => {
    await completeOnboarding();
    navigation.replace('Auth');
  };

  const renderSlide = ({ item, index }) => (
    <LinearGradient
      colors={item.gradient}
      style={styles.slide}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.5, y: 1 }}
    >
      {/* Background decoration */}
      <View style={styles.bgDecoration} />
      <View style={styles.bgDecoration2} />

      {/* Icon */}
      <View style={[styles.iconContainer, { backgroundColor: item.iconBg }]}>
        <MaterialCommunityIcons name={item.icon} size={80} color={item.iconColor} />
      </View>

      {/* Text */}
      <View style={styles.textContainer}>
        <Text style={styles.slideTitle}>{item.title}</Text>
        <Text style={styles.slideSubtitle}>{item.subtitle}</Text>
      </View>

      {/* Features list for slide 1 */}
      {index === 0 && (
        <View style={styles.featureList}>
          {['Real-time health monitoring', 'Smart alert system', 'Vaccination scheduling', 'Milk production tracking'].map((f, i) => (
            <View key={i} style={styles.featureItem}>
              <MaterialCommunityIcons name="check-circle" size={18} color="rgba(255,255,255,0.9)" />
              <Text style={styles.featureText}>{f}</Text>
            </View>
          ))}
        </View>
      )}
    </LinearGradient>
  );

  return (
    <View style={styles.container}>
      <FlatList
        ref={flatRef}
        data={SLIDES}
        renderItem={renderSlide}
        keyExtractor={i => i.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: scrollX } } }], { useNativeDriver: false })}
        onMomentumScrollEnd={e => {
          setCurrentIdx(Math.round(e.nativeEvent.contentOffset.x / width));
        }}
      />

      {/* Controls */}
      <View style={styles.controls}>
        {/* Dots */}
        <View style={styles.dots}>
          {SLIDES.map((_, i) => {
            const inputRange = [(i - 1) * width, i * width, (i + 1) * width];
            const dotWidth = scrollX.interpolate({
              inputRange,
              outputRange: [8, 24, 8],
              extrapolate: 'clamp',
            });
            const opacity = scrollX.interpolate({
              inputRange,
              outputRange: [0.4, 1, 0.4],
              extrapolate: 'clamp',
            });
            return (
              <Animated.View
                key={i}
                style={[styles.dot, { width: dotWidth, opacity }]}
              />
            );
          })}
        </View>

        {/* Buttons */}
        <View style={styles.buttonRow}>
          <TouchableOpacity onPress={handleGetStarted} activeOpacity={0.7}>
            <Text style={styles.skipText}>Skip</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleNext} activeOpacity={0.85} style={styles.nextBtn}>
            <Text style={styles.nextBtnText}>
              {currentIdx === SLIDES.length - 1 ? 'Get Started' : 'Next'}
            </Text>
            <MaterialCommunityIcons name="arrow-right" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primaryDark,
  },
  slide: {
    width,
    height: height * 0.85,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  bgDecoration: {
    position: 'absolute',
    width: width * 1.2,
    height: width * 1.2,
    borderRadius: width * 0.6,
    backgroundColor: 'rgba(255,255,255,0.06)',
    top: -width * 0.4,
    right: -width * 0.3,
  },
  bgDecoration2: {
    position: 'absolute',
    width: width * 0.7,
    height: width * 0.7,
    borderRadius: width * 0.35,
    backgroundColor: 'rgba(0,0,0,0.06)',
    bottom: 0,
    left: -width * 0.2,
  },
  iconContainer: {
    width: 160,
    height: 160,
    borderRadius: 80,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 40,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
    elevation: 10,
  },
  textContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  slideTitle: {
    fontSize: 38,
    fontWeight: '800',
    color: '#fff',
    textAlign: 'center',
    lineHeight: 46,
    marginBottom: 16,
  },
  slideSubtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    lineHeight: 26,
    fontWeight: '400',
  },
  featureList: {
    gap: 12,
    alignSelf: 'stretch',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 20,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  featureText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 15,
    fontWeight: '500',
  },
  controls: {
    flex: 1,
    backgroundColor: Colors.primaryDark,
    paddingHorizontal: 28,
    paddingVertical: 20,
    justifyContent: 'space-between',
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    paddingTop: 8,
  },
  dot: {
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.7)',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  skipText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 16,
    fontWeight: '500',
  },
  nextBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.accent,
    paddingHorizontal: 28,
    paddingVertical: 14,
    borderRadius: 30,
    gap: 8,
  },
  nextBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
