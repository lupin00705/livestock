export const SPECIES = ['Cattle', 'Goat', 'Sheep'];
export const BREEDS = {
  Cattle: ['Holstein', 'Angus', 'Hereford', 'Jersey', 'Brahman'],
  Goat: ['Boer', 'Nubian', 'Alpine', 'Saanen', 'Kiko'],
  Sheep: ['Merino', 'Suffolk', 'Dorset', 'Romney', 'Rambouillet'],
};

const now = new Date();
const daysAgo = (d) => new Date(now - d * 86400000).toISOString();
const hoursAgo = (h) => new Date(now - h * 3600000).toISOString();

export const generateSensorReadings = (animalId, baseTemp = 38.5) => ({
  temperature: {
    id: `sensor-temp-${animalId}`,
    animalId,
    type: 'temperature',
    value: +(baseTemp + (Math.random() - 0.5) * 2).toFixed(1),
    unit: '°C',
    batteryLevel: Math.floor(60 + Math.random() * 40),
    signalStrength: Math.floor(50 + Math.random() * 50),
    lastSync: hoursAgo(Math.random() * 2),
    status: 'online',
    history: Array.from({ length: 24 }, (_, i) => ({
      time: hoursAgo(23 - i),
      value: +(baseTemp + (Math.random() - 0.5) * 1.5).toFixed(1),
    })),
  },
  gps: {
    id: `sensor-gps-${animalId}`,
    animalId,
    type: 'gps',
    value: { lat: 22.3 + Math.random() * 0.1, lng: 70.8 + Math.random() * 0.1 },
    unit: 'coords',
    batteryLevel: Math.floor(40 + Math.random() * 60),
    signalStrength: Math.floor(60 + Math.random() * 40),
    lastSync: hoursAgo(Math.random() * 1),
    status: 'online',
  },
  milk: {
    id: `sensor-milk-${animalId}`,
    animalId,
    type: 'milk',
    value: +(8 + Math.random() * 15).toFixed(1),
    unit: 'L/day',
    batteryLevel: Math.floor(70 + Math.random() * 30),
    signalStrength: Math.floor(55 + Math.random() * 45),
    lastSync: hoursAgo(Math.random() * 3),
    status: 'online',
    history: Array.from({ length: 7 }, (_, i) => ({
      day: daysAgo(6 - i),
      value: +(10 + Math.random() * 8).toFixed(1),
    })),
  },
  activity: {
    id: `sensor-activity-${animalId}`,
    animalId,
    type: 'activity',
    value: Math.floor(3000 + Math.random() * 5000),
    unit: 'steps',
    batteryLevel: Math.floor(50 + Math.random() * 50),
    signalStrength: Math.floor(65 + Math.random() * 35),
    lastSync: hoursAgo(Math.random() * 0.5),
    status: 'online',
  },
});

export const generateVaccinations = (animalId) => [
  {
    id: `vac-${animalId}-1`,
    name: 'FMD Vaccine',
    date: daysAgo(90),
    nextDue: daysAgo(-5), // 5 days from now
    administered: true,
    veterinarian: 'Dr. Patel',
    notes: 'Annual dose administered without complications.',
    status: 'upcoming',
  },
  {
    id: `vac-${animalId}-2`,
    name: 'Brucellosis',
    date: daysAgo(180),
    nextDue: daysAgo(10),
    administered: true,
    veterinarian: 'Dr. Sharma',
    notes: 'Routine vaccination completed.',
    status: 'overdue',
  },
  {
    id: `vac-${animalId}-3`,
    name: 'Anthrax Vaccine',
    date: daysAgo(365),
    nextDue: daysAgo(-60),
    administered: true,
    veterinarian: 'Dr. Patel',
    notes: 'Annual vaccination.',
    status: 'scheduled',
  },
];

export const generateHealth = (animalId) => ({
  currentStatus: ['healthy', 'healthy', 'healthy', 'warning', 'critical'][Math.floor(Math.random() * 5)],
  weight: Math.floor(200 + Math.random() * 400),
  bcs: +(2.5 + Math.random() * 2).toFixed(1),
  symptoms: [],
  vetNotes: 'Animal appears healthy. Regular monitoring recommended.',
  records: [
    {
      id: `hr-${animalId}-1`,
      date: daysAgo(30),
      type: 'Checkup',
      diagnosis: 'Healthy',
      treatment: 'None required',
      veterinarian: 'Dr. Patel',
      notes: 'Routine health checkup. All vitals normal.',
    },
    {
      id: `hr-${animalId}-2`,
      date: daysAgo(90),
      type: 'Treatment',
      diagnosis: 'Minor respiratory infection',
      treatment: 'Antibiotics for 5 days',
      veterinarian: 'Dr. Sharma',
      notes: 'Recovered fully after treatment.',
    },
  ],
});

export const generateMilk = (animalId) => ({
  currentDaily: +(10 + Math.random() * 12).toFixed(1),
  monthlyTotal: +(280 + Math.random() * 100).toFixed(0),
  avgDaily: +(10 + Math.random() * 8).toFixed(1),
  weeklyData: Array.from({ length: 7 }, (_, i) => ({
    day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
    morning: +(5 + Math.random() * 6).toFixed(1),
    evening: +(4 + Math.random() * 5).toFixed(1),
  })),
  logs: Array.from({ length: 7 }, (_, i) => ({
    id: `ml-${animalId}-${i}`,
    date: daysAgo(6 - i),
    morning: +(5 + Math.random() * 6).toFixed(1),
    evening: +(4 + Math.random() * 5).toFixed(1),
    quality: ['A', 'A', 'A', 'B', 'B'][Math.floor(Math.random() * 5)],
  })),
});

export const generateReproduction = (animalId, idx) => ({
  status: ['pregnant', 'open', 'lactating', 'dry'][idx % 4],
  lastHeat: daysAgo(21 + Math.floor(Math.random() * 10)),
  nextExpectedHeat: daysAgo(-(21 - Math.floor(Math.random() * 5))),
  pregnancyDate: idx % 4 === 0 ? daysAgo(180) : null,
  expectedDelivery: idx % 4 === 0 ? daysAgo(-100) : null,
  breedingLog: [
    {
      id: `br-${animalId}-1`,
      date: daysAgo(180),
      sire: 'Bull #A-001',
      method: 'Natural',
      result: 'Confirmed pregnant',
    },
    {
      id: `br-${animalId}-2`,
      date: daysAgo(400),
      sire: 'Bull #B-003',
      method: 'AI',
      result: 'Not pregnant',
    },
  ],
  offspring: [
    {
      id: `off-${animalId}-1`,
      dob: daysAgo(365),
      sex: 'Female',
      weight: '28 kg',
      tagNumber: `TAG-${1000 + idx}`,
    },
  ],
  heatCalendar: Array.from({ length: 3 }, (_, i) => ({
    date: daysAgo(21 * (i + 1)),
    intensity: ['high', 'medium', 'high'][i],
  })),
});

const avatarColors = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#F44336', '#00BCD4', '#8BC34A', '#FF5722', '#607D8B', '#795548'];

export const SAMPLE_ANIMALS = Array.from({ length: 10 }, (_, i) => {
  const species = SPECIES[i % 3];
  const breeds = BREEDS[species];
  const breed = breeds[i % breeds.length];
  const statuses = ['healthy', 'healthy', 'healthy', 'warning', 'critical', 'healthy', 'healthy', 'offline', 'healthy', 'warning'];
  const baseTemps = [38.2, 38.6, 39.1, 39.8, 40.2, 38.4, 38.7, 38.3, 39.0, 39.6];
  const names = ['Bella', 'Daisy', 'Rosie', 'Molly', 'Bessie', 'Lola', 'Nala', 'Stella', 'Ruby', 'Luna'];

  return {
    id: `animal-${i + 1}`,
    name: names[i],
    species,
    breed,
    age: `${1 + (i % 7)} years`,
    weight: Math.floor(150 + Math.random() * 350),
    tagNumber: `TAG-${String(100 + i).padStart(4, '0')}`,
    photo: null,
    avatarColor: avatarColors[i],
    status: statuses[i],
    sensors: generateSensorReadings(`animal-${i + 1}`, baseTemps[i]),
    health: generateHealth(`animal-${i + 1}`),
    milk: species === 'Cattle' || species === 'Goat' ? generateMilk(`animal-${i + 1}`) : null,
    reproduction: generateReproduction(`animal-${i + 1}`, i),
    vaccinations: generateVaccinations(`animal-${i + 1}`),
  };
});

export const SAMPLE_ALERTS = [
  {
    id: 'alert-1',
    animalId: 'animal-5',
    animalName: 'Bessie',
    type: 'critical',
    title: 'High Temperature Alert',
    message: 'Bessie\'s temperature has exceeded 40.2°C, which is above the critical threshold of 39.5°C.',
    timestamp: hoursAgo(0.5),
    resolved: false,
    icon: 'thermometer-alert',
  },
  {
    id: 'alert-2',
    animalId: 'animal-10',
    animalName: 'Luna',
    type: 'warning',
    title: 'Elevated Temperature',
    message: 'Luna\'s temperature is 39.6°C, approaching the critical threshold.',
    timestamp: hoursAgo(1.5),
    resolved: false,
    icon: 'thermometer',
  },
  {
    id: 'alert-3',
    animalId: 'animal-2',
    animalName: 'Daisy',
    type: 'warning',
    title: 'Vaccination Due',
    message: 'Daisy\'s Brucellosis vaccination was due 10 days ago. Please schedule immediately.',
    timestamp: hoursAgo(3),
    resolved: false,
    icon: 'needle',
  },
  {
    id: 'alert-4',
    animalId: 'animal-8',
    animalName: 'Stella',
    type: 'normal',
    title: 'Sensor Offline',
    message: 'Stella\'s temperature sensor has gone offline. Last reading: 38.3°C.',
    timestamp: hoursAgo(6),
    resolved: false,
    icon: 'wifi-off',
  },
  {
    id: 'alert-5',
    animalId: 'animal-4',
    animalName: 'Molly',
    type: 'warning',
    title: 'Milk Production Drop',
    message: 'Molly\'s milk production has dropped by 25% below her 7-day average.',
    timestamp: hoursAgo(12),
    resolved: true,
    icon: 'water-minus',
  },
  {
    id: 'alert-6',
    animalId: 'animal-1',
    animalName: 'Bella',
    type: 'normal',
    title: 'Heat Cycle Detected',
    message: 'Bella is showing signs of heat. Consider scheduling for breeding.',
    timestamp: hoursAgo(18),
    resolved: true,
    icon: 'heart-pulse',
  },
];

export const FARM_STATS = {
  name: 'Green Valley Farm',
  owner: 'Rajesh Kumar',
  location: 'Anand, Gujarat',
  totalAnimals: 10,
  cattle: 4,
  goats: 3,
  sheep: 3,
  criticalAlerts: 1,
  warningAlerts: 3,
  normalAlerts: 2,
  offlineAnimals: 1,
  avgTemperature: 38.8,
  totalMilkToday: 85.4,
  totalAlerts: 6,
};
