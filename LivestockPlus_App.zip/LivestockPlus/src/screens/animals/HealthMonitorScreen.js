import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader, PrimaryButton, StatusBadge } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

const SYMPTOMS = [
  'Lethargy', 'Loss of appetite', 'Nasal discharge', 'Limping',
  'Coughing', 'Diarrhea', 'Eye discharge', 'Labored breathing',
  'Fever', 'Bloating', 'Skin lesions', 'Abnormal posture',
];

export default function HealthMonitorScreen({ route, navigation }) {
  const { animalId } = route.params || {};
  const { state, dispatch } = useApp();
  const dark = state.darkMode;
  const animal = state.animals.find(a => a.id === animalId) || state.animals[0];

  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [vetNotes, setVetNotes] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newRecord, setNewRecord] = useState({ type: 'Checkup', diagnosis: '', treatment: '', notes: '', veterinarian: '' });

  const toggleSymptom = (s) => {
    setSelectedSymptoms(prev =>
      prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]
    );
  };

  const handleAddRecord = () => {
    if (!newRecord.diagnosis) {
      Alert.alert('Required', 'Please enter a diagnosis');
      return;
    }
    dispatch({
      type: 'ADD_HEALTH_RECORD',
      payload: {
        animalId: animal.id,
        record: {
          id: `hr-${Date.now()}`,
          date: new Date().toISOString(),
          ...newRecord,
        },
      },
    });
    setShowAddModal(false);
    setNewRecord({ type: 'Checkup', diagnosis: '', treatment: '', notes: '', veterinarian: '' });
    Alert.alert('Success', 'Health record added successfully');
  };

  const recordTypes = ['Checkup', 'Treatment', 'Surgery', 'Emergency', 'Vaccination'];

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader
        title="Health Monitor"
        subtitle={animal?.name}
        onBack={() => navigation.goBack()}
        dark={dark}
        rightComponent={
          <TouchableOpacity onPress={() => setShowAddModal(true)} style={styles.addBtn}>
            <MaterialCommunityIcons name="plus" size={20} color={Colors.primary} />
          </TouchableOpacity>
        }
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Current Status */}
        <Card dark={dark}>
          <View style={styles.statusRow}>
            <View>
              <Text style={[styles.sectionTitle, dark && { color: Colors.darkText }]}>Health Status</Text>
              <Text style={[styles.animalName, dark && { color: Colors.darkText }]}>{animal?.name}</Text>
            </View>
            <StatusBadge status={animal?.status} />
          </View>
          <View style={styles.vitalsRow}>
            {[
              { label: 'Weight', value: `${animal?.health?.weight} kg`, icon: 'weight-kilogram', color: Colors.primary },
              { label: 'BCS', value: animal?.health?.bcs, icon: 'chart-arc', color: Colors.accent },
              { label: 'Temp', value: `${animal?.sensors?.temperature?.value}°C`, icon: 'thermometer', color: Colors.danger },
            ].map(v => (
              <View key={v.label} style={[styles.vitalBox, { backgroundColor: v.color + '15' }]}>
                <MaterialCommunityIcons name={v.icon} size={20} color={v.color} />
                <Text style={[styles.vitalValue, { color: v.color }]}>{v.value}</Text>
                <Text style={[styles.vitalLabel, dark && { color: Colors.darkTextMuted }]}>{v.label}</Text>
              </View>
            ))}
          </View>
        </Card>

        {/* Symptom Checklist */}
        <Card dark={dark}>
          <Text style={[styles.sectionTitle, dark && { color: Colors.darkText }]}>Symptom Checklist</Text>
          <Text style={[styles.sectionSubtitle, dark && { color: Colors.darkTextSecondary }]}>
            Select any observed symptoms:
          </Text>
          <View style={styles.symptomGrid}>
            {SYMPTOMS.map(s => {
              const active = selectedSymptoms.includes(s);
              return (
                <TouchableOpacity
                  key={s}
                  onPress={() => toggleSymptom(s)}
                  activeOpacity={0.8}
                  style={[styles.symptomChip, active && styles.symptomChipActive, dark && !active && styles.symptomChipDark]}
                >
                  <MaterialCommunityIcons
                    name={active ? 'checkbox-marked' : 'checkbox-blank-outline'}
                    size={16}
                    color={active ? '#fff' : dark ? Colors.darkTextMuted : Colors.textMuted}
                  />
                  <Text style={[styles.symptomText, active && styles.symptomTextActive, dark && !active && { color: Colors.darkTextSecondary }]}>
                    {s}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
          {selectedSymptoms.length > 0 && (
            <View style={styles.symptomAlert}>
              <MaterialCommunityIcons name="alert" size={16} color={Colors.warning} />
              <Text style={styles.symptomAlertText}>
                {selectedSymptoms.length} symptom(s) selected. Consider contacting a veterinarian.
              </Text>
            </View>
          )}
        </Card>

        {/* Vet Notes */}
        <Card dark={dark}>
          <Text style={[styles.sectionTitle, dark && { color: Colors.darkText }]}>Vet Notes</Text>
          <TextInput
            value={vetNotes || animal?.health?.vetNotes}
            onChangeText={setVetNotes}
            placeholder="Enter veterinarian notes..."
            placeholderTextColor={dark ? Colors.darkTextMuted : Colors.placeholder}
            style={[styles.notesInput, dark && styles.notesInputDark]}
            multiline
            numberOfLines={4}
            textAlignVertical="top"
          />
          <TouchableOpacity style={styles.saveNotesBtn} activeOpacity={0.85}>
            <MaterialCommunityIcons name="content-save" size={16} color="#fff" />
            <Text style={styles.saveNotesBtnText}>Save Notes</Text>
          </TouchableOpacity>
        </Card>

        {/* Diagnosis History */}
        <Text style={[styles.historyTitle, dark && { color: Colors.darkText }]}>Diagnosis History</Text>
        {animal?.health?.records.map(r => (
          <Card key={r.id} dark={dark} style={styles.historyCard}>
            <View style={styles.historyHeader}>
              <View style={[styles.historyTypeBadge, { backgroundColor: r.type === 'Treatment' ? '#FFF3E0' : '#E8F5E9' }]}>
                <Text style={[styles.historyTypeText, { color: r.type === 'Treatment' ? Colors.warning : Colors.success }]}>
                  {r.type}
                </Text>
              </View>
              <Text style={[styles.historyDate, dark && { color: Colors.darkTextMuted }]}>
                {new Date(r.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
              </Text>
            </View>
            <Text style={[styles.historyDiagnosis, dark && { color: Colors.darkText }]}>
              Diagnosis: {r.diagnosis}
            </Text>
            <Text style={[styles.historyTreatment, dark && { color: Colors.darkTextSecondary }]}>
              Treatment: {r.treatment}
            </Text>
            <Text style={[styles.historyVet, dark && { color: Colors.darkTextMuted }]}>
              {r.veterinarian} • {r.notes}
            </Text>
          </Card>
        ))}
      </ScrollView>

      {/* Add Record Modal */}
      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, dark && styles.modalSheetDark]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, dark && { color: Colors.darkText }]}>Add Health Record</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <MaterialCommunityIcons name="close" size={24} color={dark ? Colors.darkTextSecondary : Colors.textSecondary} />
              </TouchableOpacity>
            </View>

            {/* Type selector */}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: Spacing.md }} contentContainerStyle={{ gap: 8 }}>
              {recordTypes.map(t => (
                <TouchableOpacity key={t} onPress={() => setNewRecord(r => ({ ...r, type: t }))}
                  style={[styles.typeChip, newRecord.type === t && styles.typeChipActive]}>
                  <Text style={[styles.typeChipText, newRecord.type === t && styles.typeChipTextActive]}>{t}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {[
              { key: 'diagnosis', label: 'Diagnosis *', placeholder: 'e.g. Respiratory infection' },
              { key: 'treatment', label: 'Treatment', placeholder: 'e.g. Antibiotics for 5 days' },
              { key: 'veterinarian', label: 'Veterinarian', placeholder: 'Dr. Name' },
              { key: 'notes', label: 'Notes', placeholder: 'Additional notes...', multiline: true },
            ].map(f => (
              <View key={f.key} style={styles.modalField}>
                <Text style={[styles.modalLabel, dark && { color: Colors.darkTextSecondary }]}>{f.label}</Text>
                <TextInput
                  value={newRecord[f.key]}
                  onChangeText={v => setNewRecord(r => ({ ...r, [f.key]: v }))}
                  placeholder={f.placeholder}
                  placeholderTextColor={dark ? Colors.darkTextMuted : Colors.placeholder}
                  style={[styles.modalInput, dark && styles.modalInputDark, f.multiline && { height: 80 }]}
                  multiline={f.multiline}
                  textAlignVertical={f.multiline ? 'top' : 'center'}
                />
              </View>
            ))}

            <PrimaryButton title="Save Record" onPress={handleAddRecord} icon="content-save" />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  content: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 40 },
  addBtn: { padding: 8, backgroundColor: '#E8F5E9', borderRadius: Radius.md },
  statusRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.md },
  sectionTitle: { fontSize: Typography.md, fontWeight: '700', color: Colors.text, marginBottom: Spacing.sm },
  sectionSubtitle: { fontSize: Typography.sm, color: Colors.textSecondary, marginBottom: Spacing.md },
  animalName: { fontSize: Typography.xl, fontWeight: '800', color: Colors.text },
  vitalsRow: { flexDirection: 'row', gap: Spacing.sm },
  vitalBox: { flex: 1, alignItems: 'center', padding: Spacing.md, borderRadius: Radius.md, gap: 4 },
  vitalValue: { fontSize: Typography.base, fontWeight: '800' },
  vitalLabel: { fontSize: Typography.xs, color: Colors.textMuted },
  symptomGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  symptomChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.round, backgroundColor: Colors.surfaceSecondary, borderWidth: 1, borderColor: Colors.border },
  symptomChipActive: { backgroundColor: Colors.danger, borderColor: Colors.danger },
  symptomChipDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  symptomText: { fontSize: Typography.xs, color: Colors.textSecondary, fontWeight: '500' },
  symptomTextActive: { color: '#fff' },
  symptomAlert: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: Spacing.md, padding: Spacing.sm, backgroundColor: '#FFF3E0', borderRadius: Radius.md },
  symptomAlertText: { flex: 1, fontSize: Typography.xs, color: Colors.warning, fontWeight: '500' },
  notesInput: { backgroundColor: Colors.surfaceSecondary, borderRadius: Radius.md, padding: Spacing.md, fontSize: Typography.base, color: Colors.text, borderWidth: 1, borderColor: Colors.border, minHeight: 100 },
  notesInputDark: { backgroundColor: Colors.darkSurfaceSecondary, color: Colors.darkText, borderColor: Colors.darkBorder },
  saveNotesBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, alignSelf: 'flex-end', marginTop: Spacing.md, backgroundColor: Colors.primary, paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.round },
  saveNotesBtnText: { color: '#fff', fontWeight: '700', fontSize: Typography.sm },
  historyTitle: { fontSize: Typography.lg, fontWeight: '700', color: Colors.text, marginTop: Spacing.sm },
  historyCard: {},
  historyHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginBottom: Spacing.sm },
  historyTypeBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.round },
  historyTypeText: { fontSize: Typography.xs, fontWeight: '700' },
  historyDate: { fontSize: Typography.xs, color: Colors.textMuted, marginLeft: 'auto' },
  historyDiagnosis: { fontSize: Typography.base, fontWeight: '600', color: Colors.text, marginBottom: 4 },
  historyTreatment: { fontSize: Typography.sm, color: Colors.textSecondary, marginBottom: 4 },
  historyVet: { fontSize: Typography.xs, color: Colors.textMuted },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalSheet: { backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: Spacing.xl, maxHeight: '90%' },
  modalSheetDark: { backgroundColor: Colors.darkSurface },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.lg },
  modalTitle: { fontSize: Typography.lg, fontWeight: '700', color: Colors.text },
  typeChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: Radius.round, backgroundColor: Colors.surfaceSecondary, borderWidth: 1, borderColor: Colors.border },
  typeChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  typeChipText: { fontSize: Typography.sm, color: Colors.textSecondary, fontWeight: '600' },
  typeChipTextActive: { color: '#fff' },
  modalField: { marginBottom: Spacing.md },
  modalLabel: { fontSize: Typography.xs, fontWeight: '600', color: Colors.textSecondary, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.4 },
  modalInput: { backgroundColor: Colors.surfaceSecondary, borderRadius: Radius.md, padding: Spacing.md, fontSize: Typography.base, color: Colors.text, borderWidth: 1, borderColor: Colors.border },
  modalInputDark: { backgroundColor: Colors.darkSurfaceSecondary, color: Colors.darkText, borderColor: Colors.darkBorder },
});
