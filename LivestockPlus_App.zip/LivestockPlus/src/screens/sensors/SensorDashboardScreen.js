import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader, AnimalAvatar } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

const { width } = Dimensions.get('window');

const SENSOR_TYPES = [
  { key: 'temperature', label: 'Temperature', icon: 'thermometer', unit: '°C', color: Colors.danger },
  { key: 'gps', label: 'GPS', icon: 'map-marker', unit: 'coords', color: Colors.info },
  { key: 'milk', label: 'Milk Flow', icon: 'water', unit: 'L/day', color: Colors.accent },
  { key: 'activity', label: 'Activity', icon: 'run', unit: 'steps', color: Colors.success },
];

function BatteryBar({ level, dark }) {
  const color = level > 60 ? Colors.success : level > 30 ? Colors.warning : Colors.danger;
  return (
    <View style={styles.batteryContainer}>
      <View style={[styles.batteryBar, dark && styles.batteryBarDark]}>
        <View style={[styles.batteryFill, { width: `${level}%`, backgroundColor: color }]} />
      </View>
      <Text style={[styles.batteryText, { color }, dark && {}]}>{level}%</Text>
    </View>
  );
}

function SignalStrength({ strength }) {
  const bars = [25, 50, 75, 100];
  return (
    <View style={styles.signalContainer}>
      {bars.map((threshold, i) => (
        <View key={i} style={[
          styles.signalBar,
          { height: 4 + i * 3 },
          strength >= threshold ? { backgroundColor: Colors.success } : { backgroundColor: Colors.border },
        ]} />
      ))}
    </View>
  );
}

function SensorCard({ animal, sensorType, dark, onPress }) {
  const sensor = animal.sensors?.[sensorType.key];
  if (!sensor) return null;

  const value = sensorType.key === 'gps'
    ? `${sensor.value?.lat?.toFixed(4)}, ${sensor.value?.lng?.toFixed(4)}`
    : sensorType.key === 'activity'
    ? sensor.value?.toLocaleString()
    : sensor.value;

  const isOnline = sensor.status === 'online';

  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85}>
      <View style={[styles.sensorCard, dark && styles.sensorCardDark, !isOnline && styles.sensorCardOffline]}>
        {/* Header */}
        <View style={styles.sensorCardHeader}>
          <View style={[styles.sensorIcon, { backgroundColor: (isOnline ? sensorType.color : Colors.statusOffline) + '20' }]}>
            <MaterialCommunityIcons name={sensorType.icon} size={20} color={isOnline ? sensorType.color : Colors.statusOffline} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.sensorAnimalName, dark && { color: Colors.darkText }]}>{animal.name}</Text>
            <Text style={[styles.sensorType, dark && { color: Colors.darkTextMuted }]}>{sensorType.label}</Text>
          </View>
          <View style={[styles.onlineDot, { backgroundColor: isOnline ? Colors.statusHealthy : Colors.statusOffline }]} />
        </View>

        {/* Value */}
        <Text style={[styles.sensorValue, { color: isOnline ? sensorType.color : Colors.statusOffline }]} numberOfLines={1}>
          {isOnline ? value : 'Offline'}
          {isOnline && sensorType.key !== 'gps' && sensorType.key !== 'activity' && (
            <Text style={styles.sensorUnit}> {sensorType.unit}</Text>
          )}
        </Text>

        {/* Battery & Signal */}
        <View style={styles.sensorMeta}>
          <BatteryBar level={sensor.batteryLevel} dark={dark} />
          <SignalStrength strength={sensor.signalStrength} />
        </View>

        {/* Last sync */}
        <Text style={[styles.lastSync, dark && { color: Colors.darkTextMuted }]}>
          Sync: {new Date(sensor.lastSync).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

export default function SensorDashboardScreen({ navigation }) {
  const { state } = useApp();
  const dark = state.darkMode;
  const [activeType, setActiveType] = useState('temperature');
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = async () => {
    setRefreshing(true);
    await new Promise(r => setTimeout(r, 1200));
    setRefreshing(false);
  };

  const selectedSensorType = SENSOR_TYPES.find(t => t.key === activeType) || SENSOR_TYPES[0];

  const totalOnline = state.animals.filter(a => a.sensors?.[activeType]?.status === 'online').length;
  const totalOffline = state.animals.length - totalOnline;
  const avgBattery = Math.round(
    state.animals.reduce((sum, a) => sum + (a.sensors?.[activeType]?.batteryLevel || 0), 0) / state.animals.length
  );

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader
        title="Sensor Dashboard"
        subtitle={`${state.animals.length} animals monitored`}
        dark={dark}
        rightComponent={
          <TouchableOpacity style={[styles.syncBtn, dark && { backgroundColor: Colors.darkSurfaceSecondary }]}>
            <MaterialCommunityIcons name="sync" size={20} color={Colors.primary} />
          </TouchableOpacity>
        }
      />

      {/* Sensor type tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.typeScroll} contentContainerStyle={{ gap: 8, paddingHorizontal: Spacing.base }}>
        {SENSOR_TYPES.map(t => (
          <TouchableOpacity
            key={t.key}
            onPress={() => setActiveType(t.key)}
            style={[styles.typeTab, activeType === t.key && { backgroundColor: t.color, borderColor: t.color }, dark && activeType !== t.key && styles.typeTabDark]}
            activeOpacity={0.8}
          >
            <MaterialCommunityIcons name={t.icon} size={16} color={activeType === t.key ? '#fff' : dark ? Colors.darkTextSecondary : Colors.textSecondary} />
            <Text style={[styles.typeTabText, activeType === t.key && styles.typeTabTextActive, dark && activeType !== t.key && { color: Colors.darkTextSecondary }]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Summary row */}
      <View style={[styles.summaryRow, dark && styles.summaryRowDark]}>
        <View style={styles.summaryItem}>
          <MaterialCommunityIcons name="access-point" size={18} color={Colors.success} />
          <Text style={[styles.summaryValue, dark && { color: Colors.darkText }]}>{totalOnline}</Text>
          <Text style={[styles.summaryLabel, dark && { color: Colors.darkTextMuted }]}>Online</Text>
        </View>
        <View style={[styles.summaryDivider, dark && { backgroundColor: Colors.darkBorder }]} />
        <View style={styles.summaryItem}>
          <MaterialCommunityIcons name="wifi-off" size={18} color={Colors.statusOffline} />
          <Text style={[styles.summaryValue, dark && { color: Colors.darkText }]}>{totalOffline}</Text>
          <Text style={[styles.summaryLabel, dark && { color: Colors.darkTextMuted }]}>Offline</Text>
        </View>
        <View style={[styles.summaryDivider, dark && { backgroundColor: Colors.darkBorder }]} />
        <View style={styles.summaryItem}>
          <MaterialCommunityIcons name="battery" size={18} color={Colors.accent} />
          <Text style={[styles.summaryValue, dark && { color: Colors.darkText }]}>{avgBattery}%</Text>
          <Text style={[styles.summaryLabel, dark && { color: Colors.darkTextMuted }]}>Avg Battery</Text>
        </View>
        <View style={[styles.summaryDivider, dark && { backgroundColor: Colors.darkBorder }]} />
        <View style={styles.summaryItem}>
          <MaterialCommunityIcons name="antenna" size={18} color={Colors.primary} />
          <Text style={[styles.summaryValue, dark && { color: Colors.darkText }]}>{state.animals.length * 4}</Text>
          <Text style={[styles.summaryLabel, dark && { color: Colors.darkTextMuted }]}>Total</Text>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />}
        contentContainerStyle={styles.grid}
      >
        {state.animals.map(animal => (
          <SensorCard
            key={animal.id}
            animal={animal}
            sensorType={selectedSensorType}
            dark={dark}
            onPress={() => navigation.navigate('SensorDetail', { animalId: animal.id, sensorType: activeType })}
          />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  syncBtn: { padding: 8, backgroundColor: Colors.surfaceSecondary, borderRadius: Radius.md },
  typeScroll: { paddingVertical: Spacing.md },
  typeTab: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 16, paddingVertical: 9, borderRadius: Radius.round, backgroundColor: Colors.surfaceSecondary, borderWidth: 1.5, borderColor: Colors.border },
  typeTabDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  typeTabText: { fontSize: Typography.sm, color: Colors.textSecondary, fontWeight: '600' },
  typeTabTextActive: { color: '#fff' },
  summaryRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface, paddingVertical: Spacing.md, paddingHorizontal: Spacing.base, borderBottomWidth: 1, borderBottomColor: Colors.border },
  summaryRowDark: { backgroundColor: Colors.darkSurface, borderBottomColor: Colors.darkBorder },
  summaryItem: { flex: 1, alignItems: 'center', gap: 3 },
  summaryValue: { fontSize: Typography.xl, fontWeight: '800', color: Colors.text },
  summaryLabel: { fontSize: 10, color: Colors.textMuted, fontWeight: '500' },
  summaryDivider: { width: 1, height: 40, backgroundColor: Colors.border },
  grid: { padding: Spacing.base, gap: Spacing.sm, paddingBottom: 40 },
  sensorCard: { backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.md, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3 },
  sensorCardDark: { backgroundColor: Colors.darkSurface },
  sensorCardOffline: { opacity: 0.65 },
  sensorCardHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.sm },
  sensorIcon: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  sensorAnimalName: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text },
  sensorType: { fontSize: Typography.xs, color: Colors.textMuted },
  onlineDot: { width: 8, height: 8, borderRadius: 4 },
  sensorValue: { fontSize: Typography.xxl, fontWeight: '800', marginVertical: Spacing.sm },
  sensorUnit: { fontSize: Typography.sm, fontWeight: '400' },
  sensorMeta: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  batteryContainer: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  batteryBar: { width: 60, height: 6, backgroundColor: Colors.border, borderRadius: 3, overflow: 'hidden' },
  batteryBarDark: { backgroundColor: Colors.darkBorder },
  batteryFill: { height: '100%', borderRadius: 3 },
  batteryText: { fontSize: 10, fontWeight: '700' },
  signalContainer: { flexDirection: 'row', alignItems: 'flex-end', gap: 2 },
  signalBar: { width: 5, borderRadius: 2 },
  lastSync: { fontSize: 10, color: Colors.textMuted },
});
