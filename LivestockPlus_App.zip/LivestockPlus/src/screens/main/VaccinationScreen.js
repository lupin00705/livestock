import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader, AnimalAvatar, PrimaryButton, EmptyState, InputField } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

const FILTERS = ['All', 'Upcoming', 'Overdue', 'Scheduled', 'Done'];

export default function VaccinationScreen({ route, navigation }) {
  const { animalId } = route.params || {};
  const { state, dispatch } = useApp();
  const dark = state.darkMode;
  const [filter, setFilter] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newVac, setNewVac] = useState({ name: '', veterinarian: '', nextDue: '', notes: '' });

  // Flatten all vaccinations across animals
  const allVaccinations = state.animals
    .filter(a => !animalId || a.id === animalId)
    .flatMap(a =>
      a.vaccinations.map(v => ({ ...v, animal: a }))
    );

  const filtered = allVaccinations.filter(v => {
    if (filter === 'All') return true;
    if (filter === 'Done') return v.administered;
    return v.status === filter.toLowerCase();
  });

  const overdueCount = allVaccinations.filter(v => v.status === 'overdue').length;
  const upcomingCount = allVaccinations.filter(v => v.status === 'upcoming').length;

  const handleMarkDone = (animalId, vacId) => {
    Alert.alert('Mark as Done', 'Confirm this vaccination was administered?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Confirm', onPress: () => {
          dispatch({
            type: 'UPDATE_ANIMAL',
            payload: {
              id: animalId,
              vaccinations: state.animals.find(a => a.id === animalId)?.vaccinations.map(v =>
                v.id === vacId ? { ...v, administered: true, status: 'scheduled' } : v
              ),
            },
          });
          Alert.alert('Done!', 'Vaccination marked as administered.');
        },
      },
    ]);
  };

  const handleAddVaccination = () => {
    if (!newVac.name) { Alert.alert('Required', 'Please enter vaccine name'); return; }
    const targetAnimal = state.animals.find(a => a.id === animalId) || state.animals[0];
    dispatch({
      type: 'ADD_VACCINATION',
      payload: {
        animalId: targetAnimal.id,
        vaccination: {
          id: `vac-${Date.now()}`,
          name: newVac.name,
          date: new Date().toISOString(),
          nextDue: newVac.nextDue ? new Date(newVac.nextDue).toISOString() : new Date(Date.now() + 90 * 86400000).toISOString(),
          administered: false,
          veterinarian: newVac.veterinarian,
          notes: newVac.notes,
          status: 'scheduled',
        },
      },
    });
    setShowAddModal(false);
    setNewVac({ name: '', veterinarian: '', nextDue: '', notes: '' });
    Alert.alert('Added!', 'Vaccination scheduled.');
  };

  const statusConfig = {
    upcoming: { color: Colors.accent, bg: '#FFF8E1', icon: 'clock-outline', label: 'Upcoming' },
    overdue: { color: Colors.danger, bg: '#FFEBEE', icon: 'alert-circle', label: 'Overdue' },
    scheduled: { color: Colors.info, bg: '#E3F2FD', icon: 'calendar-check', label: 'Scheduled' },
  };

  const renderVaccination = ({ item: v }) => {
    const cfg = statusConfig[v.status] || statusConfig.scheduled;
    const daysUntil = Math.ceil((new Date(v.nextDue) - new Date()) / 86400000);

    return (
      <Card dark={dark} style={[styles.vacCard, v.status === 'overdue' && styles.vacCardOverdue]}>
        <View style={styles.vacTop}>
          <AnimalAvatar animal={v.animal} size={40} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.vacAnimalName, dark && { color: Colors.darkText }]}>{v.animal.name}</Text>
            <Text style={[styles.vacName, dark && { color: Colors.darkText }]}>{v.name}</Text>
          </View>
          <View style={[styles.vacStatusBadge, { backgroundColor: cfg.bg }]}>
            <MaterialCommunityIcons name={cfg.icon} size={14} color={cfg.color} />
            <Text style={[styles.vacStatusText, { color: cfg.color }]}>{cfg.label}</Text>
          </View>
        </View>

        <View style={styles.vacDetails}>
          <View style={styles.vacDetailRow}>
            <MaterialCommunityIcons name="calendar-check" size={14} color={Colors.success} />
            <Text style={[styles.vacDetailText, dark && { color: Colors.darkTextSecondary }]}>
              Last: {new Date(v.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
            </Text>
          </View>
          <View style={styles.vacDetailRow}>
            <MaterialCommunityIcons name="calendar-clock" size={14} color={cfg.color} />
            <Text style={[styles.vacDetailText, { color: cfg.color, fontWeight: '600' }]}>
              Due: {new Date(v.nextDue).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
              {daysUntil !== 0 && ` (${Math.abs(daysUntil)}d ${daysUntil > 0 ? 'remaining' : 'overdue'})`}
            </Text>
          </View>
          {v.veterinarian && (
            <View style={styles.vacDetailRow}>
              <MaterialCommunityIcons name="doctor" size={14} color={Colors.textMuted} />
              <Text style={[styles.vacDetailText, dark && { color: Colors.darkTextMuted }]}>{v.veterinarian}</Text>
            </View>
          )}
        </View>

        {!v.administered && (
          <TouchableOpacity
            onPress={() => handleMarkDone(v.animal.id, v.id)}
            style={styles.markDoneBtn}
            activeOpacity={0.85}
          >
            <MaterialCommunityIcons name="check-circle" size={16} color={Colors.success} />
            <Text style={styles.markDoneText}>Mark as Administered</Text>
          </TouchableOpacity>
        )}
        {v.administered && (
          <View style={styles.doneRow}>
            <MaterialCommunityIcons name="check-circle" size={16} color={Colors.success} />
            <Text style={styles.doneText}>Administered</Text>
          </View>
        )}
      </Card>
    );
  };

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader
        title="Vaccination Schedule"
        subtitle={`${overdueCount} overdue, ${upcomingCount} upcoming`}
        dark={dark}
        onBack={navigation.canGoBack?.() ? () => navigation.goBack() : undefined}
        onMenu={navigation.openDrawer ? () => navigation.openDrawer() : undefined}
        rightComponent={
          <TouchableOpacity onPress={() => setShowAddModal(true)} style={styles.addBtn}>
            <MaterialCommunityIcons name="plus" size={20} color="#fff" />
          </TouchableOpacity>
        }
      />

      {/* Summary */}
      {overdueCount > 0 && (
        <View style={styles.overdueAlert}>
          <MaterialCommunityIcons name="alert-circle" size={18} color="#fff" />
          <Text style={styles.overdueAlertText}>
            {overdueCount} vaccination(s) are overdue! Schedule immediately.
          </Text>
        </View>
      )}

      {/* Filters */}
      <View style={styles.filterRow}>
        {FILTERS.map(f => {
          const count = f === 'All' ? allVaccinations.length : f === 'Done' ? allVaccinations.filter(v => v.administered).length : allVaccinations.filter(v => v.status === f.toLowerCase()).length;
          return (
            <TouchableOpacity key={f} onPress={() => setFilter(f)} style={[styles.filterBtn, filter === f && styles.filterBtnActive, dark && filter !== f && styles.filterBtnDark]} activeOpacity={0.8}>
              <Text style={[styles.filterText, filter === f && styles.filterTextActive, dark && filter !== f && { color: Colors.darkTextSecondary }]}>{f}</Text>
              {count > 0 && <View style={[styles.filterCount, filter === f && { backgroundColor: 'rgba(255,255,255,0.25)' }]}><Text style={[styles.filterCountText, filter === f && { color: '#fff' }]}>{count}</Text></View>}
            </TouchableOpacity>
          );
        })}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={v => v.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={<EmptyState icon="needle-off" title="No vaccinations found" subtitle="Add a vaccination record to get started" dark={dark} />}
        renderItem={renderVaccination}
      />

      {/* Add Modal */}
      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.overlay}>
          <View style={[styles.sheet, dark && styles.sheetDark]}>
            <View style={styles.sheetHeader}>
              <Text style={[styles.sheetTitle, dark && { color: Colors.darkText }]}>Add Vaccination</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <MaterialCommunityIcons name="close" size={22} color={dark ? Colors.darkTextSecondary : Colors.textSecondary} />
              </TouchableOpacity>
            </View>
            <InputField label="Vaccine Name *" value={newVac.name} onChangeText={v => setNewVac(n => ({ ...n, name: v }))} placeholder="e.g. FMD Vaccine" icon="needle" dark={dark} autoCapitalize="words" />
            <InputField label="Veterinarian" value={newVac.veterinarian} onChangeText={v => setNewVac(n => ({ ...n, veterinarian: v }))} placeholder="Dr. Name" icon="doctor" dark={dark} autoCapitalize="words" />
            <InputField label="Next Due Date" value={newVac.nextDue} onChangeText={v => setNewVac(n => ({ ...n, nextDue: v }))} placeholder="DD/MM/YYYY" icon="calendar" dark={dark} />
            <InputField label="Notes" value={newVac.notes} onChangeText={v => setNewVac(n => ({ ...n, notes: v }))} placeholder="Additional notes..." icon="note" dark={dark} multiline numberOfLines={3} />
            <PrimaryButton title="Schedule Vaccination" onPress={handleAddVaccination} icon="calendar-check" />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  addBtn: { padding: 8, backgroundColor: Colors.primary, borderRadius: Radius.md },
  overdueAlert: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: Colors.danger, paddingHorizontal: Spacing.base, paddingVertical: 12 },
  overdueAlertText: { flex: 1, color: '#fff', fontSize: Typography.sm, fontWeight: '600' },
  filterRow: { flexDirection: 'row', gap: 6, paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm },
  filterBtn: { flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 4, paddingVertical: 7, borderRadius: Radius.round, backgroundColor: Colors.surfaceSecondary, borderWidth: 1, borderColor: Colors.border },
  filterBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterBtnDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  filterText: { fontSize: 10, color: Colors.textSecondary, fontWeight: '600' },
  filterTextActive: { color: '#fff' },
  filterCount: { backgroundColor: Colors.border, borderRadius: 8, paddingHorizontal: 5, paddingVertical: 1 },
  filterCountText: { fontSize: 9, color: Colors.textSecondary, fontWeight: '700' },
  list: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 40 },
  vacCard: {},
  vacCardOverdue: { borderWidth: 1, borderColor: Colors.dangerLight },
  vacTop: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginBottom: Spacing.sm },
  vacAnimalName: { fontSize: Typography.xs, color: Colors.textMuted, fontWeight: '500' },
  vacName: { fontSize: Typography.md, fontWeight: '700', color: Colors.text },
  vacStatusBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: Radius.round },
  vacStatusText: { fontSize: Typography.xs, fontWeight: '700' },
  vacDetails: { gap: 6, marginBottom: Spacing.md },
  vacDetailRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  vacDetailText: { fontSize: Typography.sm, color: Colors.textSecondary },
  markDoneBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#E8F5E9', borderRadius: Radius.md, paddingVertical: 10, borderWidth: 1, borderColor: Colors.primaryLight },
  markDoneText: { fontSize: Typography.sm, color: Colors.success, fontWeight: '700' },
  doneRow: { flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center' },
  doneText: { fontSize: Typography.sm, color: Colors.success, fontWeight: '600' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: Spacing.xl, maxHeight: '90%' },
  sheetDark: { backgroundColor: Colors.darkSurface },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.lg },
  sheetTitle: { fontSize: Typography.lg, fontWeight: '700', color: Colors.text },
});
