import React from 'react';
import { View, TouchableOpacity, Platform } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../context/AppContext';
import { Colors, Radius } from '../utils/theme';

// Screens
import DashboardScreen from '../screens/main/DashboardScreen';
import AnimalListScreen from '../screens/animals/AnimalListScreen';
import AnimalDetailScreen from '../screens/animals/AnimalDetailScreen';
import SensorDashboardScreen from '../screens/sensors/SensorDashboardScreen';
import SensorDetailScreen from '../screens/sensors/SensorDetailScreen';
import ReportsScreen from '../screens/main/ReportsScreen';
import SettingsScreen from '../screens/main/SettingsScreen';
import AlertsScreen from '../screens/main/AlertsScreen';
import VaccinationScreen from '../screens/main/VaccinationScreen';
import MilkProductionScreen from '../screens/main/MilkProductionScreen';
import ReproductionScreen from '../screens/main/ReproductionScreen';
import TemperatureMonitorScreen from '../screens/sensors/TemperatureMonitorScreen';
import HealthMonitorScreen from '../screens/animals/HealthMonitorScreen';

const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();
const AnimalStack = createNativeStackNavigator();
const SensorStack = createNativeStackNavigator();

function AnimalStackNavigator() {
  return (
    <AnimalStack.Navigator screenOptions={{ headerShown: false }}>
      <AnimalStack.Screen name="AnimalList" component={AnimalListScreen} />
      <AnimalStack.Screen name="AnimalDetail" component={AnimalDetailScreen} />
      <AnimalStack.Screen name="HealthMonitor" component={HealthMonitorScreen} />
      <AnimalStack.Screen name="TemperatureMonitor" component={TemperatureMonitorScreen} />
      <AnimalStack.Screen name="MilkProduction" component={MilkProductionScreen} />
      <AnimalStack.Screen name="Reproduction" component={ReproductionScreen} />
      <AnimalStack.Screen name="Vaccination" component={VaccinationScreen} />
    </AnimalStack.Navigator>
  );
}

function SensorStackNavigator() {
  return (
    <SensorStack.Navigator screenOptions={{ headerShown: false }}>
      <SensorStack.Screen name="SensorDashboard" component={SensorDashboardScreen} />
      <SensorStack.Screen name="SensorDetail" component={SensorDetailScreen} />
      <SensorStack.Screen name="TemperatureMonitor" component={TemperatureMonitorScreen} />
    </SensorStack.Navigator>
  );
}

function BottomTabNavigator() {
  const { state } = useApp();
  const dark = state.darkMode;
  const criticalCount = state.alerts.filter(a => !a.resolved && a.type === 'critical').length;

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: dark ? Colors.darkSurface : Colors.surface,
          borderTopColor: dark ? Colors.darkBorder : Colors.border,
          height: Platform.OS === 'ios' ? 85 : 65,
          paddingBottom: Platform.OS === 'ios' ? 25 : 8,
          paddingTop: 8,
          elevation: 8,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.08,
          shadowRadius: 8,
        },
        tabBarActiveTintColor: Colors.primary,
        tabBarInactiveTintColor: dark ? Colors.darkTextMuted : Colors.textMuted,
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
          marginTop: 2,
        },
      })}
    >
      <Tab.Screen
        name="Dashboard"
        component={DashboardScreen}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size, focused }) => (
            <View style={{ alignItems: 'center', justifyContent: 'center' }}>
              <MaterialCommunityIcons
                name={focused ? 'home' : 'home-outline'}
                size={size}
                color={color}
              />
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Animals"
        component={AnimalStackNavigator}
        options={{
          tabBarLabel: 'Animals',
          tabBarIcon: ({ color, size, focused }) => (
            <MaterialCommunityIcons
              name={focused ? 'cow' : 'cow'}
              size={size}
              color={color}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Sensors"
        component={SensorStackNavigator}
        options={{
          tabBarLabel: 'Sensors',
          tabBarIcon: ({ color, size, focused }) => (
            <MaterialCommunityIcons
              name={focused ? 'broadcast' : 'broadcast'}
              size={size}
              color={color}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Reports"
        component={ReportsScreen}
        options={{
          tabBarLabel: 'Reports',
          tabBarIcon: ({ color, size, focused }) => (
            <MaterialCommunityIcons
              name={focused ? 'chart-bar' : 'chart-bar'}
              size={size}
              color={color}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          tabBarLabel: 'Settings',
          tabBarIcon: ({ color, size, focused }) => (
            <MaterialCommunityIcons
              name={focused ? 'cog' : 'cog-outline'}
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function MainNavigator() {
  const { state } = useApp();
  const dark = state.darkMode;

  return (
    <Drawer.Navigator
      screenOptions={{
        headerShown: false,
        drawerStyle: {
          backgroundColor: dark ? Colors.darkSurface : Colors.surface,
          width: 280,
        },
        drawerActiveTintColor: Colors.primary,
        drawerInactiveTintColor: dark ? Colors.darkTextSecondary : Colors.textSecondary,
        drawerActiveBackgroundColor: dark ? '#1A3A1C' : '#E8F5E9',
        drawerLabelStyle: { fontWeight: '600', fontSize: 15 },
      }}
    >
      <Drawer.Screen
        name="MainTabs"
        component={BottomTabNavigator}
        options={{
          drawerLabel: 'Home',
          drawerIcon: ({ color }) => (
            <MaterialCommunityIcons name="home-outline" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="AlertsDrawer"
        component={AlertsScreen}
        options={{
          drawerLabel: 'Alerts',
          drawerIcon: ({ color }) => (
            <MaterialCommunityIcons name="bell-outline" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="VaccinationDrawer"
        component={VaccinationScreen}
        options={{
          drawerLabel: 'Vaccination Schedule',
          drawerIcon: ({ color }) => (
            <MaterialCommunityIcons name="needle" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="MilkDrawer"
        component={MilkProductionScreen}
        options={{
          drawerLabel: 'Milk Production',
          drawerIcon: ({ color }) => (
            <MaterialCommunityIcons name="water" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="ReproductionDrawer"
        component={ReproductionScreen}
        options={{
          drawerLabel: 'Reproduction',
          drawerIcon: ({ color }) => (
            <MaterialCommunityIcons name="heart-pulse" size={22} color={color} />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}
