import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { BarChart, LineChart, PieChart } from 'react-native-chart-kit';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

const { width } = Dimensions.get('window');

const REPORT_TYPES = [
  { id: 'health', label: 'Health Report', icon: 'heart-pulse', color: Colors.danger, desc: 'Animal health status, diagnoses, treatments' },
  { id: 'milk', label: 'Milk Production', icon: 'water', color: Colors.info, desc: 'Daily/monthly milk yield per animal' },
  { id: 'vaccination', label: 'Vaccination Report', icon: 'needle', color: Colors.success, desc: 'Vaccination history and upcoming schedule' },
  { id: 'temperature', label: 'Temperature Log', icon: 'thermometer', color: Colors.warning, desc: '24-hour temperature trends and alerts' },
  { id: 'full', label: 'Full Farm Report', icon: 'file-chart', color: Colors.primary, desc: 'Comprehensive report of all metrics' },
];

const chartConfig = (dark) => ({
  backgroundGradientFrom: dark ? Colors.darkSurface : Colors.surface,
  backgroundGradientTo: dark ? Colors.darkSurface : Colors.surface,
  color: (o = 1) => `rgba(46,125,50,${o})`,
  labelColor: (o = 1) => dark ? `rgba(165,200,167,${o})` : `rgba(90,116,96,${o})`,
  decimalPlaces: 1,
  propsForDots: { r: '3' },
});

export default function ReportsScreen() {
  const { state } = useApp();
  const dark = state.darkMode;
  const [selectedReport, setSelectedReport] = useState('full');
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async (format) => {
    setGenerating(true);
    await new Promise(r => setTimeout(r, 1500));
    setGenerating(false);
    Alert.alert(
      `${format} Generated!`,
      `In production, this would use expo-file-system and expo-sharing to generate and share a real ${format} file with all farm data.`,
      [{ text: 'OK' }]
    );
  };

  // Stats for charts
  const milkData = state.animals.filter(a => a.milk).map(a => a.milk.currentDaily);
  const milkLabels = state.animals.filter(a => a.milk).map(a => a.name.slice(0, 4));
  const tempData = state.animals.map(a => a.sensors?.temperature?.value || 0);
  const tempLabels = state.animals.map(a => a.name.slice(0, 4));

  const healthPie = [
    { name: 'Healthy', count: state.animals.filter(a => a.status === 'healthy').length, color: Colors.success, legendFontColor: Colors.text },
    { name: 'Warning', count: state.animals.filter(a => a.status === 'warning').length, color: Colors.warning, legendFontColor: Colors.text },
    { name: 'Critical', count: state.animals.filter(a => a.status === 'critical').length, color: Colors.danger, legendFontColor: Colors.text },
    { name: 'Offline', count: state.animals.filter(a => a.status === 'offline').length, color: Colors.statusOffline, legendFontColor: Colors.text },
  ].filter(s => s.count > 0);

  const speciesPie = [
    { name: 'Cattle', count: state.farmStats.cattle, color: Colors.primary, legendFontColor: Colors.text },
    { name: 'Goats', count: state.farmStats.goats, color: Colors.accent, legendFontColor: Colors.text },
    { name: 'Sheep', count: state.farmStats.sheep, color: Colors.info, legendFontColor: Colors.text },
  ];

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader title="Reports" subtitle="Analytics & Export" dark={dark} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>

        {/* Report Type Selector */}
        <Text style={[styles.sectionLabel, dark && { color: Colors.darkText }]}>Report Type</Text>
        <View style={styles.reportGrid}>
          {REPORT_TYPES.map(rt => (
            <TouchableOpacity
              key={rt.id}
              onPress={() => setSelectedReport(rt.id)}
              activeOpacity={0.85}
              style={[styles.reportTypeCard, selectedReport === rt.id && { borderColor: rt.color, borderWidth: 2 }, dark && styles.reportTypeCardDark]}
            >
              <View style={[styles.reportTypeIcon, { backgroundColor: rt.color + '20' }]}>
                <MaterialCommunityIcons name={rt.icon} size={22} color={rt.color} />
              </View>
              <Text style={[styles.reportTypeLabel, dark && { color: Colors.darkText }]}>{rt.label}</Text>
              <Text style={[styles.reportTypeDesc, dark && { color: Colors.darkTextMuted }]} numberOfLines={2}>{rt.desc}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Export Buttons */}
        <View style={styles.exportRow}>
          <TouchableOpacity
            onPress={() => handleGenerate('PDF')}
            style={[styles.exportBtn, { backgroundColor: Colors.danger }]}
            activeOpacity={0.85}
            disabled={generating}
          >
            <MaterialCommunityIcons name="file-pdf-box" size={20} color="#fff" />
            <Text style={styles.exportBtnText}>{generating ? 'Generating...' : 'Export PDF'}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => handleGenerate('CSV')}
            style={[styles.exportBtn, { backgroundColor: Colors.success }]}
            activeOpacity={0.85}
            disabled={generating}
          >
            <MaterialCommunityIcons name="file-delimited" size={20} color="#fff" />
            <Text style={styles.exportBtnText}>Export CSV</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => Alert.alert('Share', 'Share functionality via expo-sharing')}
            style={[styles.exportBtn, { backgroundColor: Colors.info }]}
            activeOpacity={0.85}
          >
            <MaterialCommunityIcons name="share-variant" size={20} color="#fff" />
            <Text style={styles.exportBtnText}>Share</Text>
          </TouchableOpacity>
        </View>

        {/* Summary Stats */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Farm Summary</Text>
          <View style={styles.summaryGrid}>
            {[
              { label: 'Total Animals', value: state.farmStats.totalAnimals, icon: 'cow', color: Colors.primary },
              { label: 'Active Alerts', value: state.alerts.filter(a => !a.resolved).length, icon: 'bell', color: Colors.danger },
              { label: 'Milk Today (L)', value: state.farmStats.totalMilkToday, icon: 'water', color: Colors.info },
              { label: 'Avg Temp (°C)', value: state.farmStats.avgTemperature, icon: 'thermometer', color: Colors.warning },
              { label: 'Cattle', value: state.farmStats.cattle, icon: 'cow', color: Colors.primary },
              { label: 'Pregnant', value: state.animals.filter(a => a.reproduction?.status === 'pregnant').length, icon: 'baby-carriage', color: Colors.accent },
            ].map(s => (
              <View key={s.label} style={[styles.summaryItem, { backgroundColor: s.color + '12' }]}>
                <MaterialCommunityIcons name={s.icon} size={18} color={s.color} />
                <Text style={[styles.summaryValue, { color: s.color }]}>{s.value}</Text>
                <Text style={[styles.summaryLabel, dark && { color: Colors.darkTextMuted }]}>{s.label}</Text>
              </View>
            ))}
          </View>
        </Card>

        {/* Health Distribution Pie */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Health Distribution</Text>
          <PieChart
            data={healthPie.map(s => ({ ...s, legendFontColor: dark ? Colors.darkTextSecondary : Colors.text, legendFontSize: 13 }))}
            width={width - 64}
            height={180}
            chartConfig={chartConfig(dark)}
            accessor="count"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
          />
        </Card>

        {/* Species Breakdown */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Species Breakdown</Text>
          <PieChart
            data={speciesPie.map(s => ({ ...s, legendFontColor: dark ? Colors.darkTextSecondary : Colors.text, legendFontSize: 13 }))}
            width={width - 64}
            height={160}
            chartConfig={chartConfig(dark)}
            accessor="count"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
          />
        </Card>

        {/* Milk production chart */}
        {milkData.length > 0 && (
          <Card dark={dark}>
            <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Today's Milk Production by Animal</Text>
            <BarChart
              data={{ labels: milkLabels, datasets: [{ data: milkData }] }}
              width={width - 64}
              height={180}
              chartConfig={{
                ...chartConfig(dark),
                color: (o = 1) => `rgba(2,136,209,${o})`,
              }}
              style={{ borderRadius: Radius.lg, marginLeft: -16 }}
              fromZero
              showValuesOnTopOfBars
            />
          </Card>
        )}

        {/* Temperature chart */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Current Temperature by Animal</Text>
          <BarChart
            data={{ labels: tempLabels, datasets: [{ data: tempData }] }}
            width={width - 64}
            height={180}
            chartConfig={{
              ...chartConfig(dark),
              color: (o = 1) => `rgba(211,47,47,${o})`,
            }}
            style={{ borderRadius: Radius.lg, marginLeft: -16 }}
            fromZero={false}
            yAxisSuffix="°"
            showValuesOnTopOfBars
          />
          <View style={styles.thresholdNote}>
            <View style={[styles.thresholdDot, { backgroundColor: Colors.danger }]} />
            <Text style={[styles.thresholdText, dark && { color: Colors.darkTextMuted }]}>
              Critical threshold: 39.5°C
            </Text>
          </View>
        </Card>

        {/* Recent activity table */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Recent Activity</Text>
          {state.alerts.slice(0, 5).map(a => (
            <View key={a.id} style={[styles.activityRow, dark && styles.activityRowDark]}>
              <View style={[styles.activityDot, { backgroundColor: a.type === 'critical' ? Colors.danger : a.type === 'warning' ? Colors.warning : Colors.info }]} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.activityTitle, dark && { color: Colors.darkText }]} numberOfLines={1}>{a.title}</Text>
                <Text style={[styles.activityMeta, dark && { color: Colors.darkTextMuted }]}>
                  {a.animalName} · {new Date(a.timestamp).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
              {a.resolved && (
                <View style={styles.resolvedTag}>
                  <Text style={styles.resolvedTagText}>Done</Text>
                </View>
              )}
            </View>
          ))}
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  content: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 40 },
  sectionLabel: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text, textTransform: 'uppercase', letterSpacing: 0.5 },
  reportGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  reportTypeCard: { width: '48%', backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.md, borderWidth: 1.5, borderColor: Colors.border, gap: 6 },
  reportTypeCardDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  reportTypeIcon: { width: 44, height: 44, borderRadius: Radius.md, alignItems: 'center', justifyContent: 'center' },
  reportTypeLabel: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text },
  reportTypeDesc: { fontSize: Typography.xs, color: Colors.textMuted, lineHeight: 16 },
  exportRow: { flexDirection: 'row', gap: Spacing.sm },
  exportBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, borderRadius: Radius.lg },
  exportBtnText: { color: '#fff', fontSize: Typography.xs, fontWeight: '700' },
  cardTitle: { fontSize: Typography.md, fontWeight: '700', color: Colors.text, marginBottom: Spacing.md },
  summaryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  summaryItem: { width: '31%', alignItems: 'center', padding: Spacing.md, borderRadius: Radius.md, gap: 4 },
  summaryValue: { fontSize: Typography.xl, fontWeight: '800' },
  summaryLabel: { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },
  thresholdNote: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: Spacing.sm },
  thresholdDot: { width: 10, height: 2 },
  thresholdText: { fontSize: Typography.xs, color: Colors.textMuted },
  activityRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: Colors.border },
  activityRowDark: { borderBottomColor: Colors.darkBorder },
  activityDot: { width: 10, height: 10, borderRadius: 5 },
  activityTitle: { fontSize: Typography.sm, fontWeight: '600', color: Colors.text },
  activityMeta: { fontSize: Typography.xs, color: Colors.textMuted },
  resolvedTag: { backgroundColor: '#E8F5E9', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  resolvedTagText: { fontSize: 10, color: Colors.success, fontWeight: '700' },
});
