import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Switch, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { ScreenHeader, EmptyState } from '../../components/common';
import { Colors, Typography, Spacing, Radius, Shadows } from '../../utils/theme';

const FILTERS = ['All', 'Critical', 'Warning', 'Normal', 'Resolved'];

const TYPE_CONFIG = {
  critical: { color: Colors.danger, bg: '#FFEBEE', icon: 'alert-circle' },
  warning: { color: Colors.warning, bg: '#FFF3E0', icon: 'alert' },
  normal: { color: Colors.info, bg: '#E3F2FD', icon: 'information' },
};

function AlertCard({ alert, onResolve, onDelete, dark }) {
  const config = TYPE_CONFIG[alert.type] || TYPE_CONFIG.normal;
  const timeAgo = (ts) => {
    const mins = Math.floor((Date.now() - new Date(ts)) / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  };

  return (
    <View style={[styles.alertCard, dark && styles.alertCardDark, alert.resolved && styles.alertCardResolved]}>
      {/* Left accent */}
      <View style={[styles.alertAccent, { backgroundColor: alert.resolved ? Colors.statusOffline : config.color }]} />

      <View style={[styles.alertIconWrap, { backgroundColor: alert.resolved ? '#F5F5F5' : config.bg }]}>
        <MaterialCommunityIcons
          name={alert.icon || config.icon}
          size={22}
          color={alert.resolved ? Colors.statusOffline : config.color}
        />
      </View>

      <View style={styles.alertContent}>
        <View style={styles.alertTitleRow}>
          <Text style={[styles.alertTitle, dark && { color: Colors.darkText }, alert.resolved && styles.alertTitleResolved]} numberOfLines={1}>
            {alert.title}
          </Text>
          <Text style={[styles.alertTime, dark && { color: Colors.darkTextMuted }]}>{timeAgo(alert.timestamp)}</Text>
        </View>
        <Text style={[styles.alertAnimal, { color: config.color }]}>{alert.animalName}</Text>
        <Text style={[styles.alertMessage, dark && { color: Colors.darkTextSecondary }]} numberOfLines={2}>
          {alert.message}
        </Text>

        <View style={styles.alertActions}>
          {!alert.resolved && (
            <TouchableOpacity onPress={() => onResolve(alert.id)} style={styles.resolveBtn} activeOpacity={0.8}>
              <MaterialCommunityIcons name="check" size={14} color={Colors.success} />
              <Text style={styles.resolveBtnText}>Resolve</Text>
            </TouchableOpacity>
          )}
          {alert.resolved && (
            <View style={styles.resolvedTag}>
              <MaterialCommunityIcons name="check-circle" size={14} color={Colors.success} />
              <Text style={styles.resolvedTagText}>Resolved</Text>
            </View>
          )}
          <TouchableOpacity onPress={() => onDelete(alert.id)} style={styles.deleteBtn} activeOpacity={0.8}>
            <MaterialCommunityIcons name="trash-can-outline" size={16} color={Colors.danger} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default function AlertsScreen({ navigation }) {
  const { state, dispatch } = useApp();
  const dark = state.darkMode;
  const [filter, setFilter] = useState('All');

  const filtered = state.alerts.filter(a => {
    if (filter === 'All') return true;
    if (filter === 'Resolved') return a.resolved;
    return a.type === filter.toLowerCase() && !a.resolved;
  });

  const handleResolve = (id) => {
    dispatch({ type: 'RESOLVE_ALERT', payload: id });
  };

  const handleDelete = (id) => {
    Alert.alert('Delete Alert', 'Are you sure you want to delete this alert?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => dispatch({ type: 'DELETE_ALERT', payload: id }) },
    ]);
  };

  const handleResolveAll = () => {
    state.alerts.filter(a => !a.resolved).forEach(a => dispatch({ type: 'RESOLVE_ALERT', payload: a.id }));
  };

  const unresolved = state.alerts.filter(a => !a.resolved).length;

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader
        title="Alerts"
        subtitle={`${unresolved} unresolved`}
        dark={dark}
        onMenu={navigation.openDrawer ? () => navigation.openDrawer() : undefined}
        rightComponent={
          unresolved > 0 ? (
            <TouchableOpacity onPress={handleResolveAll} style={styles.resolveAllBtn}>
              <Text style={styles.resolveAllText}>Resolve All</Text>
            </TouchableOpacity>
          ) : null
        }
      />

      {/* Notification Toggles */}
      <View style={[styles.togglesCard, dark && styles.togglesCardDark]}>
        <Text style={[styles.togglesTitle, dark && { color: Colors.darkText }]}>Notifications</Text>
        <View style={styles.togglesRow}>
          {[
            { key: 'temperature', label: 'Temp', icon: 'thermometer' },
            { key: 'vaccination', label: 'Vaccine', icon: 'needle' },
            { key: 'milk', label: 'Milk', icon: 'water' },
            { key: 'general', label: 'General', icon: 'bell' },
          ].map(item => (
            <View key={item.key} style={styles.toggleItem}>
              <MaterialCommunityIcons name={item.icon} size={16} color={state.notifications[item.key] ? Colors.primary : Colors.textMuted} />
              <Text style={[styles.toggleLabel, dark && { color: Colors.darkTextSecondary }]}>{item.label}</Text>
              <Switch
                value={state.notifications[item.key]}
                onValueChange={() => dispatch({ type: 'TOGGLE_NOTIFICATION', payload: item.key })}
                trackColor={{ true: Colors.primary, false: Colors.border }}
                thumbColor="#fff"
                style={{ transform: [{ scale: 0.7 }] }}
              />
            </View>
          ))}
        </View>
      </View>

      {/* Filter tabs */}
      <View style={styles.filterRow}>
        <FlatList
          data={FILTERS}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: Spacing.base, gap: 8 }}
          keyExtractor={f => f}
          renderItem={({ item }) => {
            const count = item === 'All'
              ? state.alerts.length
              : item === 'Resolved'
              ? state.alerts.filter(a => a.resolved).length
              : state.alerts.filter(a => a.type === item.toLowerCase() && !a.resolved).length;
            return (
              <TouchableOpacity
                onPress={() => setFilter(item)}
                activeOpacity={0.8}
                style={[styles.filterPill, filter === item && styles.filterPillActive, dark && filter !== item && styles.filterPillDark]}
              >
                <Text style={[styles.filterText, filter === item && styles.filterTextActive, dark && filter !== item && { color: Colors.darkTextSecondary }]}>
                  {item}
                </Text>
                {count > 0 && (
                  <View style={[styles.filterCount, filter === item && styles.filterCountActive]}>
                    <Text style={[styles.filterCountText, filter === item && styles.filterCountTextActive]}>{count}</Text>
                  </View>
                )}
              </TouchableOpacity>
            );
          }}
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={a => a.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <EmptyState icon="bell-off-outline" title="No alerts" subtitle="You're all caught up!" dark={dark} />
        }
        renderItem={({ item }) => (
          <AlertCard alert={item} onResolve={handleResolve} onDelete={handleDelete} dark={dark} />
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  resolveAllBtn: { backgroundColor: '#E8F5E9', paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.round },
  resolveAllText: { fontSize: Typography.xs, color: Colors.primary, fontWeight: '700' },
  togglesCard: { backgroundColor: Colors.surface, paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border },
  togglesCardDark: { backgroundColor: Colors.darkSurface, borderBottomColor: Colors.darkBorder },
  togglesTitle: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text, marginBottom: Spacing.sm },
  togglesRow: { flexDirection: 'row', gap: Spacing.sm },
  toggleItem: { flex: 1, alignItems: 'center', gap: 3 },
  toggleLabel: { fontSize: 10, color: Colors.textMuted, fontWeight: '500' },
  filterRow: { paddingVertical: Spacing.sm },
  filterPill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 7, borderRadius: Radius.round, backgroundColor: Colors.surfaceSecondary, borderWidth: 1.5, borderColor: Colors.border },
  filterPillActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterPillDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  filterText: { fontSize: Typography.xs, color: Colors.textSecondary, fontWeight: '600' },
  filterTextActive: { color: '#fff' },
  filterCount: { backgroundColor: Colors.border, borderRadius: 10, paddingHorizontal: 6, paddingVertical: 1 },
  filterCountActive: { backgroundColor: 'rgba(255,255,255,0.25)' },
  filterCountText: { fontSize: 10, color: Colors.textSecondary, fontWeight: '700' },
  filterCountTextActive: { color: '#fff' },
  list: { padding: Spacing.base, gap: Spacing.sm, paddingBottom: 40 },
  alertCard: { flexDirection: 'row', backgroundColor: Colors.surface, borderRadius: Radius.lg, overflow: 'hidden', ...Shadows.md },
  alertCardDark: { backgroundColor: Colors.darkSurface },
  alertCardResolved: { opacity: 0.7 },
  alertAccent: { width: 4 },
  alertIconWrap: { width: 52, alignItems: 'center', justifyContent: 'center', paddingVertical: Spacing.md },
  alertContent: { flex: 1, padding: Spacing.md },
  alertTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8, marginBottom: 2 },
  alertTitle: { flex: 1, fontSize: Typography.sm, fontWeight: '700', color: Colors.text },
  alertTitleResolved: { textDecorationLine: 'line-through', color: Colors.textMuted },
  alertTime: { fontSize: Typography.xs, color: Colors.textMuted, whiteSpace: 'nowrap' },
  alertAnimal: { fontSize: Typography.xs, fontWeight: '700', marginBottom: 4 },
  alertMessage: { fontSize: Typography.xs, color: Colors.textSecondary, lineHeight: 16 },
  alertActions: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginTop: Spacing.sm },
  resolveBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 5, backgroundColor: '#E8F5E9', borderRadius: Radius.round },
  resolveBtnText: { fontSize: Typography.xs, color: Colors.success, fontWeight: '700' },
  resolvedTag: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  resolvedTagText: { fontSize: Typography.xs, color: Colors.success, fontWeight: '600' },
  deleteBtn: { marginLeft: 'auto', padding: 4 },
});
