import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { InputField, PrimaryButton, ScreenHeader } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

export default function RegisterScreen({ navigation }) {
  const { login } = useApp();
  const [form, setForm] = useState({
    name: '',
    farm: '',
    email: '',
    password: '',
    confirmPassword: '',
    location: 'Anand, Gujarat',
  });
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const update = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Full name is required';
    if (!form.farm.trim()) e.farm = 'Farm name is required';
    if (!form.email) e.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Invalid email address';
    if (!form.password) e.password = 'Password is required';
    else if (form.password.length < 6) e.password = 'At least 6 characters';
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleRegister = async () => {
    if (!validate()) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1200));
    await login({
      id: 'user-new',
      name: form.name,
      email: form.email,
      farm: form.farm,
      location: form.location,
    });
    setLoading(false);
  };

  const handleLocationPicker = () => {
    Alert.alert(
      'Location Picker',
      'In production, this opens a map picker using expo-location and Google Maps API.',
      [
        { text: 'Use Current', onPress: () => update('location', 'Current Location') },
        { text: 'Cancel', style: 'cancel' },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScreenHeader
          title="Create Account"
          subtitle="Join LiveStock+ today"
          onBack={() => navigation.goBack()}
        />
        <ScrollView
          contentContainerStyle={styles.scroll}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header art */}
          <View style={styles.headerArt}>
            <MaterialCommunityIcons name="account-plus" size={48} color={Colors.primary} />
          </View>

          <InputField
            label="Full Name"
            value={form.name}
            onChangeText={v => update('name', v)}
            placeholder="Rajesh Kumar"
            icon="account-outline"
            error={errors.name}
            autoCapitalize="words"
          />
          <InputField
            label="Farm Name"
            value={form.farm}
            onChangeText={v => update('farm', v)}
            placeholder="Green Valley Farm"
            icon="barn"
            error={errors.farm}
            autoCapitalize="words"
          />
          <InputField
            label="Email Address"
            value={form.email}
            onChangeText={v => update('email', v)}
            placeholder="you@example.com"
            keyboardType="email-address"
            icon="email-outline"
            error={errors.email}
          />
          <InputField
            label="Password"
            value={form.password}
            onChangeText={v => update('password', v)}
            placeholder="Create a strong password"
            secureTextEntry={!showPass}
            icon="lock-outline"
            error={errors.password}
            rightComponent={
              <TouchableOpacity onPress={() => setShowPass(!showPass)} style={{ padding: 4 }}>
                <MaterialCommunityIcons
                  name={showPass ? 'eye-off-outline' : 'eye-outline'}
                  size={20}
                  color={Colors.textMuted}
                />
              </TouchableOpacity>
            }
          />
          <InputField
            label="Confirm Password"
            value={form.confirmPassword}
            onChangeText={v => update('confirmPassword', v)}
            placeholder="Re-enter your password"
            secureTextEntry={!showConfirm}
            icon="lock-check-outline"
            error={errors.confirmPassword}
            rightComponent={
              <TouchableOpacity onPress={() => setShowConfirm(!showConfirm)} style={{ padding: 4 }}>
                <MaterialCommunityIcons
                  name={showConfirm ? 'eye-off-outline' : 'eye-outline'}
                  size={20}
                  color={Colors.textMuted}
                />
              </TouchableOpacity>
            }
          />

          {/* Location picker */}
          <View style={styles.inputWrapper}>
            <Text style={styles.inputLabel}>Farm Location</Text>
            <TouchableOpacity onPress={handleLocationPicker} style={styles.locationPicker} activeOpacity={0.85}>
              <MaterialCommunityIcons name="map-marker-outline" size={20} color={Colors.primary} />
              <Text style={styles.locationText}>{form.location || 'Tap to set location'}</Text>
              <MaterialCommunityIcons name="chevron-right" size={20} color={Colors.textMuted} />
            </TouchableOpacity>
          </View>

          <PrimaryButton
            title="Create Account"
            onPress={handleRegister}
            loading={loading}
            icon="check"
            style={{ marginTop: Spacing.md }}
          />

          <View style={styles.loginRow}>
            <Text style={styles.loginText}>Already have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')} activeOpacity={0.7}>
              <Text style={styles.loginLink}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scroll: {
    flexGrow: 1,
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.xxxl,
    paddingTop: Spacing.lg,
  },
  headerArt: {
    alignItems: 'center',
    marginBottom: Spacing.xl,
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  inputWrapper: {
    marginBottom: Spacing.md,
  },
  inputLabel: {
    fontSize: Typography.sm,
    fontWeight: Typography.semibold,
    color: Colors.textSecondary,
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  locationPicker: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radius.lg,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.border,
    gap: 10,
  },
  locationText: {
    flex: 1,
    fontSize: Typography.md,
    color: Colors.text,
  },
  loginRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: Spacing.xl,
  },
  loginText: {
    fontSize: Typography.base,
    color: Colors.textSecondary,
  },
  loginLink: {
    fontSize: Typography.base,
    color: Colors.primary,
    fontWeight: Typography.bold,
  },
});
