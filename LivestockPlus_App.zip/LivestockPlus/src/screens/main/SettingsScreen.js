import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Switch, Alert, TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader, PrimaryButton } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

function SettingRow({ icon, label, subtitle, rightComponent, onPress, color, dark }) {
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper onPress={onPress} activeOpacity={0.8} style={[styles.settingRow, dark && styles.settingRowDark]}>
      <View style={[styles.settingIcon, { backgroundColor: (color || Colors.primary) + '20' }]}>
        <MaterialCommunityIcons name={icon} size={20} color={color || Colors.primary} />
      </View>
      <View style={styles.settingInfo}>
        <Text style={[styles.settingLabel, dark && { color: Colors.darkText }]}>{label}</Text>
        {subtitle && <Text style={[styles.settingSubtitle, dark && { color: Colors.darkTextMuted }]}>{subtitle}</Text>}
      </View>
      {rightComponent || (onPress && (
        <MaterialCommunityIcons name="chevron-right" size={20} color={dark ? Colors.darkTextMuted : Colors.textMuted} />
      ))}
    </Wrapper>
  );
}

function SettingSection({ title, children, dark }) {
  return (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, dark && { color: Colors.darkTextMuted }]}>{title}</Text>
      <Card dark={dark} style={{ padding: 0, overflow: 'hidden' }}>
        {children}
      </Card>
    </View>
  );
}

export default function SettingsScreen({ navigation }) {
  const { state, dispatch, logout } = useApp();
  const dark = state.darkMode;
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({
    name: state.user?.name || '',
    farm: state.user?.farm || '',
    email: state.user?.email || '',
    location: state.user?.location || '',
  });
  const [language, setLanguage] = useState('English');
  const LANGUAGES = ['English', 'हिंदी', 'ગુજરાતી', 'தமிழ்', 'తెలుగు'];

  const handleLogout = () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Logout', style: 'destructive', onPress: logout },
    ]);
  };

  const handleSaveProfile = () => {
    dispatch({
      type: 'LOGIN',
      payload: { ...state.user, ...profileForm },
    });
    setEditingProfile(false);
    Alert.alert('Saved', 'Profile updated successfully');
  };

  const handleSensorPairing = () => {
    Alert.alert('Sensor Pairing', 'In production, this would open a BLE/WiFi sensor pairing wizard to connect new IoT sensors to animals.');
  };

  const handleLanguageChange = () => {
    Alert.alert('Language', 'Select language:', LANGUAGES.map(l => ({
      text: l,
      onPress: () => setLanguage(l),
    })));
  };

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader title="Settings" dark={dark} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>

        {/* Profile Card */}
        <Card dark={dark} style={styles.profileCard}>
          <View style={styles.profileHeader}>
            <View style={[styles.profileAvatar, { backgroundColor: Colors.primary }]}>
              <MaterialCommunityIcons name="account" size={36} color="#fff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.profileName, dark && { color: Colors.darkText }]}>{state.user?.name}</Text>
              <Text style={[styles.profileEmail, dark && { color: Colors.darkTextSecondary }]}>{state.user?.email}</Text>
              <Text style={[styles.profileFarm, dark && { color: Colors.darkTextMuted }]}>
                <MaterialCommunityIcons name="barn" size={13} /> {state.user?.farm}
              </Text>
            </View>
            <TouchableOpacity onPress={() => setEditingProfile(!editingProfile)} style={styles.editProfileBtn}>
              <MaterialCommunityIcons name={editingProfile ? 'close' : 'pencil'} size={18} color={Colors.primary} />
            </TouchableOpacity>
          </View>

          {editingProfile && (
            <View style={styles.profileForm}>
              {[
                { key: 'name', label: 'Full Name', icon: 'account', cap: 'words' },
                { key: 'farm', label: 'Farm Name', icon: 'barn', cap: 'words' },
                { key: 'email', label: 'Email', icon: 'email', cap: 'none' },
                { key: 'location', label: 'Location', icon: 'map-marker', cap: 'words' },
              ].map(f => (
                <View key={f.key} style={styles.formField}>
                  <Text style={[styles.formLabel, dark && { color: Colors.darkTextSecondary }]}>{f.label}</Text>
                  <View style={[styles.formInput, dark && styles.formInputDark]}>
                    <MaterialCommunityIcons name={f.icon} size={16} color={Colors.textMuted} />
                    <TextInput
                      value={profileForm[f.key]}
                      onChangeText={v => setProfileForm(p => ({ ...p, [f.key]: v }))}
                      style={[styles.formInputText, dark && { color: Colors.darkText }]}
                      autoCapitalize={f.cap}
                      placeholderTextColor={dark ? Colors.darkTextMuted : Colors.placeholder}
                    />
                  </View>
                </View>
              ))}
              <PrimaryButton title="Save Changes" onPress={handleSaveProfile} icon="content-save" style={{ marginTop: Spacing.sm }} />
            </View>
          )}
        </Card>

        {/* Appearance */}
        <SettingSection title="APPEARANCE" dark={dark}>
          <SettingRow
            icon="theme-light-dark"
            label="Dark Mode"
            subtitle={dark ? 'Currently dark' : 'Currently light'}
            color={Colors.primary}
            dark={dark}
            rightComponent={
              <Switch
                value={dark}
                onValueChange={() => dispatch({ type: 'TOGGLE_DARK_MODE' })}
                trackColor={{ true: Colors.primary, false: Colors.border }}
                thumbColor="#fff"
              />
            }
          />
          <SettingRow
            icon="translate"
            label="Language"
            subtitle={language}
            color={Colors.info}
            dark={dark}
            onPress={handleLanguageChange}
          />
        </SettingSection>

        {/* Farm Settings */}
        <SettingSection title="FARM SETTINGS" dark={dark}>
          <SettingRow icon="access-point-network" label="Sensor Pairing" subtitle="Connect IoT sensors" color={Colors.accent} dark={dark} onPress={handleSensorPairing} />
          <SettingRow icon="map-marker" label="Farm Location" subtitle={state.user?.location || 'Not set'} color={Colors.success} dark={dark} onPress={() => Alert.alert('Location', 'Location picker would open here')} />
          <SettingRow icon="cog" label="Alert Thresholds" subtitle="Customize temperature, milk thresholds" color={Colors.warning} dark={dark} onPress={() => Alert.alert('Thresholds', 'Threshold settings UI would appear here')} />
          <SettingRow icon="clock-outline" label="Sync Frequency" subtitle="Every 30 seconds" color={Colors.primary} dark={dark} onPress={() => Alert.alert('Sync', 'Adjust automatic sync interval')} />
        </SettingSection>

        {/* Notifications */}
        <SettingSection title="NOTIFICATIONS" dark={dark}>
          {[
            { key: 'temperature', label: 'Temperature Alerts', icon: 'thermometer', color: Colors.danger },
            { key: 'vaccination', label: 'Vaccination Reminders', icon: 'needle', color: Colors.success },
            { key: 'milk', label: 'Milk Drop Alerts', icon: 'water-minus', color: Colors.info },
            { key: 'general', label: 'General Notifications', icon: 'bell', color: Colors.accent },
          ].map(item => (
            <SettingRow
              key={item.key}
              icon={item.icon}
              label={item.label}
              color={item.color}
              dark={dark}
              rightComponent={
                <Switch
                  value={state.notifications[item.key]}
                  onValueChange={() => dispatch({ type: 'TOGGLE_NOTIFICATION', payload: item.key })}
                  trackColor={{ true: Colors.primary, false: Colors.border }}
                  thumbColor="#fff"
                />
              }
            />
          ))}
        </SettingSection>

        {/* Data & Privacy */}
        <SettingSection title="DATA & PRIVACY" dark={dark}>
          <SettingRow icon="database-export" label="Export All Data" subtitle="Download farm data as CSV" color={Colors.primary} dark={dark} onPress={() => Alert.alert('Export', 'Would export all farm data as CSV')} />
          <SettingRow icon="cloud-sync" label="Sync Status" subtitle={state.lastSync ? `Last sync: ${new Date(state.lastSync).toLocaleTimeString()}` : 'Not synced'} color={Colors.success} dark={dark} onPress={() => {}} />
          <SettingRow icon="wifi" label="Offline Mode" subtitle={state.isOnline ? 'Online' : 'Offline — changes will sync'} color={state.isOnline ? Colors.success : Colors.warning} dark={dark} />
          <SettingRow icon="shield-lock" label="Privacy Policy" color={Colors.textMuted} dark={dark} onPress={() => Alert.alert('Privacy', 'Privacy policy URL')} />
        </SettingSection>

        {/* Support */}
        <SettingSection title="SUPPORT" dark={dark}>
          <SettingRow icon="help-circle" label="Help & FAQ" color={Colors.info} dark={dark} onPress={() => Alert.alert('Help', 'Help center would open here')} />
          <SettingRow icon="bug" label="Report a Bug" color={Colors.warning} dark={dark} onPress={() => Alert.alert('Report Bug', 'Bug reporting form would open')} />
          <SettingRow icon="information" label="App Version" subtitle="LiveStock+ v1.0.0" color={Colors.textMuted} dark={dark} />
        </SettingSection>

        {/* Logout */}
        <TouchableOpacity onPress={handleLogout} style={[styles.logoutBtn, dark && styles.logoutBtnDark]} activeOpacity={0.85}>
          <MaterialCommunityIcons name="logout" size={20} color={Colors.danger} />
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>

        <Text style={[styles.version, dark && { color: Colors.darkTextMuted }]}>
          LiveStock+ · v1.0.0 · Made with ❤️ for Indian Farmers
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  content: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 60 },
  profileCard: {},
  profileHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  profileAvatar: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  profileName: { fontSize: Typography.lg, fontWeight: '800', color: Colors.text },
  profileEmail: { fontSize: Typography.sm, color: Colors.textSecondary, marginTop: 2 },
  profileFarm: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 3 },
  editProfileBtn: { padding: 8, backgroundColor: '#E8F5E9', borderRadius: Radius.round },
  profileForm: { marginTop: Spacing.lg, gap: Spacing.sm },
  formField: {},
  formLabel: { fontSize: Typography.xs, fontWeight: '700', color: Colors.textSecondary, marginBottom: 5, textTransform: 'uppercase', letterSpacing: 0.4 },
  formInput: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: Colors.surfaceSecondary, borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: 10, borderWidth: 1, borderColor: Colors.border },
  formInputDark: { backgroundColor: Colors.darkSurfaceSecondary, borderColor: Colors.darkBorder },
  formInputText: { flex: 1, fontSize: Typography.base, color: Colors.text },
  section: { gap: 6 },
  sectionTitle: { fontSize: Typography.xs, fontWeight: '700', color: Colors.textMuted, letterSpacing: 1, paddingLeft: 4 },
  settingRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, padding: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border },
  settingRowDark: { borderBottomColor: Colors.darkBorder },
  settingIcon: { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  settingInfo: { flex: 1 },
  settingLabel: { fontSize: Typography.base, fontWeight: '600', color: Colors.text },
  settingSubtitle: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 1 },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: '#FFEBEE', borderRadius: Radius.lg, paddingVertical: 14, borderWidth: 1.5, borderColor: Colors.dangerLight },
  logoutBtnDark: { backgroundColor: '#2A1515' },
  logoutText: { fontSize: Typography.md, fontWeight: '700', color: Colors.danger },
  version: { textAlign: 'center', fontSize: Typography.xs, color: Colors.textMuted },
});
