import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Modal, TextInput, Alert, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { BarChart, LineChart } from 'react-native-chart-kit';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader, PrimaryButton, AnimalAvatar } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

const { width } = Dimensions.get('window');

export default function MilkProductionScreen({ route, navigation }) {
  const { animalId } = route.params || {};
  const { state, dispatch } = useApp();
  const dark = state.darkMode;
  const [showLogModal, setShowLogModal] = useState(false);
  const [selectedAnimalId, setSelectedAnimalId] = useState(animalId || state.animals.find(a => a.milk)?.id);
  const [log, setLog] = useState({ morning: '', evening: '', quality: 'A', notes: '' });

  const milkAnimals = state.animals.filter(a => a.milk);
  const animal = milkAnimals.find(a => a.id === selectedAnimalId) || milkAnimals[0];
  const m = animal?.milk;

  const handleAddLog = () => {
    if (!log.morning || !log.evening) {
      Alert.alert('Required', 'Please enter both morning and evening values');
      return;
    }
    dispatch({
      type: 'ADD_MILK_LOG',
      payload: {
        animalId: animal.id,
        log: {
          id: `ml-${Date.now()}`,
          date: new Date().toISOString(),
          morning: parseFloat(log.morning),
          evening: parseFloat(log.evening),
          quality: log.quality,
          notes: log.notes,
        },
      },
    });
    setShowLogModal(false);
    setLog({ morning: '', evening: '', quality: 'A', notes: '' });
    Alert.alert('Success', 'Milk log added!');
  };

  const exportCSV = () => {
    Alert.alert('Export CSV', 'In production, this would generate and share a CSV file via expo-sharing and expo-file-system.');
  };

  const totalFarm = milkAnimals.reduce((sum, a) => sum + (a.milk?.currentDaily || 0), 0).toFixed(1);
  const weekLabels = m?.weeklyData?.map(d => d.day) || [];
  const weekTotals = m?.weeklyData?.map(d => d.morning + d.evening) || [];

  const prevWeekAvg = 12.5;
  const pctChange = m ? (((m.avgDaily - prevWeekAvg) / prevWeekAvg) * 100).toFixed(1) : 0;

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader
        title="Milk Production"
        subtitle="Daily tracking & analytics"
        dark={dark}
        onBack={navigation.canGoBack?.() ? () => navigation.goBack() : undefined}
        onMenu={navigation.openDrawer ? () => navigation.openDrawer() : undefined}
        rightComponent={
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TouchableOpacity onPress={exportCSV} style={[styles.iconBtn, dark && { backgroundColor: Colors.darkSurfaceSecondary }]}>
              <MaterialCommunityIcons name="download" size={18} color={Colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setShowLogModal(true)} style={styles.addLogBtn}>
              <MaterialCommunityIcons name="plus" size={18} color="#fff" />
            </TouchableOpacity>
          </View>
        }
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Farm Total */}
        <Card dark={dark} style={styles.farmTotal}>
          <MaterialCommunityIcons name="water" size={32} color={Colors.info} />
          <View>
            <Text style={[styles.farmTotalValue, dark && { color: Colors.darkText }]}>{totalFarm} L</Text>
            <Text style={[styles.farmTotalLabel, dark && { color: Colors.darkTextSecondary }]}>
              Total Farm Production Today
            </Text>
          </View>
          <View style={[styles.changeBadge, { backgroundColor: pctChange >= 0 ? '#E8F5E9' : '#FFEBEE' }]}>
            <MaterialCommunityIcons name={pctChange >= 0 ? 'trending-up' : 'trending-down'} size={16} color={pctChange >= 0 ? Colors.success : Colors.danger} />
            <Text style={{ fontSize: Typography.sm, fontWeight: '700', color: pctChange >= 0 ? Colors.success : Colors.danger }}>
              {pctChange >= 0 ? '+' : ''}{pctChange}%
            </Text>
          </View>
        </Card>

        {/* Animal Selector */}
        <Text style={[styles.sectionLabel, dark && { color: Colors.darkText }]}>Select Animal</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.animalScroll} contentContainerStyle={{ gap: 10 }}>
          {milkAnimals.map(a => (
            <TouchableOpacity
              key={a.id}
              onPress={() => setSelectedAnimalId(a.id)}
              style={[styles.animalPill, selectedAnimalId === a.id && { borderColor: Colors.primary, borderWidth: 2 }, dark && styles.animalPillDark]}
              activeOpacity={0.8}
            >
              <AnimalAvatar animal={a} size={32} />
              <View>
                <Text style={[styles.animalPillName, dark && { color: Colors.darkText }]}>{a.name}</Text>
                <Text style={[styles.animalPillMilk, dark && { color: Colors.darkTextMuted }]}>{a.milk?.currentDaily}L</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Stats cards */}
        {m && (
          <>
            <View style={styles.statsRow}>
              {[
                { label: 'Today', value: `${m.currentDaily}L`, icon: 'calendar-today', color: Colors.primary },
                { label: 'This Month', value: `${m.monthlyTotal}L`, icon: 'calendar-month', color: Colors.accent },
                { label: 'Daily Avg', value: `${m.avgDaily}L`, icon: 'chart-line', color: Colors.info },
              ].map(s => (
                <Card key={s.label} dark={dark} style={styles.statCard}>
                  <MaterialCommunityIcons name={s.icon} size={20} color={s.color} />
                  <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
                  <Text style={[styles.statLabel, dark && { color: Colors.darkTextMuted }]}>{s.label}</Text>
                </Card>
              ))}
            </View>

            {/* 7-Day Chart */}
            <Card dark={dark}>
              <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>7-Day Production</Text>
              <BarChart
                data={{ labels: weekLabels, datasets: [{ data: weekTotals }] }}
                width={width - 64}
                height={180}
                chartConfig={{
                  backgroundGradientFrom: dark ? Colors.darkSurface : Colors.surface,
                  backgroundGradientTo: dark ? Colors.darkSurface : Colors.surface,
                  color: (opacity) => `rgba(2, 136, 209, ${opacity})`,
                  labelColor: (o) => dark ? `rgba(165,200,167,${o})` : `rgba(90,116,96,${o})`,
                  decimalPlaces: 1,
                }}
                style={{ borderRadius: Radius.lg, marginLeft: -16 }}
                fromZero
                showValuesOnTopOfBars
              />
            </Card>

            {/* Daily Logs */}
            <Card dark={dark}>
              <View style={styles.logsHeader}>
                <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Daily Log</Text>
                <TouchableOpacity onPress={exportCSV} style={styles.exportBtn}>
                  <MaterialCommunityIcons name="file-export" size={16} color={Colors.primary} />
                  <Text style={styles.exportText}>Export CSV</Text>
                </TouchableOpacity>
              </View>
              {/* Table header */}
              <View style={styles.tableHeader}>
                {['Date', '🌅 AM', '🌙 PM', 'Total', 'Grade'].map(h => (
                  <Text key={h} style={[styles.tableHeaderText, dark && { color: Colors.darkTextMuted }]}>{h}</Text>
                ))}
              </View>
              {m.logs.map(log => (
                <View key={log.id} style={[styles.tableRow, dark && styles.tableRowDark]}>
                  <Text style={[styles.tableCell, dark && { color: Colors.darkText }]}>
                    {new Date(log.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                  </Text>
                  <Text style={[styles.tableCell, dark && { color: Colors.darkText }]}>{log.morning}L</Text>
                  <Text style={[styles.tableCell, dark && { color: Colors.darkText }]}>{log.evening}L</Text>
                  <Text style={[styles.tableCell, { fontWeight: '800', color: Colors.primary }]}>
                    {(log.morning + log.evening).toFixed(1)}L
                  </Text>
                  <View style={[styles.gradeChip, { backgroundColor: log.quality === 'A' ? '#E8F5E9' : '#FFF8E1' }]}>
                    <Text style={{ fontSize: 12, fontWeight: '700', color: log.quality === 'A' ? Colors.success : Colors.accent }}>{log.quality}</Text>
                  </View>
                </View>
              ))}
            </Card>
          </>
        )}
      </ScrollView>

      {/* Add Log Modal */}
      <Modal visible={showLogModal} animationType="slide" transparent>
        <View style={styles.overlay}>
          <View style={[styles.sheet, dark && styles.sheetDark]}>
            <View style={styles.sheetHeader}>
              <Text style={[styles.sheetTitle, dark && { color: Colors.darkText }]}>Log Milk Production</Text>
              <TouchableOpacity onPress={() => setShowLogModal(false)}>
                <MaterialCommunityIcons name="close" size={22} color={dark ? Colors.darkTextSecondary : Colors.textSecondary} />
              </TouchableOpacity>
            </View>
            <Text style={[styles.sheetSubtitle, dark && { color: Colors.darkTextSecondary }]}>
              {animal?.name} · {new Date().toLocaleDateString()}
            </Text>

            {[
              { key: 'morning', label: '🌅 Morning (L)', placeholder: 'e.g. 7.5' },
              { key: 'evening', label: '🌙 Evening (L)', placeholder: 'e.g. 6.2' },
            ].map(f => (
              <View key={f.key} style={styles.field}>
                <Text style={[styles.fieldLabel, dark && { color: Colors.darkTextSecondary }]}>{f.label}</Text>
                <TextInput
                  value={log[f.key]}
                  onChangeText={v => setLog(l => ({ ...l, [f.key]: v }))}
                  placeholder={f.placeholder}
                  placeholderTextColor={dark ? Colors.darkTextMuted : Colors.placeholder}
                  keyboardType="decimal-pad"
                  style={[styles.fieldInput, dark && styles.fieldInputDark]}
                />
              </View>
            ))}

            <View style={styles.field}>
              <Text style={[styles.fieldLabel, dark && { color: Colors.darkTextSecondary }]}>Milk Quality Grade</Text>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                {['A', 'B', 'C'].map(q => (
                  <TouchableOpacity key={q} onPress={() => setLog(l => ({ ...l, quality: q }))}
                    style={[styles.gradeBtn, log.quality === q && styles.gradeBtnActive]}>
                    <Text style={[styles.gradeBtnText, log.quality === q && styles.gradeBtnTextActive]}>Grade {q}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <PrimaryButton title="Save Log" onPress={handleAddLog} icon="content-save" style={{ marginTop: Spacing.md }} />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  content: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 40 },
  iconBtn: { padding: 8, backgroundColor: Colors.surfaceSecondary, borderRadius: Radius.md },
  addLogBtn: { padding: 8, backgroundColor: Colors.primary, borderRadius: Radius.md },
  farmTotal: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  farmTotalValue: { fontSize: Typography.xxl, fontWeight: '900', color: Colors.text },
  farmTotalLabel: { fontSize: Typography.xs, color: Colors.textSecondary },
  changeBadge: { marginLeft: 'auto', flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 6, borderRadius: Radius.round },
  sectionLabel: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text, textTransform: 'uppercase', letterSpacing: 0.5 },
  animalScroll: { marginBottom: Spacing.sm },
  animalPill: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, backgroundColor: Colors.surface, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border, ...{ shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3, elevation: 2 } },
  animalPillDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  animalPillName: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text },
  animalPillMilk: { fontSize: Typography.xs, color: Colors.textMuted },
  statsRow: { flexDirection: 'row', gap: Spacing.sm },
  statCard: { flex: 1, alignItems: 'center', gap: 4, paddingVertical: Spacing.md },
  statValue: { fontSize: Typography.lg, fontWeight: '800' },
  statLabel: { fontSize: 10, color: Colors.textMuted, textAlign: 'center' },
  cardTitle: { fontSize: Typography.md, fontWeight: '700', color: Colors.text, marginBottom: Spacing.md },
  logsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
  exportBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  exportText: { fontSize: Typography.xs, color: Colors.primary, fontWeight: '600' },
  tableHeader: { flexDirection: 'row', paddingBottom: 8, borderBottomWidth: 2, borderBottomColor: Colors.primary, marginBottom: 4 },
  tableHeaderText: { flex: 1, fontSize: 10, fontWeight: '700', color: Colors.textMuted, textTransform: 'uppercase' },
  tableRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: Colors.border },
  tableRowDark: { borderBottomColor: Colors.darkBorder },
  tableCell: { flex: 1, fontSize: Typography.xs, color: Colors.text },
  gradeChip: { flex: 1, alignItems: 'flex-start', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: Spacing.xl },
  sheetDark: { backgroundColor: Colors.darkSurface },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  sheetTitle: { fontSize: Typography.lg, fontWeight: '700', color: Colors.text },
  sheetSubtitle: { fontSize: Typography.sm, color: Colors.textSecondary, marginBottom: Spacing.lg },
  field: { marginBottom: Spacing.md },
  fieldLabel: { fontSize: Typography.xs, fontWeight: '600', color: Colors.textSecondary, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.4 },
  fieldInput: { backgroundColor: Colors.surfaceSecondary, borderRadius: Radius.md, padding: Spacing.md, fontSize: Typography.md, color: Colors.text, borderWidth: 1, borderColor: Colors.border },
  fieldInputDark: { backgroundColor: Colors.darkSurfaceSecondary, color: Colors.darkText, borderColor: Colors.darkBorder },
  gradeBtn: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: Radius.md, borderWidth: 1.5, borderColor: Colors.border },
  gradeBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  gradeBtnText: { fontSize: Typography.sm, color: Colors.textSecondary, fontWeight: '600' },
  gradeBtnTextActive: { color: '#fff' },
});
