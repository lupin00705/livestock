import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader, AnimalAvatar } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

const STATUS_CONFIG = {
  pregnant: { color: Colors.info, bg: '#E3F2FD', icon: 'baby-carriage', label: 'Pregnant' },
  open: { color: Colors.accent, bg: '#FFF8E1', icon: 'heart', label: 'Open' },
  lactating: { color: Colors.success, bg: '#E8F5E9', icon: 'water', label: 'Lactating' },
  dry: { color: Colors.textMuted, bg: '#F5F5F5', icon: 'water-off', label: 'Dry' },
};

function CalendarHeatMap({ events, dark }) {
  const days = ['S','M','T','W','T','F','S'];
  const today = new Date();
  const cells = Array.from({ length: 35 }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() - 17 + i);
    const hasEvent = events.some(e => {
      const ed = new Date(e.date);
      return ed.toDateString() === d.toDateString();
    });
    const event = hasEvent ? events.find(e => new Date(e.date).toDateString() === d.toDateString()) : null;
    const isToday = d.toDateString() === today.toDateString();
    return { date: d, event, isToday };
  });

  return (
    <View>
      <View style={styles.calDayRow}>
        {days.map((d, i) => <Text key={i} style={[styles.calDayLabel, dark && { color: Colors.darkTextMuted }]}>{d}</Text>)}
      </View>
      <View style={styles.calGrid}>
        {cells.map((cell, i) => (
          <View key={i} style={[
            styles.calCell,
            cell.isToday && styles.calCellToday,
            cell.event && { backgroundColor: cell.event.intensity === 'high' ? Colors.danger + '60' : Colors.warning + '40' },
            dark && !cell.event && !cell.isToday && { backgroundColor: Colors.darkSurfaceSecondary },
          ]}>
            <Text style={[styles.calCellText, cell.isToday && { color: '#fff' }, dark && !cell.isToday && { color: Colors.darkTextSecondary }]}>
              {cell.date.getDate()}
            </Text>
            {cell.event && <View style={[styles.calDot, { backgroundColor: Colors.danger }]} />}
          </View>
        ))}
      </View>
      <View style={styles.calLegend}>
        <View style={styles.calLegendItem}>
          <View style={[styles.calLegendDot, { backgroundColor: Colors.danger + '60' }]} />
          <Text style={[styles.calLegendText, dark && { color: Colors.darkTextMuted }]}>High intensity heat</Text>
        </View>
        <View style={styles.calLegendItem}>
          <View style={[styles.calLegendDot, { backgroundColor: Colors.warning + '40' }]} />
          <Text style={[styles.calLegendText, dark && { color: Colors.darkTextMuted }]}>Medium heat</Text>
        </View>
      </View>
    </View>
  );
}

export default function ReproductionScreen({ route, navigation }) {
  const { animalId } = route.params || {};
  const { state } = useApp();
  const dark = state.darkMode;
  const [selectedId, setSelectedId] = useState(animalId || state.animals[0]?.id);
  const animal = state.animals.find(a => a.id === selectedId) || state.animals[0];
  const r = animal?.reproduction;

  const pregnantAnimals = state.animals.filter(a => a.reproduction?.status === 'pregnant');
  const heatAnimals = state.animals.filter(a => {
    const nextHeat = a.reproduction?.nextExpectedHeat;
    if (!nextHeat) return false;
    const daysUntil = Math.ceil((new Date(nextHeat) - new Date()) / 86400000);
    return daysUntil >= 0 && daysUntil <= 5;
  });

  const daysToDelivery = r?.expectedDelivery
    ? Math.max(0, Math.ceil((new Date(r.expectedDelivery) - new Date()) / 86400000))
    : null;

  const statusCfg = STATUS_CONFIG[r?.status] || STATUS_CONFIG.open;

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader
        title="Reproduction Tracker"
        subtitle={`${pregnantAnimals.length} pregnant, ${heatAnimals.length} in heat soon`}
        dark={dark}
        onBack={navigation.canGoBack?.() ? () => navigation.goBack() : undefined}
        onMenu={navigation.openDrawer ? () => navigation.openDrawer() : undefined}
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Pregnant animals alert */}
        {pregnantAnimals.length > 0 && (
          <View style={styles.pregnantAlert}>
            <MaterialCommunityIcons name="baby-carriage" size={20} color={Colors.info} />
            <Text style={styles.pregnantAlertText}>
              {pregnantAnimals.map(a => a.name).join(', ')} {pregnantAnimals.length === 1 ? 'is' : 'are'} currently pregnant
            </Text>
          </View>
        )}

        {/* Animal selector */}
        <Text style={[styles.sectionLabel, dark && { color: Colors.darkText }]}>Select Animal</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.animalScroll} contentContainerStyle={{ gap: 8 }}>
          {state.animals.map(a => {
            const cfg = STATUS_CONFIG[a.reproduction?.status] || STATUS_CONFIG.open;
            return (
              <TouchableOpacity
                key={a.id}
                onPress={() => setSelectedId(a.id)}
                style={[styles.animalChip, selectedId === a.id && { borderColor: Colors.primary, borderWidth: 2 }, dark && styles.animalChipDark]}
                activeOpacity={0.8}
              >
                <AnimalAvatar animal={a} size={32} />
                <View>
                  <Text style={[styles.animalChipName, dark && { color: Colors.darkText }]}>{a.name}</Text>
                  <View style={[styles.repStatusPill, { backgroundColor: cfg.bg }]}>
                    <Text style={[styles.repStatusText, { color: cfg.color }]}>{cfg.label}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Selected animal status */}
        <Card dark={dark} style={styles.statusCard}>
          <View style={styles.statusCardTop}>
            <AnimalAvatar animal={animal} size={56} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.animalName, dark && { color: Colors.darkText }]}>{animal?.name}</Text>
              <Text style={[styles.animalSpecies, dark && { color: Colors.darkTextSecondary }]}>{animal?.species} · {animal?.breed}</Text>
            </View>
            <View style={[styles.statusBadge, { backgroundColor: statusCfg.bg }]}>
              <MaterialCommunityIcons name={statusCfg.icon} size={16} color={statusCfg.color} />
              <Text style={[styles.statusBadgeText, { color: statusCfg.color }]}>{statusCfg.label}</Text>
            </View>
          </View>

          {/* Pregnancy countdown */}
          {r?.status === 'pregnant' && daysToDelivery !== null && (
            <View style={styles.countdownBox}>
              <MaterialCommunityIcons name="baby-carriage" size={28} color={Colors.info} />
              <View>
                <Text style={styles.countdownValue}>{daysToDelivery} days</Text>
                <Text style={[styles.countdownLabel, dark && { color: Colors.darkTextSecondary }]}>
                  Until expected delivery · {new Date(r.expectedDelivery).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                </Text>
              </View>
            </View>
          )}

          {/* Info grid */}
          <View style={styles.infoGrid}>
            {[
              { label: 'Last Heat', value: r?.lastHeat ? new Date(r.lastHeat).toLocaleDateString() : 'N/A' },
              { label: 'Next Expected Heat', value: r?.nextExpectedHeat ? new Date(r.nextExpectedHeat).toLocaleDateString() : 'N/A' },
              { label: 'Breeding Date', value: r?.pregnancyDate ? new Date(r.pregnancyDate).toLocaleDateString() : 'N/A' },
              { label: 'Due Date', value: r?.expectedDelivery ? new Date(r.expectedDelivery).toLocaleDateString() : 'N/A' },
            ].map(item => (
              <View key={item.label} style={styles.infoItem}>
                <Text style={[styles.infoLabel, dark && { color: Colors.darkTextMuted }]}>{item.label}</Text>
                <Text style={[styles.infoValue, dark && { color: Colors.darkText }]}>{item.value}</Text>
              </View>
            ))}
          </View>
        </Card>

        {/* Heat Calendar */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Heat Calendar</Text>
          <CalendarHeatMap events={r?.heatCalendar || []} dark={dark} />
        </Card>

        {/* Breeding Log */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Breeding Log</Text>
          {r?.breedingLog.map(b => (
            <View key={b.id} style={[styles.breedRow, dark && styles.breedRowDark]}>
              <View style={[styles.breedDot, { backgroundColor: b.result.includes('pregnant') ? Colors.success : Colors.textMuted }]} />
              <View style={{ flex: 1 }}>
                <View style={styles.breedTop}>
                  <Text style={[styles.breedSire, dark && { color: Colors.darkText }]}>{b.sire}</Text>
                  <View style={[styles.breedMethodBadge, { backgroundColor: b.method === 'Natural' ? '#E8F5E9' : '#E3F2FD' }]}>
                    <Text style={[styles.breedMethodText, { color: b.method === 'Natural' ? Colors.success : Colors.info }]}>{b.method}</Text>
                  </View>
                </View>
                <Text style={[styles.breedDate, dark && { color: Colors.darkTextMuted }]}>
                  {new Date(b.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                </Text>
                <Text style={[styles.breedResult, { color: b.result.includes('pregnant') ? Colors.success : Colors.textMuted }]}>
                  {b.result}
                </Text>
              </View>
            </View>
          ))}
          <TouchableOpacity style={styles.addBreedBtn} activeOpacity={0.85}>
            <MaterialCommunityIcons name="plus" size={16} color={Colors.primary} />
            <Text style={styles.addBreedText}>Add Breeding Record</Text>
          </TouchableOpacity>
        </Card>

        {/* Offspring */}
        {r?.offspring.length > 0 && (
          <Card dark={dark}>
            <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Offspring</Text>
            {r.offspring.map(o => (
              <View key={o.id} style={[styles.offspringRow, dark && { backgroundColor: Colors.darkSurfaceSecondary }]}>
                <MaterialCommunityIcons name="baby-carriage" size={24} color={Colors.accent} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.offspringTag, dark && { color: Colors.darkText }]}>{o.tagNumber} · {o.sex}</Text>
                  <Text style={[styles.offspringMeta, dark && { color: Colors.darkTextMuted }]}>
                    Born {new Date(o.dob).toLocaleDateString()} · Birth weight: {o.weight}
                  </Text>
                </View>
              </View>
            ))}
          </Card>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  content: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 40 },
  pregnantAlert: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#E3F2FD', padding: Spacing.md, borderRadius: Radius.lg },
  pregnantAlertText: { flex: 1, fontSize: Typography.sm, color: Colors.info, fontWeight: '500' },
  sectionLabel: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text, textTransform: 'uppercase', letterSpacing: 0.5 },
  animalScroll: {},
  animalChip: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, backgroundColor: Colors.surface, borderRadius: Radius.lg, borderWidth: 1, borderColor: Colors.border },
  animalChipDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  animalChipName: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text },
  repStatusPill: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: Radius.round },
  repStatusText: { fontSize: 10, fontWeight: '700' },
  statusCard: {},
  statusCardTop: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginBottom: Spacing.md },
  animalName: { fontSize: Typography.xl, fontWeight: '800', color: Colors.text },
  animalSpecies: { fontSize: Typography.sm, color: Colors.textSecondary },
  statusBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: Radius.round },
  statusBadgeText: { fontSize: Typography.xs, fontWeight: '700' },
  countdownBox: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, backgroundColor: '#E3F2FD', borderRadius: Radius.lg, padding: Spacing.md, marginBottom: Spacing.md },
  countdownValue: { fontSize: Typography.xl, fontWeight: '800', color: Colors.info },
  countdownLabel: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
  infoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  infoItem: { width: '48%' },
  infoLabel: { fontSize: Typography.xs, color: Colors.textMuted, marginBottom: 2 },
  infoValue: { fontSize: Typography.sm, fontWeight: '700', color: Colors.text },
  cardTitle: { fontSize: Typography.md, fontWeight: '700', color: Colors.text, marginBottom: Spacing.md },
  calDayRow: { flexDirection: 'row', marginBottom: 4 },
  calDayLabel: { flex: 1, textAlign: 'center', fontSize: 11, fontWeight: '700', color: Colors.textMuted },
  calGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 2 },
  calCell: { width: `${(100 - 3 * 6) / 7}%`, aspectRatio: 1, borderRadius: 6, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.surfaceSecondary },
  calCellToday: { backgroundColor: Colors.primary },
  calCellText: { fontSize: 12, fontWeight: '500', color: Colors.text },
  calDot: { width: 4, height: 4, borderRadius: 2, position: 'absolute', bottom: 3 },
  calLegend: { flexDirection: 'row', gap: Spacing.lg, marginTop: Spacing.md, justifyContent: 'center' },
  calLegendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  calLegendDot: { width: 12, height: 12, borderRadius: 6 },
  calLegendText: { fontSize: Typography.xs, color: Colors.textMuted },
  breedRow: { flexDirection: 'row', gap: Spacing.md, paddingBottom: Spacing.md, marginBottom: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border },
  breedRowDark: { borderBottomColor: Colors.darkBorder },
  breedDot: { width: 12, height: 12, borderRadius: 6, marginTop: 4 },
  breedTop: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  breedSire: { flex: 1, fontSize: Typography.base, fontWeight: '700', color: Colors.text },
  breedMethodBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: Radius.round },
  breedMethodText: { fontSize: Typography.xs, fontWeight: '700' },
  breedDate: { fontSize: Typography.xs, color: Colors.textMuted },
  breedResult: { fontSize: Typography.sm, fontWeight: '600', marginTop: 4 },
  addBreedBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: Spacing.md, paddingVertical: 10, borderRadius: Radius.md, borderWidth: 2, borderColor: Colors.primary, borderStyle: 'dashed' },
  addBreedText: { fontSize: Typography.sm, color: Colors.primary, fontWeight: '700' },
  offspringRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, backgroundColor: '#FFF8E1', borderRadius: Radius.md, padding: Spacing.md, marginBottom: Spacing.sm },
  offspringTag: { fontSize: Typography.base, fontWeight: '700', color: Colors.text },
  offspringMeta: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 2 },
});
