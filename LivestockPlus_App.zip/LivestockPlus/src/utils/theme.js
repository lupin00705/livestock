export const Colors = {
  primary: '#2E7D32',
  primaryLight: '#4CAF50',
  primaryDark: '#1B5E20',
  accent: '#FF8F00',
  accentLight: '#FFB300',
  danger: '#D32F2F',
  dangerLight: '#EF5350',
  warning: '#F57C00',
  warningLight: '#FFA726',
  success: '#388E3C',
  info: '#0288D1',

  // Light theme
  background: '#F9FAF7',
  surface: '#FFFFFF',
  surfaceSecondary: '#F1F4F0',
  border: '#E0E6DC',
  text: '#1A2E1B',
  textSecondary: '#5A7460',
  textMuted: '#8FAB92',
  placeholder: '#A8C4AA',

  // Dark theme
  darkBackground: '#121212',
  darkSurface: '#1E1E1E',
  darkSurfaceSecondary: '#2A2A2A',
  darkBorder: '#333333',
  darkText: '#E8F5E9',
  darkTextSecondary: '#A5C8A7',
  darkTextMuted: '#6B9B6D',

  // Status
  statusHealthy: '#4CAF50',
  statusWarning: '#FF9800',
  statusCritical: '#F44336',
  statusOffline: '#9E9E9E',

  // Charts
  chartGreen: '#4CAF50',
  chartBlue: '#2196F3',
  chartOrange: '#FF9800',
  chartPurple: '#9C27B0',
};

export const Typography = {
  // Font sizes
  xs: 10,
  sm: 12,
  base: 14,
  md: 16,
  lg: 18,
  xl: 22,
  xxl: 28,
  xxxl: 36,

  // Font weights
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
  heavy: '800',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 40,
};

export const Radius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  xxl: 24,
  round: 999,
};

export const Shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 3,
    elevation: 2,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
};
