import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../../context/AppContext';
import {
  Card, StatusBadge, AnimalAvatar, SectionTitle, EmptyState,
} from '../../components/common';
import { Colors, Typography, Spacing, Radius, Shadows } from '../../utils/theme';

const { width } = Dimensions.get('window');

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good Morning';
  if (h < 17) return 'Good Afternoon';
  return 'Good Evening';
}

function AlertSummaryCard({ critical, warning, normal, offline, dark, onPress }) {
  const items = [
    { label: 'Critical', value: critical, color: Colors.danger, bg: '#FFEBEE', icon: 'alert-circle' },
    { label: 'Warning', value: warning, color: Colors.warning, bg: '#FFF3E0', icon: 'alert' },
    { label: 'Normal', value: normal, color: Colors.success, bg: '#E8F5E9', icon: 'check-circle' },
    { label: 'Offline', value: offline, color: Colors.statusOffline, bg: '#F5F5F5', icon: 'wifi-off' },
  ];
  return (
    <Card dark={dark} style={styles.alertSummaryCard}>
      <View style={styles.alertSummaryHeader}>
        <Text style={[styles.sectionText, dark && { color: Colors.darkText }]}>Alert Summary</Text>
        <TouchableOpacity onPress={onPress}>
          <Text style={{ color: Colors.primary, fontSize: Typography.sm, fontWeight: '600' }}>View All</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.alertGrid}>
        {items.map(item => (
          <View key={item.label} style={[styles.alertItem, { backgroundColor: item.bg }]}>
            <MaterialCommunityIcons name={item.icon} size={22} color={item.color} />
            <Text style={[styles.alertItemValue, { color: item.color }]}>{item.value}</Text>
            <Text style={styles.alertItemLabel}>{item.label}</Text>
          </View>
        ))}
      </View>
    </Card>
  );
}

function QuickStatCard({ label, value, unit, icon, color, dark }) {
  return (
    <Card dark={dark} style={styles.quickStat}>
      <View style={[styles.quickStatIcon, { backgroundColor: color + '20' }]}>
        <MaterialCommunityIcons name={icon} size={20} color={color} />
      </View>
      <Text style={[styles.quickStatValue, dark && { color: Colors.darkText }]}>
        {value}<Text style={{ fontSize: Typography.sm, fontWeight: '400' }}>{unit}</Text>
      </Text>
      <Text style={[styles.quickStatLabel, dark && { color: Colors.darkTextMuted }]}>{label}</Text>
    </Card>
  );
}

function AnimalAlertRow({ animal, dark, onPress }) {
  const temp = animal.sensors?.temperature?.value;
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85} style={[styles.animalRow, dark && styles.animalRowDark]}>
      <AnimalAvatar animal={animal} size={44} />
      <View style={styles.animalRowInfo}>
        <Text style={[styles.animalRowName, dark && { color: Colors.darkText }]}>{animal.name}</Text>
        <Text style={[styles.animalRowSpecies, dark && { color: Colors.darkTextSecondary }]}>
          {animal.species} • {animal.breed}
        </Text>
      </View>
      <View style={styles.animalRowRight}>
        {temp && (
          <Text style={[styles.animalRowTemp, { color: temp > 39.5 ? Colors.danger : temp > 39 ? Colors.warning : Colors.success }]}>
            {temp}°C
          </Text>
        )}
        <StatusBadge status={animal.status} size="sm" />
      </View>
    </TouchableOpacity>
  );
}

export default function DashboardScreen({ navigation }) {
  const { state } = useApp();
  const dark = state.darkMode;
  const [refreshing, setRefreshing] = useState(false);
  const [bannerAlert, setBannerAlert] = useState(
    state.alerts.find(a => !a.resolved && a.type === 'critical') || null
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await new Promise(r => setTimeout(r, 1500));
    setRefreshing(false);
  }, []);

  const alertAnimals = state.animals.filter(a => a.status === 'critical' || a.status === 'warning');
  const { farmStats } = state;
  const criticalAlerts = state.alerts.filter(a => !a.resolved && a.type === 'critical').length;
  const warningAlerts = state.alerts.filter(a => !a.resolved && a.type === 'warning').length;
  const normalAlerts = state.alerts.filter(a => !a.resolved && a.type === 'normal').length;

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      {/* Critical Alert Banner */}
      {bannerAlert && (
        <View style={styles.banner}>
          <MaterialCommunityIcons name="alert-circle" size={18} color="#fff" />
          <Text style={styles.bannerText} numberOfLines={1}>{bannerAlert.title}: {bannerAlert.animalName}</Text>
          <TouchableOpacity onPress={() => setBannerAlert(null)} style={{ padding: 4 }}>
            <MaterialCommunityIcons name="close" size={16} color="#fff" />
          </TouchableOpacity>
        </View>
      )}

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />
        }
      >
        {/* Header */}
        <LinearGradient
          colors={dark ? [Colors.primaryDark, '#1A3A1C'] : [Colors.primaryDark, Colors.primary]}
          style={styles.headerGrad}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        >
          <View style={styles.headerTop}>
            <View>
              <Text style={styles.greeting}>{getGreeting()},</Text>
              <Text style={styles.userName}>{state.user?.name?.split(' ')[0] || 'Farmer'} 👋</Text>
              <View style={styles.farmNameRow}>
                <MaterialCommunityIcons name="map-marker" size={14} color="rgba(255,255,255,0.7)" />
                <Text style={styles.farmName}>{farmStats.name}</Text>
              </View>
            </View>
            <TouchableOpacity
              onPress={() => navigation.getParent()?.navigate('AlertsDrawer')}
              style={styles.notifBtn}
            >
              <MaterialCommunityIcons name="bell-outline" size={24} color="#fff" />
              {criticalAlerts > 0 && (
                <View style={styles.notifBadge}>
                  <Text style={styles.notifBadgeText}>{criticalAlerts}</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          {/* Summary row */}
          <View style={styles.summaryRow}>
            {[
              { label: 'Cattle', value: farmStats.cattle, icon: 'cow' },
              { label: 'Goats', value: farmStats.goats, icon: 'goat' },
              { label: 'Sheep', value: farmStats.sheep, icon: 'sheep' },
            ].map(item => (
              <View key={item.label} style={styles.summaryItem}>
                <MaterialCommunityIcons name={item.icon} size={22} color="rgba(255,255,255,0.9)" />
                <Text style={styles.summaryValue}>{item.value}</Text>
                <Text style={styles.summaryLabel}>{item.label}</Text>
              </View>
            ))}
          </View>
        </LinearGradient>

        <View style={styles.body}>
          {/* Quick Stats */}
          <View style={styles.quickStatsRow}>
            <QuickStatCard
              label="Avg Temp"
              value={farmStats.avgTemperature}
              unit="°C"
              icon="thermometer"
              color={Colors.danger}
              dark={dark}
            />
            <QuickStatCard
              label="Milk Today"
              value={farmStats.totalMilkToday}
              unit="L"
              icon="water"
              color={Colors.info}
              dark={dark}
            />
            <QuickStatCard
              label="Total Alerts"
              value={farmStats.totalAlerts}
              unit=""
              icon="bell"
              color={Colors.accent}
              dark={dark}
            />
          </View>

          {/* Alert Summary */}
          <AlertSummaryCard
            critical={criticalAlerts}
            warning={warningAlerts}
            normal={normalAlerts}
            offline={state.animals.filter(a => a.status === 'offline').length}
            dark={dark}
            onPress={() => navigation.getParent()?.navigate('AlertsDrawer')}
          />

          {/* Animals needing attention */}
          <SectionTitle
            title="Needs Attention"
            action={{
              label: 'View All',
              onPress: () => navigation.navigate('Animals'),
            }}
            dark={dark}
          />

          {alertAnimals.length > 0 ? (
            alertAnimals.map(animal => (
              <AnimalAlertRow
                key={animal.id}
                animal={animal}
                dark={dark}
                onPress={() => {
                  navigation.navigate('Animals', {
                    screen: 'AnimalDetail',
                    params: { animalId: animal.id },
                  });
                }}
              />
            ))
          ) : (
            <Card dark={dark} style={{ alignItems: 'center', paddingVertical: Spacing.xl }}>
              <MaterialCommunityIcons name="check-all" size={40} color={Colors.success} />
              <Text style={[{ marginTop: 8, fontWeight: '600', color: Colors.success }]}>
                All animals are healthy!
              </Text>
            </Card>
          )}

          {/* Recent Alerts */}
          <SectionTitle
            title="Recent Alerts"
            action={{
              label: 'See All',
              onPress: () => navigation.getParent()?.navigate('AlertsDrawer'),
            }}
            dark={dark}
          />

          {state.alerts.slice(0, 3).map(alert => (
            <Card key={alert.id} dark={dark} style={styles.alertCard}>
              <View style={[styles.alertDot, {
                backgroundColor: alert.type === 'critical' ? Colors.danger :
                  alert.type === 'warning' ? Colors.warning : Colors.info,
              }]} />
              <View style={styles.alertCardInfo}>
                <Text style={[styles.alertCardTitle, dark && { color: Colors.darkText }]} numberOfLines={1}>
                  {alert.title}
                </Text>
                <Text style={[styles.alertCardMeta, dark && { color: Colors.darkTextMuted }]}>
                  {alert.animalName} • {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
              {alert.resolved && (
                <View style={styles.resolvedBadge}>
                  <Text style={styles.resolvedText}>Resolved</Text>
                </View>
              )}
            </Card>
          ))}

          {/* Last sync */}
          <View style={styles.syncRow}>
            <MaterialCommunityIcons name="sync" size={14} color={Colors.textMuted} />
            <Text style={[styles.syncText, dark && { color: Colors.darkTextMuted }]}>
              Last sync: {state.lastSync
                ? new Date(state.lastSync).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                : 'Syncing...'}
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  banner: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.danger, paddingHorizontal: 16, paddingVertical: 10,
  },
  bannerText: { flex: 1, color: '#fff', fontSize: Typography.sm, fontWeight: '600' },
  headerGrad: { paddingHorizontal: Spacing.base, paddingTop: Spacing.base, paddingBottom: 28 },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.lg },
  greeting: { fontSize: Typography.sm, color: 'rgba(255,255,255,0.75)', fontWeight: '500' },
  userName: { fontSize: Typography.xxl, fontWeight: '800', color: '#fff', marginBottom: 4 },
  farmNameRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  farmName: { fontSize: Typography.sm, color: 'rgba(255,255,255,0.7)' },
  notifBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center', justifyContent: 'center',
  },
  notifBadge: {
    position: 'absolute', top: -2, right: -2,
    backgroundColor: Colors.danger, borderRadius: 10,
    minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: '#fff',
  },
  notifBadgeText: { color: '#fff', fontSize: 10, fontWeight: '800' },
  summaryRow: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: Radius.xl,
    padding: Spacing.md,
  },
  summaryItem: { flex: 1, alignItems: 'center', gap: 4 },
  summaryValue: { fontSize: Typography.xxl, fontWeight: '800', color: '#fff' },
  summaryLabel: { fontSize: Typography.xs, color: 'rgba(255,255,255,0.75)', fontWeight: '500' },
  body: { paddingHorizontal: Spacing.base, paddingTop: Spacing.base, paddingBottom: 100 },
  quickStatsRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.md },
  quickStat: { flex: 1, alignItems: 'center', gap: 4, paddingVertical: Spacing.base },
  quickStatIcon: { width: 38, height: 38, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 2 },
  quickStatValue: { fontSize: Typography.lg, fontWeight: '800', color: Colors.text },
  quickStatLabel: { fontSize: 10, color: Colors.textMuted, fontWeight: '500', textAlign: 'center' },
  alertSummaryCard: { marginBottom: Spacing.base },
  alertSummaryHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
  sectionText: { fontSize: Typography.md, fontWeight: '700', color: Colors.text },
  alertGrid: { flexDirection: 'row', gap: Spacing.sm },
  alertItem: { flex: 1, alignItems: 'center', gap: 4, padding: Spacing.sm, borderRadius: Radius.md },
  alertItemValue: { fontSize: Typography.xl, fontWeight: '800' },
  alertItemLabel: { fontSize: 10, color: Colors.textSecondary, fontWeight: '500' },
  animalRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surface, borderRadius: Radius.lg,
    padding: Spacing.md, marginBottom: Spacing.sm,
    ...Shadows.sm,
  },
  animalRowDark: { backgroundColor: Colors.darkSurface },
  animalRowInfo: { flex: 1 },
  animalRowName: { fontSize: Typography.md, fontWeight: '700', color: Colors.text },
  animalRowSpecies: { fontSize: Typography.xs, color: Colors.textSecondary, marginTop: 2 },
  animalRowRight: { alignItems: 'flex-end', gap: 4 },
  animalRowTemp: { fontSize: Typography.sm, fontWeight: '700' },
  alertCard: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    marginBottom: Spacing.sm, paddingVertical: Spacing.md,
  },
  alertDot: { width: 10, height: 10, borderRadius: 5 },
  alertCardInfo: { flex: 1 },
  alertCardTitle: { fontSize: Typography.base, fontWeight: '600', color: Colors.text },
  alertCardMeta: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 2 },
  resolvedBadge: { backgroundColor: '#E8F5E9', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 },
  resolvedText: { fontSize: 10, color: Colors.success, fontWeight: '600' },
  syncRow: { flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center', marginTop: Spacing.lg },
  syncText: { fontSize: Typography.xs, color: Colors.textMuted },
});
