import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ActivityIndicator,
  TextInput, ScrollView,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius, Shadows } from '../../utils/theme';

// ─── Card ───────────────────────────────────────────────────────────────────
export function Card({ children, style, onPress, dark }) {
  const Wrapper = onPress ? TouchableOpacity : View;
  return (
    <Wrapper
      onPress={onPress}
      activeOpacity={0.85}
      style={[
        styles.card,
        dark && styles.cardDark,
        style,
      ]}
    >
      {children}
    </Wrapper>
  );
}

// ─── Status Badge ────────────────────────────────────────────────────────────
export function StatusBadge({ status, size = 'md' }) {
  const config = {
    healthy: { color: Colors.statusHealthy, label: 'Healthy', bg: '#E8F5E9' },
    warning: { color: Colors.statusWarning, label: 'Warning', bg: '#FFF3E0' },
    critical: { color: Colors.statusCritical, label: 'Critical', bg: '#FFEBEE' },
    offline: { color: Colors.statusOffline, label: 'Offline', bg: '#F5F5F5' },
    pregnant: { color: Colors.info, label: 'Pregnant', bg: '#E3F2FD' },
    open: { color: Colors.accent, label: 'Open', bg: '#FFF8E1' },
    lactating: { color: Colors.primaryLight, label: 'Lactating', bg: '#E8F5E9' },
    dry: { color: Colors.textMuted, label: 'Dry', bg: '#F5F5F5' },
    upcoming: { color: Colors.accent, label: 'Upcoming', bg: '#FFF8E1' },
    overdue: { color: Colors.danger, label: 'Overdue', bg: '#FFEBEE' },
    scheduled: { color: Colors.info, label: 'Scheduled', bg: '#E3F2FD' },
  };
  const c = config[status] || config.offline;
  const isSmall = size === 'sm';

  return (
    <View style={[
      styles.badge,
      { backgroundColor: c.bg },
      isSmall && styles.badgeSm,
    ]}>
      <View style={[styles.dot, { backgroundColor: c.color }]} />
      {!isSmall && (
        <Text style={[styles.badgeText, { color: c.color }]}>{c.label}</Text>
      )}
    </View>
  );
}

// ─── Status Dot ──────────────────────────────────────────────────────────────
export function StatusDot({ status, size = 10 }) {
  const colors = {
    healthy: Colors.statusHealthy,
    warning: Colors.statusWarning,
    critical: Colors.statusCritical,
    offline: Colors.statusOffline,
  };
  return (
    <View style={{
      width: size, height: size, borderRadius: size / 2,
      backgroundColor: colors[status] || colors.offline,
    }} />
  );
}

// ─── Primary Button ──────────────────────────────────────────────────────────
export function PrimaryButton({ title, onPress, loading, disabled, icon, style, textStyle }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.85}
      style={[styles.primaryBtn, (disabled || loading) && styles.primaryBtnDisabled, style]}
    >
      {loading ? (
        <ActivityIndicator color="#fff" size="small" />
      ) : (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          {icon && <MaterialCommunityIcons name={icon} size={20} color="#fff" />}
          <Text style={[styles.primaryBtnText, textStyle]}>{title}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

// ─── Secondary Button ────────────────────────────────────────────────────────
export function SecondaryButton({ title, onPress, disabled, icon, style, dark }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.85}
      style={[styles.secondaryBtn, dark && styles.secondaryBtnDark, style]}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        {icon && <MaterialCommunityIcons name={icon} size={18} color={dark ? Colors.darkText : Colors.primary} />}
        <Text style={[styles.secondaryBtnText, dark && { color: Colors.darkText }]}>{title}</Text>
      </View>
    </TouchableOpacity>
  );
}

// ─── Input Field ─────────────────────────────────────────────────────────────
export function InputField({
  label, value, onChangeText, placeholder, secureTextEntry,
  keyboardType, icon, error, dark, multiline, numberOfLines,
  rightComponent, autoCapitalize,
}) {
  const [focused, setFocused] = React.useState(false);
  return (
    <View style={styles.inputWrapper}>
      {label && (
        <Text style={[styles.inputLabel, dark && { color: Colors.darkTextSecondary }]}>
          {label}
        </Text>
      )}
      <View style={[
        styles.inputContainer,
        dark && styles.inputContainerDark,
        focused && styles.inputFocused,
        error && styles.inputError,
      ]}>
        {icon && (
          <MaterialCommunityIcons
            name={icon}
            size={20}
            color={focused ? Colors.primary : dark ? Colors.darkTextMuted : Colors.textMuted}
            style={{ marginRight: 10 }}
          />
        )}
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={dark ? Colors.darkTextMuted : Colors.placeholder}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize || 'none'}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={[styles.input, dark && { color: Colors.darkText }]}
          multiline={multiline}
          numberOfLines={numberOfLines}
        />
        {rightComponent}
      </View>
      {error && (
        <Text style={styles.inputErrorText}>{error}</Text>
      )}
    </View>
  );
}

// ─── Screen Header ────────────────────────────────────────────────────────────
export function ScreenHeader({ title, subtitle, onBack, onMenu, rightComponent, dark }) {
  return (
    <View style={[styles.header, dark && styles.headerDark]}>
      <View style={styles.headerLeft}>
        {onBack && (
          <TouchableOpacity onPress={onBack} style={styles.headerBtn} activeOpacity={0.7}>
            <MaterialCommunityIcons
              name="arrow-left"
              size={24}
              color={dark ? Colors.darkText : Colors.text}
            />
          </TouchableOpacity>
        )}
        {onMenu && (
          <TouchableOpacity onPress={onMenu} style={styles.headerBtn} activeOpacity={0.7}>
            <MaterialCommunityIcons
              name="menu"
              size={24}
              color={dark ? Colors.darkText : Colors.text}
            />
          </TouchableOpacity>
        )}
        <View style={{ flex: 1, marginLeft: (onBack || onMenu) ? 8 : 0 }}>
          <Text style={[styles.headerTitle, dark && { color: Colors.darkText }]} numberOfLines={1}>
            {title}
          </Text>
          {subtitle && (
            <Text style={[styles.headerSubtitle, dark && { color: Colors.darkTextSecondary }]}>
              {subtitle}
            </Text>
          )}
        </View>
      </View>
      {rightComponent && (
        <View style={styles.headerRight}>{rightComponent}</View>
      )}
    </View>
  );
}

// ─── Animal Avatar ────────────────────────────────────────────────────────────
export function AnimalAvatar({ animal, size = 48, dark }) {
  const speciesIcon = {
    Cattle: 'cow',
    Goat: 'goat',
    Sheep: 'sheep',
  };
  return (
    <View style={[
      styles.avatar,
      { width: size, height: size, borderRadius: size / 2, backgroundColor: animal.avatarColor || Colors.primary },
    ]}>
      <MaterialCommunityIcons
        name={speciesIcon[animal.species] || 'paw'}
        size={size * 0.5}
        color="#fff"
      />
    </View>
  );
}

// ─── Metric Card ─────────────────────────────────────────────────────────────
export function MetricCard({ label, value, unit, icon, color, dark, style }) {
  return (
    <Card dark={dark} style={[styles.metricCard, style]}>
      <View style={[styles.metricIcon, { backgroundColor: (color || Colors.primary) + '20' }]}>
        <MaterialCommunityIcons name={icon} size={22} color={color || Colors.primary} />
      </View>
      <Text style={[styles.metricValue, dark && { color: Colors.darkText }]}>
        {value}
        {unit && <Text style={[styles.metricUnit, dark && { color: Colors.darkTextSecondary }]}> {unit}</Text>}
      </Text>
      <Text style={[styles.metricLabel, dark && { color: Colors.darkTextMuted }]}>{label}</Text>
    </Card>
  );
}

// ─── Empty State ─────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, subtitle, action, dark }) {
  return (
    <View style={styles.emptyState}>
      <MaterialCommunityIcons
        name={icon || 'inbox-outline'}
        size={64}
        color={dark ? Colors.darkTextMuted : Colors.placeholder}
      />
      <Text style={[styles.emptyTitle, dark && { color: Colors.darkText }]}>{title}</Text>
      {subtitle && (
        <Text style={[styles.emptySubtitle, dark && { color: Colors.darkTextSecondary }]}>{subtitle}</Text>
      )}
      {action}
    </View>
  );
}

// ─── Section Title ────────────────────────────────────────────────────────────
export function SectionTitle({ title, action, dark }) {
  return (
    <View style={styles.sectionTitle}>
      <Text style={[styles.sectionTitleText, dark && { color: Colors.darkText }]}>{title}</Text>
      {action && (
        <TouchableOpacity onPress={action.onPress} activeOpacity={0.7}>
          <Text style={styles.sectionAction}>{action.label}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// ─── Skeleton Loader ──────────────────────────────────────────────────────────
export function Skeleton({ width, height, borderRadius, style, dark }) {
  const [opacity] = React.useState(new (require('react-native').Animated).Value(0.3));
  
  React.useEffect(() => {
    const anim = require('react-native').Animated.loop(
      require('react-native').Animated.sequence([
        require('react-native').Animated.timing(opacity, { toValue: 1, duration: 800, useNativeDriver: true }),
        require('react-native').Animated.timing(opacity, { toValue: 0.3, duration: 800, useNativeDriver: true }),
      ])
    );
    anim.start();
    return () => anim.stop();
  }, []);

  return (
    <require('react-native').Animated.View style={[{
      width, height,
      borderRadius: borderRadius || Radius.md,
      backgroundColor: dark ? Colors.darkBorder : Colors.border,
      opacity,
    }, style]} />
  );
}

// ─── FAB ─────────────────────────────────────────────────────────────────────
export function FAB({ onPress, icon, color, style }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.85}
      style={[styles.fab, { backgroundColor: color || Colors.primary }, style]}
    >
      <MaterialCommunityIcons name={icon || 'plus'} size={28} color="#fff" />
    </TouchableOpacity>
  );
}

// ─── Alert Banner ─────────────────────────────────────────────────────────────
export function AlertBanner({ alert, onDismiss }) {
  if (!alert) return null;
  const colors = {
    critical: Colors.danger,
    warning: Colors.warning,
    normal: Colors.info,
  };
  return (
    <View style={[styles.alertBanner, { backgroundColor: colors[alert.type] || Colors.info }]}>
      <MaterialCommunityIcons name={alert.icon || 'alert'} size={20} color="#fff" />
      <Text style={styles.alertBannerText} numberOfLines={2}>{alert.message}</Text>
      <TouchableOpacity onPress={onDismiss} style={{ padding: 4 }}>
        <MaterialCommunityIcons name="close" size={18} color="#fff" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.base,
    ...Shadows.md,
  },
  cardDark: {
    backgroundColor: Colors.darkSurface,
    shadowColor: '#000',
    shadowOpacity: 0.3,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: Radius.round,
    gap: 5,
  },
  badgeSm: {
    paddingHorizontal: 6,
    paddingVertical: 3,
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  badgeText: {
    fontSize: Typography.sm,
    fontWeight: Typography.semibold,
  },
  primaryBtn: {
    backgroundColor: Colors.primary,
    borderRadius: Radius.lg,
    paddingVertical: 15,
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.sm,
  },
  primaryBtnDisabled: {
    opacity: 0.6,
  },
  primaryBtnText: {
    color: '#fff',
    fontSize: Typography.md,
    fontWeight: Typography.bold,
    letterSpacing: 0.3,
  },
  secondaryBtn: {
    backgroundColor: 'transparent',
    borderRadius: Radius.lg,
    paddingVertical: 13,
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: Colors.primary,
  },
  secondaryBtnDark: {
    borderColor: Colors.darkBorder,
  },
  secondaryBtnText: {
    color: Colors.primary,
    fontSize: Typography.md,
    fontWeight: Typography.semibold,
  },
  inputWrapper: {
    marginBottom: Spacing.md,
  },
  inputLabel: {
    fontSize: Typography.sm,
    fontWeight: Typography.semibold,
    color: Colors.textSecondary,
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radius.lg,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  inputContainerDark: {
    backgroundColor: Colors.darkSurfaceSecondary,
    borderColor: Colors.darkBorder,
  },
  inputFocused: {
    borderColor: Colors.primary,
    backgroundColor: Colors.surface,
  },
  inputError: {
    borderColor: Colors.danger,
  },
  input: {
    flex: 1,
    fontSize: Typography.md,
    color: Colors.text,
    padding: 0,
  },
  inputErrorText: {
    fontSize: Typography.xs,
    color: Colors.danger,
    marginTop: 4,
    marginLeft: 4,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerDark: {
    backgroundColor: Colors.darkSurface,
    borderBottomColor: Colors.darkBorder,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerBtn: {
    padding: 4,
  },
  headerTitle: {
    fontSize: Typography.lg,
    fontWeight: Typography.bold,
    color: Colors.text,
  },
  headerSubtitle: {
    fontSize: Typography.xs,
    color: Colors.textSecondary,
    marginTop: 1,
  },
  avatar: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  metricCard: {
    alignItems: 'center',
    gap: 6,
  },
  metricIcon: {
    width: 44,
    height: 44,
    borderRadius: Radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  metricValue: {
    fontSize: Typography.xl,
    fontWeight: Typography.bold,
    color: Colors.text,
  },
  metricUnit: {
    fontSize: Typography.sm,
    fontWeight: Typography.regular,
    color: Colors.textSecondary,
  },
  metricLabel: {
    fontSize: Typography.xs,
    color: Colors.textMuted,
    fontWeight: Typography.medium,
    textAlign: 'center',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xxxl,
    gap: Spacing.md,
  },
  emptyTitle: {
    fontSize: Typography.lg,
    fontWeight: Typography.bold,
    color: Colors.text,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: Typography.base,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  sectionTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.md,
  },
  sectionTitleText: {
    fontSize: Typography.md,
    fontWeight: Typography.bold,
    color: Colors.text,
  },
  sectionAction: {
    fontSize: Typography.sm,
    color: Colors.primary,
    fontWeight: Typography.semibold,
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 58,
    height: 58,
    borderRadius: 29,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.lg,
  },
  alertBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    paddingHorizontal: Spacing.base,
    gap: 10,
    margin: Spacing.base,
    borderRadius: Radius.lg,
  },
  alertBannerText: {
    flex: 1,
    color: '#fff',
    fontSize: Typography.sm,
    fontWeight: Typography.medium,
    lineHeight: 18,
  },
});
