# 🐄 LiveStock+ — Smart Farm Health Monitor

A production-ready React Native (Expo) mobile application for livestock health monitoring, built for Android & iOS.

---

## 📱 Screenshots Overview

The app includes **16 complete screens** covering every aspect of farm management:

| Screen | Description |
|--------|-------------|
| Splash | Animated logo with farm icon |
| Onboarding | 3 swipeable slides with feature highlights |
| Login | Email/password + Google Sign-In |
| Register | Full registration with location picker |
| Dashboard | Farm summary, alerts, quick stats |
| Animal List | Searchable list with filters |
| Animal Detail | Profile + Health/Milk/Reproduction/Vaccination tabs |
| Temperature Monitor | Live gauge, 24h chart, zone thresholds |
| Health Monitor | Symptom checklist, vet notes, diagnosis history |
| Milk Production | Daily logs, 7-day charts, CSV export |
| Reproduction Tracker | Heat calendar, breeding log, pregnancy countdown |
| Vaccination Schedule | Upcoming/overdue alerts, mark done |
| Sensor Dashboard | All 4 sensor types with battery/signal |
| Alerts | Feed with type filters, resolve/delete |
| Reports | PDF/CSV export, charts, analytics |
| Settings | Profile, dark mode, notifications, sensor pairing |

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- For iOS: macOS + Xcode
- For Android: Android Studio + emulator, or physical device

### Installation

```bash
# Clone or extract the project
cd LivestockPlus

# Install dependencies
npm install

# Start Expo development server
npx expo start

# Run on Android
npx expo start --android

# Run on iOS
npx expo start --ios
```

### Demo Login
- **Email:** demo@farm.com (or any valid email)
- **Password:** password123 (or any 6+ char password)

---

## 🏗️ Project Structure

```
LivestockPlus/
├── App.js                          # Root entry point
├── app.json                        # Expo configuration
├── package.json
├── babel.config.js
└── src/
    ├── context/
    │   └── AppContext.js           # Global state (useReducer)
    ├── data/
    │   └── mockData.js             # 10 sample animals + alerts
    ├── navigation/
    │   ├── RootNavigator.js        # Auth flow routing
    │   ├── AuthNavigator.js        # Login/Register/ForgotPassword
    │   └── MainNavigator.js        # Bottom tabs + Drawer
    ├── components/
    │   └── common/
    │       └── index.js            # Reusable UI components
    ├── screens/
    │   ├── SplashScreen.js
    │   ├── OnboardingScreen.js
    │   ├── auth/
    │   │   ├── LoginScreen.js
    │   │   ├── RegisterScreen.js
    │   │   └── ForgotPasswordScreen.js
    │   ├── main/
    │   │   ├── DashboardScreen.js
    │   │   ├── AlertsScreen.js
    │   │   ├── MilkProductionScreen.js
    │   │   ├── ReproductionScreen.js
    │   │   ├── VaccinationScreen.js
    │   │   ├── ReportsScreen.js
    │   │   └── SettingsScreen.js
    │   ├── animals/
    │   │   ├── AnimalListScreen.js
    │   │   ├── AnimalDetailScreen.js
    │   │   └── HealthMonitorScreen.js
    │   └── sensors/
    │       ├── SensorDashboardScreen.js
    │       ├── SensorDetailScreen.js
    │       └── TemperatureMonitorScreen.js
    └── utils/
        └── theme.js                # Colors, typography, spacing
```

---

## 🎨 Design System

### Colors
```js
Primary:    #2E7D32  (Forest green)
Accent:     #FF8F00  (Amber)
Danger:     #D32F2F  (Red)
Background: #F9FAF7  (Light) / #121212 (Dark)
```

### Components (from `src/components/common/index.js`)
- `Card` — White card with shadow, 8px radius
- `StatusBadge` — Healthy/Warning/Critical/Offline pill
- `StatusDot` — Small colored status indicator
- `PrimaryButton` / `SecondaryButton`
- `InputField` — Labeled input with icon
- `ScreenHeader` — Back/menu + title + right actions
- `AnimalAvatar` — Species icon with color background
- `MetricCard` — Stat display with icon
- `EmptyState` — Icon + text for empty lists
- `FAB` — Floating action button
- `AlertBanner` — Full-width alert strip

---

## 📊 Data Models

### Animal Model
```js
{
  id, name, species, breed, age, weight, tagNumber,
  photo, avatarColor, status,  // healthy | warning | critical | offline
  sensors: {
    temperature: { value, unit, batteryLevel, signalStrength, lastSync, history[] },
    gps: { value: {lat, lng}, batteryLevel, signalStrength },
    milk: { value, unit, batteryLevel, history[] },
    activity: { value, unit }
  },
  health: { weight, bcs, symptoms[], vetNotes, records[] },
  milk: { currentDaily, monthlyTotal, avgDaily, weeklyData[], logs[] },
  reproduction: { status, lastHeat, nextExpectedHeat, pregnancyDate, expectedDelivery, breedingLog[], offspring[], heatCalendar[] },
  vaccinations: [{ id, name, date, nextDue, status, veterinarian, notes }]
}
```

### Alert Model
```js
{
  id, animalId, animalName, type,  // critical | warning | normal
  title, message, timestamp, resolved, icon
}
```

---

## 🔧 Key Features

### Sensor Simulation
Mock sensor updates run every **30 seconds**, updating temperature, milk, and activity values. If temperature exceeds 39.5°C, a critical alert is automatically generated.

### Navigation Structure
```
Root Stack
├── Splash → Onboarding → Auth (if not onboarded)
├── Auth Stack (Login, Register, ForgotPassword)
└── Main (Drawer)
    ├── MainTabs (Bottom Navigation)
    │   ├── Home (Dashboard)
    │   ├── Animals (Stack: List → Detail → sub-screens)
    │   ├── Sensors (Stack: Dashboard → Detail)
    │   ├── Reports
    │   └── Settings
    ├── Alerts (Drawer)
    ├── Vaccination Schedule (Drawer)
    ├── Milk Production (Drawer)
    └── Reproduction (Drawer)
```

### Dark Mode
Full dark mode support throughout all screens. Toggle in Settings or via `dispatch({ type: 'TOGGLE_DARK_MODE' })`. Persisted to AsyncStorage.

### State Management
Uses React Context + useReducer with the following action types:
- `LOGIN`, `LOGOUT`, `SET_ONBOARDED`
- `TOGGLE_DARK_MODE`, `SET_DARK_MODE`
- `UPDATE_ANIMAL`, `UPDATE_SENSOR`, `BULK_UPDATE_SENSORS`
- `ADD_ALERT`, `RESOLVE_ALERT`, `DELETE_ALERT`
- `ADD_HEALTH_RECORD`, `ADD_VACCINATION`, `ADD_MILK_LOG`
- `TOGGLE_NOTIFICATION`, `UPDATE_FARM_STATS`

---

## 📦 Production Additions Needed

For a full production release, add:

1. **Authentication**: Firebase Auth or AWS Cognito (replace mock login)
2. **Database**: Firestore or Supabase for real-time sync
3. **Push Notifications**: expo-notifications with Firebase Cloud Messaging
4. **GPS/BLE Sensors**: expo-location + react-native-ble-plx
5. **PDF Export**: react-native-pdf or expo-print
6. **CSV Export**: expo-file-system + expo-sharing
7. **Offline Sync**: WatermelonDB or react-query with offline support
8. **Camera**: expo-camera for animal photos
9. **Maps**: react-native-maps for GPS tracking view
10. **i18n**: react-i18next for Hindi, Gujarati, etc.

---

## 🐛 Known Issues & Notes

- `react-native-chart-kit` requires `react-native-svg` — ensure both are installed
- On Android, some chart labels may clip — use `paddingLeft` in chart config
- The `@react-navigation/drawer` requires `react-native-gesture-handler` and `react-native-reanimated`
- Expo Go may not support all native modules — use a development build for full testing

---

## 📄 License

MIT License — Free for personal and commercial use.

---

*Built for Indian farmers 🇮🇳 — LiveStock+ helps you care for every animal, every day.*
