import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SAMPLE_ANIMALS, SAMPLE_ALERTS, FARM_STATS, generateSensorReadings } from '../data/mockData';

const AppContext = createContext(null);

const initialState = {
  // Auth
  isAuthenticated: false,
  hasOnboarded: false,
  user: null,

  // Farm data
  animals: SAMPLE_ANIMALS,
  alerts: SAMPLE_ALERTS,
  farmStats: FARM_STATS,

  // UI
  darkMode: false,
  isLoading: true,
  isOnline: true,
  lastSync: null,
  notifications: {
    temperature: true,
    vaccination: true,
    milk: true,
    general: true,
  },

  // Selected
  selectedAnimal: null,
};

function appReducer(state, action) {
  switch (action.type) {
    case 'INIT_COMPLETE':
      return { ...state, isLoading: false, ...action.payload };

    case 'LOGIN':
      return { ...state, isAuthenticated: true, user: action.payload };

    case 'LOGOUT':
      return { ...state, isAuthenticated: false, user: null };

    case 'SET_ONBOARDED':
      return { ...state, hasOnboarded: true };

    case 'TOGGLE_DARK_MODE':
      return { ...state, darkMode: !state.darkMode };

    case 'SET_DARK_MODE':
      return { ...state, darkMode: action.payload };

    case 'UPDATE_ANIMAL':
      return {
        ...state,
        animals: state.animals.map(a =>
          a.id === action.payload.id ? { ...a, ...action.payload } : a
        ),
      };

    case 'UPDATE_SENSOR':
      return {
        ...state,
        animals: state.animals.map(a => {
          if (a.id === action.payload.animalId) {
            return {
              ...a,
              sensors: { ...a.sensors, [action.payload.type]: action.payload.sensor },
              status: action.payload.newStatus || a.status,
            };
          }
          return a;
        }),
      };

    case 'BULK_UPDATE_SENSORS':
      return { ...state, animals: action.payload };

    case 'ADD_ALERT':
      return {
        ...state,
        alerts: [action.payload, ...state.alerts],
        farmStats: {
          ...state.farmStats,
          [action.payload.type === 'critical' ? 'criticalAlerts' : 'warningAlerts']:
            state.farmStats[action.payload.type === 'critical' ? 'criticalAlerts' : 'warningAlerts'] + 1,
        },
      };

    case 'RESOLVE_ALERT':
      return {
        ...state,
        alerts: state.alerts.map(a =>
          a.id === action.payload ? { ...a, resolved: true } : a
        ),
      };

    case 'DELETE_ALERT':
      return {
        ...state,
        alerts: state.alerts.filter(a => a.id !== action.payload),
      };

    case 'ADD_HEALTH_RECORD':
      return {
        ...state,
        animals: state.animals.map(a => {
          if (a.id === action.payload.animalId) {
            return {
              ...a,
              health: {
                ...a.health,
                records: [action.payload.record, ...a.health.records],
              },
            };
          }
          return a;
        }),
      };

    case 'ADD_VACCINATION':
      return {
        ...state,
        animals: state.animals.map(a => {
          if (a.id === action.payload.animalId) {
            return {
              ...a,
              vaccinations: [...a.vaccinations, action.payload.vaccination],
            };
          }
          return a;
        }),
      };

    case 'ADD_MILK_LOG':
      return {
        ...state,
        animals: state.animals.map(a => {
          if (a.id === action.payload.animalId) {
            const newLog = action.payload.log;
            const total = newLog.morning + newLog.evening;
            return {
              ...a,
              milk: {
                ...a.milk,
                logs: [newLog, ...a.milk.logs],
                currentDaily: total,
              },
            };
          }
          return a;
        }),
      };

    case 'TOGGLE_NOTIFICATION':
      return {
        ...state,
        notifications: {
          ...state.notifications,
          [action.payload]: !state.notifications[action.payload],
        },
      };

    case 'UPDATE_FARM_STATS':
      return { ...state, farmStats: { ...state.farmStats, ...action.payload } };

    case 'SET_LAST_SYNC':
      return { ...state, lastSync: action.payload };

    case 'SELECT_ANIMAL':
      return { ...state, selectedAnimal: action.payload };

    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Initialize from AsyncStorage
  useEffect(() => {
    async function init() {
      try {
        const [onboarded, darkMode, user] = await Promise.all([
          AsyncStorage.getItem('hasOnboarded'),
          AsyncStorage.getItem('darkMode'),
          AsyncStorage.getItem('user'),
        ]);

        dispatch({
          type: 'INIT_COMPLETE',
          payload: {
            hasOnboarded: onboarded === 'true',
            darkMode: darkMode === 'true',
            isAuthenticated: !!user,
            user: user ? JSON.parse(user) : null,
          },
        });
      } catch (e) {
        dispatch({ type: 'INIT_COMPLETE', payload: {} });
      }
    }
    init();
  }, []);

  // Persist dark mode
  useEffect(() => {
    AsyncStorage.setItem('darkMode', String(state.darkMode));
  }, [state.darkMode]);

  // Mock sensor updates every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      const updatedAnimals = state.animals.map(animal => {
        const newSensors = generateSensorReadings(animal.id, animal.sensors?.temperature?.value || 38.5);
        const temp = newSensors.temperature.value;
        let newStatus = animal.status;
        
        if (animal.status !== 'offline') {
          if (temp > 39.5) newStatus = 'critical';
          else if (temp > 39.0) newStatus = 'warning';
          else newStatus = 'healthy';
        }

        // Trigger alert for critical temp
        if (temp > 39.5 && animal.status !== 'critical') {
          dispatch({
            type: 'ADD_ALERT',
            payload: {
              id: `alert-auto-${Date.now()}-${animal.id}`,
              animalId: animal.id,
              animalName: animal.name,
              type: 'critical',
              title: 'High Temperature Alert',
              message: `${animal.name}'s temperature is ${temp}°C, exceeding the 39.5°C threshold.`,
              timestamp: new Date().toISOString(),
              resolved: false,
              icon: 'thermometer-alert',
            },
          });
        }

        return { ...animal, sensors: newSensors, status: newStatus };
      });

      dispatch({ type: 'BULK_UPDATE_SENSORS', payload: updatedAnimals });
      dispatch({ type: 'SET_LAST_SYNC', payload: new Date().toISOString() });
    }, 30000);

    return () => clearInterval(interval);
  }, [state.animals]);

  const login = useCallback(async (user) => {
    await AsyncStorage.setItem('user', JSON.stringify(user));
    dispatch({ type: 'LOGIN', payload: user });
  }, []);

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem('user');
    dispatch({ type: 'LOGOUT' });
  }, []);

  const completeOnboarding = useCallback(async () => {
    await AsyncStorage.setItem('hasOnboarded', 'true');
    dispatch({ type: 'SET_ONBOARDED' });
  }, []);

  const value = {
    state,
    dispatch,
    login,
    logout,
    completeOnboarding,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}

export function useTheme() {
  const { state } = useApp();
  return state.darkMode;
}
