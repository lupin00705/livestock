import React, { useState, useMemo } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput, TouchableOpacity,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import {
  AnimalAvatar, StatusBadge, FAB, EmptyState, ScreenHeader,
} from '../../components/common';
import { Colors, Typography, Spacing, Radius, Shadows } from '../../utils/theme';

const FILTERS = ['All', 'Cattle', 'Goat', 'Sheep', 'Critical', 'Warning'];

function AnimalCard({ animal, onPress, dark }) {
  const temp = animal.sensors?.temperature?.value;
  const milk = animal.sensors?.milk?.value;

  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85}>
      <View style={[styles.card, dark && styles.cardDark]}>
        <AnimalAvatar animal={animal} size={56} />
        <View style={styles.cardInfo}>
          <View style={styles.cardNameRow}>
            <Text style={[styles.cardName, dark && { color: Colors.darkText }]}>{animal.name}</Text>
            <StatusBadge status={animal.status} size="sm" />
          </View>
          <Text style={[styles.cardSpecies, dark && { color: Colors.darkTextSecondary }]}>
            {animal.species} · {animal.breed}
          </Text>
          <Text style={[styles.cardTag, dark && { color: Colors.darkTextMuted }]}>
            {animal.tagNumber} · Age: {animal.age}
          </Text>
          <View style={styles.cardStats}>
            {temp && (
              <View style={styles.cardStat}>
                <MaterialCommunityIcons
                  name="thermometer"
                  size={13}
                  color={temp > 39.5 ? Colors.danger : temp > 39 ? Colors.warning : Colors.success}
                />
                <Text style={[styles.cardStatText, {
                  color: temp > 39.5 ? Colors.danger : temp > 39 ? Colors.warning : Colors.success,
                }]}>{temp}°C</Text>
              </View>
            )}
            {milk && (
              <View style={styles.cardStat}>
                <MaterialCommunityIcons name="water" size={13} color={Colors.info} />
                <Text style={[styles.cardStatText, { color: Colors.info }]}>{milk}L</Text>
              </View>
            )}
            <View style={styles.cardStat}>
              <MaterialCommunityIcons name="weight-kilogram" size={13} color={Colors.textMuted} />
              <Text style={[styles.cardStatText, dark && { color: Colors.darkTextMuted }]}>{animal.weight}kg</Text>
            </View>
          </View>
        </View>
        <MaterialCommunityIcons
          name="chevron-right"
          size={22}
          color={dark ? Colors.darkTextMuted : Colors.textMuted}
        />
      </View>
    </TouchableOpacity>
  );
}

export default function AnimalListScreen({ navigation }) {
  const { state } = useApp();
  const dark = state.darkMode;
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [refreshing, setRefreshing] = useState(false);

  const filtered = useMemo(() => {
    return state.animals.filter(a => {
      const matchSearch = !search ||
        a.name.toLowerCase().includes(search.toLowerCase()) ||
        a.tagNumber.toLowerCase().includes(search.toLowerCase()) ||
        a.species.toLowerCase().includes(search.toLowerCase());
      const matchFilter =
        activeFilter === 'All' ||
        a.species === activeFilter ||
        a.status === activeFilter.toLowerCase();
      return matchSearch && matchFilter;
    });
  }, [state.animals, search, activeFilter]);

  const onRefresh = async () => {
    setRefreshing(true);
    await new Promise(r => setTimeout(r, 1000));
    setRefreshing(false);
  };

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader
        title="My Animals"
        subtitle={`${state.animals.length} animals total`}
        dark={dark}
        rightComponent={
          <TouchableOpacity style={styles.filterBtn}>
            <MaterialCommunityIcons name="tune-variant" size={22} color={Colors.primary} />
          </TouchableOpacity>
        }
      />

      {/* Search */}
      <View style={[styles.searchContainer, dark && styles.searchContainerDark]}>
        <MaterialCommunityIcons name="magnify" size={20} color={Colors.textMuted} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search by name, tag, species..."
          placeholderTextColor={dark ? Colors.darkTextMuted : Colors.placeholder}
          style={[styles.searchInput, dark && { color: Colors.darkText }]}
        />
        {search ? (
          <TouchableOpacity onPress={() => setSearch('')} activeOpacity={0.7}>
            <MaterialCommunityIcons name="close-circle" size={18} color={Colors.textMuted} />
          </TouchableOpacity>
        ) : null}
      </View>

      {/* Filter Pills */}
      <View style={styles.filterRow}>
        <FlatList
          data={FILTERS}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: Spacing.base, gap: 8 }}
          keyExtractor={f => f}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => setActiveFilter(item)}
              activeOpacity={0.8}
              style={[
                styles.filterPill,
                activeFilter === item && styles.filterPillActive,
                dark && styles.filterPillDark,
              ]}
            >
              <Text style={[
                styles.filterPillText,
                activeFilter === item && styles.filterPillTextActive,
                dark && { color: Colors.darkTextSecondary },
              ]}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {/* List */}
      <FlatList
        data={filtered}
        keyExtractor={a => a.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />
        }
        ListEmptyComponent={
          <EmptyState
            icon="cow-off"
            title="No animals found"
            subtitle={search ? `No results for "${search}"` : 'Add your first animal to get started'}
            dark={dark}
          />
        }
        renderItem={({ item }) => (
          <AnimalCard
            animal={item}
            dark={dark}
            onPress={() => navigation.navigate('AnimalDetail', { animalId: item.id })}
          />
        )}
      />

      <FAB
        onPress={() => alert('Add Animal form would open here')}
        icon="plus"
        style={{ bottom: 90 }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  searchContainer: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.surface, margin: Spacing.base,
    paddingHorizontal: Spacing.base, paddingVertical: 12,
    borderRadius: Radius.xl, borderWidth: 1.5, borderColor: Colors.border,
    ...Shadows.sm,
  },
  searchContainerDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  searchInput: { flex: 1, fontSize: Typography.base, color: Colors.text },
  filterRow: { marginBottom: Spacing.sm },
  filterPill: {
    paddingHorizontal: 16, paddingVertical: 7, borderRadius: Radius.round,
    backgroundColor: Colors.surfaceSecondary, borderWidth: 1, borderColor: Colors.border,
  },
  filterPillActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterPillDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  filterPillText: { fontSize: Typography.sm, color: Colors.textSecondary, fontWeight: '600' },
  filterPillTextActive: { color: '#fff' },
  list: { paddingHorizontal: Spacing.base, paddingBottom: 120 },
  card: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surface, borderRadius: Radius.lg,
    padding: Spacing.md, marginBottom: Spacing.sm,
    ...Shadows.md,
  },
  cardDark: { backgroundColor: Colors.darkSurface },
  cardInfo: { flex: 1 },
  cardNameRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 2 },
  cardName: { fontSize: Typography.md, fontWeight: '700', color: Colors.text },
  cardSpecies: { fontSize: Typography.sm, color: Colors.textSecondary },
  cardTag: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 1 },
  cardStats: { flexDirection: 'row', gap: 12, marginTop: 6 },
  cardStat: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  cardStatText: { fontSize: Typography.xs, fontWeight: '600', color: Colors.textSecondary },
  filterBtn: { padding: 4 },
});
