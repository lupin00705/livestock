import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader, AnimalAvatar } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

const { width } = Dimensions.get('window');

const SENSOR_META = {
  temperature: { label: 'Temperature', icon: 'thermometer', unit: '°C', color: Colors.danger },
  gps: { label: 'GPS Location', icon: 'map-marker', unit: '', color: Colors.info },
  milk: { label: 'Milk Production', icon: 'water', unit: 'L/day', color: Colors.accent },
  activity: { label: 'Activity Monitor', icon: 'run', unit: 'steps', color: Colors.success },
};

export default function SensorDetailScreen({ route, navigation }) {
  const { animalId, sensorType } = route.params || {};
  const { state } = useApp();
  const dark = state.darkMode;
  const animal = state.animals.find(a => a.id === animalId) || state.animals[0];
  const sensor = animal?.sensors?.[sensorType || 'temperature'];
  const meta = SENSOR_META[sensorType] || SENSOR_META.temperature;

  const history = sensor?.history || [];
  const chartLabels = history.filter((_, i) => i % 4 === 0).map(h => {
    const d = new Date(h.time);
    return `${d.getHours()}:00`;
  });
  const chartData = history.filter((_, i) => i % 4 === 0).map(h => h.value);

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader title={meta.label} subtitle={animal?.name} onBack={() => navigation.goBack()} dark={dark} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* Animal info */}
        <Card dark={dark} style={styles.animalCard}>
          <AnimalAvatar animal={animal} size={56} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.name, dark && { color: Colors.darkText }]}>{animal?.name}</Text>
            <Text style={[styles.breed, dark && { color: Colors.darkTextSecondary }]}>{animal?.species} · {animal?.breed}</Text>
            <Text style={[styles.tag, dark && { color: Colors.darkTextMuted }]}>{animal?.tagNumber}</Text>
          </View>
        </Card>

        {/* Current reading */}
        <Card dark={dark} style={styles.readingCard}>
          <View style={[styles.readingIcon, { backgroundColor: meta.color + '20' }]}>
            <MaterialCommunityIcons name={meta.icon} size={40} color={meta.color} />
          </View>
          <Text style={[styles.readingValue, { color: meta.color }]}>
            {sensorType === 'gps'
              ? `${sensor?.value?.lat?.toFixed(5)}\n${sensor?.value?.lng?.toFixed(5)}`
              : sensorType === 'activity'
              ? (sensor?.value || 0).toLocaleString()
              : sensor?.value}
            {sensorType !== 'gps' && <Text style={styles.readingUnit}> {meta.unit}</Text>}
          </Text>
          <Text style={[styles.readingLabel, dark && { color: Colors.darkTextSecondary }]}>Current Reading</Text>
        </Card>

        {/* Sensor status */}
        <Card dark={dark}>
          <Text style={[styles.sectionTitle, dark && { color: Colors.darkText }]}>Sensor Status</Text>
          {[
            { label: 'Status', value: sensor?.status || 'unknown', icon: 'access-point', color: sensor?.status === 'online' ? Colors.success : Colors.danger },
            { label: 'Battery Level', value: `${sensor?.batteryLevel}%`, icon: 'battery', color: sensor?.batteryLevel > 30 ? Colors.success : Colors.danger },
            { label: 'Signal Strength', value: `${sensor?.signalStrength}%`, icon: 'wifi', color: sensor?.signalStrength > 50 ? Colors.success : Colors.warning },
            { label: 'Last Sync', value: new Date(sensor?.lastSync).toLocaleTimeString(), icon: 'sync', color: Colors.primary },
            { label: 'Sensor ID', value: sensor?.id, icon: 'identifier', color: Colors.textMuted },
          ].map(item => (
            <View key={item.label} style={[styles.statusRow, dark && styles.statusRowDark]}>
              <MaterialCommunityIcons name={item.icon} size={18} color={item.color} />
              <Text style={[styles.statusLabel, dark && { color: Colors.darkTextSecondary }]}>{item.label}</Text>
              <Text style={[styles.statusValue, { color: item.color }, dark && {}]} numberOfLines={1}>{item.value}</Text>
            </View>
          ))}
        </Card>

        {/* History chart */}
        {chartData.length > 0 && (
          <Card dark={dark}>
            <Text style={[styles.sectionTitle, dark && { color: Colors.darkText }]}>24-Hour History</Text>
            <LineChart
              data={{ labels: chartLabels, datasets: [{ data: chartData }] }}
              width={width - 64}
              height={160}
              chartConfig={{
                backgroundGradientFrom: dark ? Colors.darkSurface : Colors.surface,
                backgroundGradientTo: dark ? Colors.darkSurface : Colors.surface,
                color: () => meta.color,
                labelColor: (o) => dark ? `rgba(165,200,167,${o})` : `rgba(90,116,96,${o})`,
                decimalPlaces: 1,
                propsForDots: { r: '3', strokeWidth: '2', stroke: meta.color },
              }}
              bezier
              style={{ borderRadius: Radius.lg, marginLeft: -16 }}
              withInnerLines={false}
            />
          </Card>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  content: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 40 },
  animalCard: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  name: { fontSize: Typography.lg, fontWeight: '700', color: Colors.text },
  breed: { fontSize: Typography.sm, color: Colors.textSecondary },
  tag: { fontSize: Typography.xs, color: Colors.textMuted },
  readingCard: { alignItems: 'center', paddingVertical: Spacing.xl },
  readingIcon: { width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.md },
  readingValue: { fontSize: 42, fontWeight: '900', textAlign: 'center' },
  readingUnit: { fontSize: Typography.xl, fontWeight: '400' },
  readingLabel: { fontSize: Typography.sm, color: Colors.textSecondary, marginTop: Spacing.sm },
  sectionTitle: { fontSize: Typography.md, fontWeight: '700', color: Colors.text, marginBottom: Spacing.md },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: Colors.border },
  statusRowDark: { borderBottomColor: Colors.darkBorder },
  statusLabel: { flex: 1, fontSize: Typography.sm, color: Colors.textSecondary },
  statusValue: { fontSize: Typography.sm, fontWeight: '700', maxWidth: 160 },
});
