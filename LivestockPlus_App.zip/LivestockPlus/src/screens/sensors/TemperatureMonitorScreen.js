import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Dimensions, TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LineChart } from 'react-native-chart-kit';
import Svg, { Circle, Path, Text as SvgText, G, Line } from 'react-native-svg';
import { useApp } from '../../context/AppContext';
import { Card, ScreenHeader } from '../../components/common';
import { Colors, Typography, Spacing, Radius } from '../../utils/theme';

const { width } = Dimensions.get('window');
const GAUGE_SIZE = 220;
const GAUGE_CENTER = GAUGE_SIZE / 2;
const GAUGE_RADIUS = 90;

function tempColor(temp) {
  if (temp > 39.5) return Colors.danger;
  if (temp > 39.0) return Colors.warning;
  if (temp < 37.5) return Colors.info;
  return Colors.success;
}

function TempGauge({ value, dark }) {
  const min = 35, max = 42;
  const range = max - min;
  const pct = Math.min(1, Math.max(0, (value - min) / range));
  const startAngle = -220;
  const totalArc = 260;
  const angle = startAngle + pct * totalArc;
  const toRad = (deg) => (deg * Math.PI) / 180;

  const arcPath = (startDeg, endDeg, r) => {
    const sx = GAUGE_CENTER + r * Math.cos(toRad(startDeg));
    const sy = GAUGE_CENTER + r * Math.sin(toRad(startDeg));
    const ex = GAUGE_CENTER + r * Math.cos(toRad(endDeg));
    const ey = GAUGE_CENTER + r * Math.sin(toRad(endDeg));
    const large = endDeg - startDeg > 180 ? 1 : 0;
    return `M ${sx} ${sy} A ${r} ${r} 0 ${large} 1 ${ex} ${ey}`;
  };

  const needleX = GAUGE_CENTER + (GAUGE_RADIUS - 10) * Math.cos(toRad(angle));
  const needleY = GAUGE_CENTER + (GAUGE_RADIUS - 10) * Math.sin(toRad(angle));

  const color = tempColor(value);

  const zones = [
    { label: 'Low', start: startAngle, end: startAngle + totalArc * 0.2, color: Colors.info },
    { label: 'Normal', start: startAngle + totalArc * 0.2, end: startAngle + totalArc * 0.7, color: Colors.success },
    { label: 'Warning', start: startAngle + totalArc * 0.7, end: startAngle + totalArc * 0.85, color: Colors.warning },
    { label: 'Critical', start: startAngle + totalArc * 0.85, end: startAngle + totalArc, color: Colors.danger },
  ];

  return (
    <View style={{ alignItems: 'center' }}>
      <Svg width={GAUGE_SIZE} height={GAUGE_SIZE}>
        {/* Background track */}
        <Path
          d={arcPath(startAngle, startAngle + totalArc, GAUGE_RADIUS)}
          stroke={dark ? Colors.darkBorder : Colors.border}
          strokeWidth={14}
          fill="none"
          strokeLinecap="round"
        />
        {/* Zone arcs */}
        {zones.map((z, i) => (
          <Path
            key={i}
            d={arcPath(z.start, z.end, GAUGE_RADIUS)}
            stroke={z.color}
            strokeWidth={14}
            fill="none"
            opacity={0.35}
          />
        ))}
        {/* Value arc */}
        <Path
          d={arcPath(startAngle, angle, GAUGE_RADIUS)}
          stroke={color}
          strokeWidth={14}
          fill="none"
          strokeLinecap="round"
        />
        {/* Needle */}
        <Line
          x1={GAUGE_CENTER}
          y1={GAUGE_CENTER}
          x2={needleX}
          y2={needleY}
          stroke={color}
          strokeWidth={3}
          strokeLinecap="round"
        />
        <Circle cx={GAUGE_CENTER} cy={GAUGE_CENTER} r={8} fill={color} />
        <Circle cx={GAUGE_CENTER} cy={GAUGE_CENTER} r={4} fill="#fff" />

        {/* Labels */}
        <SvgText x={GAUGE_CENTER - 55} y={GAUGE_CENTER + 55} fontSize={11} fill={dark ? Colors.darkTextMuted : Colors.textMuted} textAnchor="middle">35°C</SvgText>
        <SvgText x={GAUGE_CENTER + 55} y={GAUGE_CENTER + 55} fontSize={11} fill={dark ? Colors.darkTextMuted : Colors.textMuted} textAnchor="middle">42°C</SvgText>

        {/* Center value */}
        <SvgText x={GAUGE_CENTER} y={GAUGE_CENTER + 18} fontSize={36} fontWeight="bold" fill={color} textAnchor="middle">{value}</SvgText>
        <SvgText x={GAUGE_CENTER} y={GAUGE_CENTER + 38} fontSize={14} fill={dark ? Colors.darkTextSecondary : Colors.textSecondary} textAnchor="middle">°Celsius</SvgText>
      </Svg>

      <View style={[styles.tempStatus, { backgroundColor: color + '20' }]}>
        <MaterialCommunityIcons name={value > 39.5 ? 'alert-circle' : value > 39 ? 'alert' : 'check-circle'} size={18} color={color} />
        <Text style={[styles.tempStatusText, { color }]}>
          {value > 39.5 ? 'CRITICAL — Fever Detected' : value > 39.0 ? 'WARNING — Above Normal' : value < 37.5 ? 'LOW — Below Normal' : 'NORMAL — Healthy Range'}
        </Text>
      </View>
    </View>
  );
}

export default function TemperatureMonitorScreen({ route, navigation }) {
  const { animalId } = route.params || {};
  const { state } = useApp();
  const dark = state.darkMode;

  const animal = animalId
    ? state.animals.find(a => a.id === animalId)
    : state.animals.find(a => a.status === 'critical') || state.animals[0];

  const sensor = animal?.sensors?.temperature;
  const temp = sensor?.value || 38.5;
  const history = sensor?.history || [];

  const chartLabels = history.filter((_, i) => i % 4 === 0).map((h) => {
    const d = new Date(h.time);
    return `${d.getHours()}:00`;
  });
  const chartData = history.filter((_, i) => i % 4 === 0).map(h => h.value);

  const [selectedAnimalId, setSelectedAnimalId] = useState(animal?.id);

  const thresholds = [
    { label: 'Low', range: '< 37.5°C', color: Colors.info, desc: 'Hypothermia risk' },
    { label: 'Normal', range: '37.5 – 39.0°C', color: Colors.success, desc: 'Healthy range' },
    { label: 'Warning', range: '39.0 – 39.5°C', color: Colors.warning, desc: 'Monitor closely' },
    { label: 'Critical', range: '> 39.5°C', color: Colors.danger, desc: 'Immediate attention' },
  ];

  return (
    <SafeAreaView style={[styles.safe, dark && styles.safeDark]}>
      <ScreenHeader
        title="Temperature Monitor"
        subtitle={animal?.name || 'All Animals'}
        onBack={() => navigation.goBack()}
        dark={dark}
        rightComponent={
          <TouchableOpacity style={[styles.syncBtn, dark && { backgroundColor: Colors.darkSurfaceSecondary }]}>
            <MaterialCommunityIcons name="sync" size={18} color={Colors.primary} />
          </TouchableOpacity>
        }
      />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Animal Selector */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.animalScroll} contentContainerStyle={{ gap: 8, paddingHorizontal: Spacing.base }}>
          {state.animals.slice(0, 6).map(a => (
            <TouchableOpacity
              key={a.id}
              onPress={() => setSelectedAnimalId(a.id)}
              style={[styles.animalChip, selectedAnimalId === a.id && styles.animalChipActive, dark && styles.animalChipDark]}
            >
              <View style={[styles.chipDot, { backgroundColor: tempColor(a.sensors?.temperature?.value || 38.5) }]} />
              <Text style={[styles.animalChipText, selectedAnimalId === a.id && styles.animalChipTextActive]}>
                {a.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Gauge */}
        <Card dark={dark} style={styles.gaugeCard}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>{animal?.name}'s Temperature</Text>
          <TempGauge value={temp} dark={dark} />
          <View style={styles.batteryRow}>
            <MaterialCommunityIcons name="battery" size={16} color={Colors.success} />
            <Text style={[styles.batteryText, dark && { color: Colors.darkTextSecondary }]}>
              Sensor Battery: {sensor?.batteryLevel}%
            </Text>
            <View style={styles.signalRow}>
              <MaterialCommunityIcons name="wifi" size={16} color={Colors.info} />
              <Text style={[styles.batteryText, dark && { color: Colors.darkTextSecondary }]}>
                Signal: {sensor?.signalStrength}%
              </Text>
            </View>
          </View>
        </Card>

        {/* 24h Chart */}
        {chartData.length > 0 && (
          <Card dark={dark}>
            <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>24-Hour History</Text>
            <LineChart
              data={{
                labels: chartLabels,
                datasets: [
                  { data: chartData, color: () => tempColor(temp) },
                  { data: [39.5, 39.5, 39.5, 39.5, 39.5, 39.5], color: () => Colors.danger + '80', withDots: false },
                ],
              }}
              width={width - 64}
              height={180}
              chartConfig={{
                backgroundGradientFrom: dark ? Colors.darkSurface : Colors.surface,
                backgroundGradientTo: dark ? Colors.darkSurface : Colors.surface,
                color: (opacity = 1) => `rgba(46,125,50,${opacity})`,
                labelColor: (opacity = 1) => dark ? `rgba(165,200,167,${opacity})` : `rgba(90,116,96,${opacity})`,
                decimalPlaces: 1,
                propsForDots: { r: '3' },
              }}
              bezier
              style={styles.chart}
              withInnerLines={false}
              withOuterLines={false}
            />
            <Text style={[styles.chartNote, dark && { color: Colors.darkTextMuted }]}>
              — Red dashed line = 39.5°C critical threshold
            </Text>
          </Card>
        )}

        {/* Thresholds */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>Temperature Zones</Text>
          {thresholds.map(t => (
            <View key={t.label} style={styles.thresholdRow}>
              <View style={[styles.thresholdDot, { backgroundColor: t.color }]} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.thresholdLabel, dark && { color: Colors.darkText }]}>{t.label} ({t.range})</Text>
                <Text style={[styles.thresholdDesc, dark && { color: Colors.darkTextMuted }]}>{t.desc}</Text>
              </View>
            </View>
          ))}
        </Card>

        {/* All Animals Temp Table */}
        <Card dark={dark}>
          <Text style={[styles.cardTitle, dark && { color: Colors.darkText }]}>All Animals — Current Temp</Text>
          {state.animals.map(a => {
            const t = a.sensors?.temperature?.value || 0;
            const c = tempColor(t);
            return (
              <View key={a.id} style={[styles.animalTempRow, dark && styles.animalTempRowDark]}>
                <Text style={[styles.animalTempName, dark && { color: Colors.darkText }]}>{a.name}</Text>
                <Text style={[styles.animalTempSpecies, dark && { color: Colors.darkTextMuted }]}>{a.species}</Text>
                <View style={styles.animalTempRight}>
                  <Text style={[styles.animalTempValue, { color: c }]}>{t}°C</Text>
                  {t > 39.5 && <MaterialCommunityIcons name="alert-circle" size={16} color={Colors.danger} />}
                </View>
              </View>
            );
          })}
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  safeDark: { backgroundColor: Colors.darkBackground },
  content: { paddingBottom: 40, gap: Spacing.md },
  animalScroll: { paddingVertical: Spacing.md },
  animalChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: Radius.round, backgroundColor: Colors.surfaceSecondary, borderWidth: 1.5, borderColor: Colors.border },
  animalChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  animalChipDark: { backgroundColor: Colors.darkSurface, borderColor: Colors.darkBorder },
  animalChipText: { fontSize: Typography.sm, color: Colors.textSecondary, fontWeight: '600' },
  animalChipTextActive: { color: '#fff' },
  chipDot: { width: 8, height: 8, borderRadius: 4 },
  gaugeCard: { alignItems: 'center', paddingVertical: Spacing.xl, marginHorizontal: Spacing.base },
  cardTitle: { fontSize: Typography.md, fontWeight: '700', color: Colors.text, marginBottom: Spacing.md },
  tempStatus: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.round, marginTop: Spacing.md },
  tempStatusText: { fontSize: Typography.sm, fontWeight: '700' },
  batteryRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: Spacing.md },
  batteryText: { fontSize: Typography.xs, color: Colors.textSecondary },
  signalRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginLeft: 'auto' },
  chart: { borderRadius: Radius.lg, marginLeft: -16 },
  chartNote: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: Spacing.sm, textAlign: 'center' },
  thresholdRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, paddingVertical: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border },
  thresholdDot: { width: 14, height: 14, borderRadius: 7 },
  thresholdLabel: { fontSize: Typography.sm, fontWeight: '600', color: Colors.text },
  thresholdDesc: { fontSize: Typography.xs, color: Colors.textMuted, marginTop: 2 },
  animalTempRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: Colors.border, gap: Spacing.md },
  animalTempRowDark: { borderBottomColor: Colors.darkBorder },
  animalTempName: { width: 70, fontSize: Typography.sm, fontWeight: '700', color: Colors.text },
  animalTempSpecies: { flex: 1, fontSize: Typography.xs, color: Colors.textMuted },
  animalTempRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  animalTempValue: { fontSize: Typography.base, fontWeight: '800' },
  syncBtn: { padding: 8, backgroundColor: Colors.surfaceSecondary, borderRadius: Radius.md },
});
